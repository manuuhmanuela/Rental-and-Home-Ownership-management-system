<?php
require 'config.php';
require 'includes/cart_helpers.php';

/* ── Filters from GET ── */
$purpose  = $_GET['purpose'] ?? '';        // '', 'sale', 'rent'
$search   = trim($_GET['search'] ?? '');
$type     = $_GET['type'] ?? '';
$minPrice = (float)($_GET['min_price'] ?? 0);
$maxPrice = (float)($_GET['max_price'] ?? 0);
$sort     = $_GET['sort'] ?? 'newest';

/* ── Build query ── */
$sql = "SELECT p.*, u.name AS owner_name
        FROM properties p
        JOIN users u ON u.id = p.owner_id
        WHERE p.status = 'approved'";
$params = [];

if (in_array($purpose, ['sale','rent'], true)) {
    $sql .= " AND p.purpose = ?";
    $params[] = $purpose;
}
if ($search !== '') {
    $sql .= " AND (p.title LIKE ? OR p.location LIKE ? OR p.description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if (in_array($type, ['Apartment','Bungalow','Townhouse','Land','Commercial'], true)) {
    $sql .= " AND p.type = ?";
    $params[] = $type;
}
if ($minPrice > 0) { $sql .= " AND p.price >= ?"; $params[] = $minPrice; }
if ($maxPrice > 0) { $sql .= " AND p.price <= ?"; $params[] = $maxPrice; }

/* Sort */
switch ($sort) {
    case 'price_asc':  $sql .= " ORDER BY p.price ASC"; break;
    case 'price_desc': $sql .= " ORDER BY p.price DESC"; break;
    case 'views':      $sql .= " ORDER BY p.views DESC"; break;
    default:           $sql .= " ORDER BY p.featured DESC, p.created_at DESC"; break;
}

/* NO LIMIT — show every approved property */
$stmt = db()->prepare($sql);
$stmt->execute($params);
$properties = $stmt->fetchAll();

/* Counts for tabs */
$countSale = (int)q("SELECT COUNT(*) FROM properties WHERE status='approved' AND purpose='sale'")->fetchColumn();
$countRent = (int)q("SELECT COUNT(*) FROM properties WHERE status='approved' AND purpose='rent'")->fetchColumn();
$countAll  = $countSale + $countRent;

/* Image resolver */
function prop_image_src($p) {
    $v = trim((string)($p['image_url'] ?? ''));
    if ($v === '') {
        return 'https://picsum.photos/seed/' . (int)$p['id'] . '/600/400';
    }
    if (preg_match('#^https?://#i', $v)) return $v;
    if (strpos($v, '/') === 0) return $v;
    return rtrim(BASE, '/') . '/uploads/properties/' . rawurlencode(basename($v));
}

top('Properties');
?>
<style>
    .cat-tabs { display: flex; gap: 8px; margin-bottom: 16px; flex-wrap: wrap; }
    .cat-tab {
        display: inline-flex; align-items: center; gap: 8px;
        padding: 10px 18px; border-radius: 999px;
        background: #fff; border: 1px solid #e5e7eb;
        color: #374151; font-weight: 700; font-size: .9rem;
        text-decoration: none; transition: all .15s;
    }
    .cat-tab:hover { background: #eff6ff; border-color: #bfdbfe; color: #1e40af; }
    .cat-tab.active { background: #2563eb; border-color: #2563eb; color: #fff; }
    .cat-tab .count {
        display: inline-block; padding: 1px 8px; border-radius: 999px;
        background: rgba(0,0,0,.08); font-size: .72rem; font-weight: 700;
    }
    .cat-tab.active .count { background: rgba(255,255,255,.25); }

    .prop-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 16px; }
    .prop-card {
        background: #fff; border: 1px solid #e5e7eb; border-radius: 12px;
        overflow: hidden; box-shadow: 0 2px 8px rgba(15,23,42,.04);
        display: flex; flex-direction: column;
        transition: transform .15s, box-shadow .15s;
    }
    .prop-card:hover { transform: translateY(-2px); box-shadow: 0 8px 22px rgba(15,23,42,.09); }
    .prop-img {
        width: 100%; height: 170px; object-fit: cover; display: block;
        background: #eef2f7;
    }
    .prop-body { padding: 14px; display: flex; flex-direction: column; flex: 1; }
    .prop-title { font-weight: 700; font-size: 1rem; margin: 0 0 4px; color: #111827; }
    .prop-loc { color: #6b7280; font-size: .82rem; margin-bottom: 8px; }
    .prop-tags { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 8px; }
    .prop-tag {
        font-size: .68rem; padding: 2px 8px; border-radius: 999px;
        font-weight: 700; text-transform: uppercase; letter-spacing: .3px;
    }
    .prop-tag.purpose-sale { background:#dbeafe; color:#1e40af; }
    .prop-tag.purpose-rent { background:#ede9fe; color:#5b21b6; }
    .prop-tag.type { background:#f1f5f9; color:#475569; }
    .prop-price { font-size: 1.15rem; font-weight: 800; color: #2563eb; margin: 4px 0 10px; }
    .prop-price small { font-size: .72rem; color: #6b7280; font-weight: 500; }
    .prop-actions { display: flex; gap: 6px; flex-wrap: wrap; margin-top: auto; }
    .empty-state { text-align: center; padding: 50px 20px; color: #6b7280; }
    .empty-state h3 { margin: 0 0 8px; color: #1f2937; }

    .result-bar {
        display: flex; justify-content: space-between; align-items: center;
        flex-wrap: wrap; gap: 10px; margin-bottom: 14px;
    }
    .result-bar .n { font-weight: 700; }
    .result-bar .muted { font-size: .85rem; }
</style>

<section class="wrap">
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:16px">
        <h1 style="margin:0">Properties</h1>
        <?php if (user()): ?>
            <a class="btn" href="<?=BASE?>/list_property.php">
                <i class="bi bi-plus-circle"></i> List a property
            </a>
        <?php else: ?>
            <a class="btn ghost" href="<?=BASE?>/login.php">
                <i class="bi bi-box-arrow-in-right"></i> Log in to list
            </a>
        <?php endif; ?>
    </div>

    <!-- Category tabs -->
    <div class="cat-tabs">
        <a class="cat-tab <?= $purpose === '' ? 'active' : '' ?>" href="<?=BASE?>/properties.php">
            <i class="bi bi-grid"></i> All <span class="count"><?=$countAll?></span>
        </a>
        <a class="cat-tab <?= $purpose === 'sale' ? 'active' : '' ?>" href="<?=BASE?>/properties.php?purpose=sale">
            <i class="bi bi-house-check"></i> For Sale <span class="count"><?=$countSale?></span>
        </a>
        <a class="cat-tab <?= $purpose === 'rent' ? 'active' : '' ?>" href="<?=BASE?>/properties.php?purpose=rent">
            <i class="bi bi-key"></i> For Rent <span class="count"><?=$countRent?></span>
        </a>
    </div>

    <!-- Filters -->
    <form method="get" class="box grid">
        <input type="hidden" name="purpose" value="<?=e($purpose)?>">
        <label>Search
            <input type="text" name="search" value="<?=e($search)?>" placeholder="Title, location, description">
        </label>
        <label>Type
            <select name="type">
                <option value="">Any</option>
                <?php foreach (['Apartment','Bungalow','Townhouse','Land','Commercial'] as $t): ?>
                    <option value="<?=$t?>" <?=$type===$t?'selected':''?>><?=$t?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>Min price
            <input type="number" name="min_price" value="<?=$minPrice > 0 ? $minPrice : ''?>" min="0">
        </label>
        <label>Max price
            <input type="number" name="max_price" value="<?=$maxPrice > 0 ? $maxPrice : ''?>" min="0">
        </label>
        <label>Sort
            <select name="sort">
                <option value="newest" <?=$sort==='newest'?'selected':''?>>Newest</option>
                <option value="price_asc" <?=$sort==='price_asc'?'selected':''?>>Price: low to high</option>
                <option value="price_desc" <?=$sort==='price_desc'?'selected':''?>>Price: high to low</option>
                <option value="views" <?=$sort==='views'?'selected':''?>>Most viewed</option>
            </select>
        </label>
        <div style="display:flex;gap:8px;align-items:end">
            <button class="btn">Filter</button>
            <a class="btn ghost" href="<?=BASE?>/properties.php<?= $purpose ? '?purpose='.$purpose : '' ?>">Reset</a>
        </div>
    </form>

    <!-- Result bar -->
    <div class="result-bar">
        <div class="n">
            <?=count($properties)?> propert<?=count($properties) === 1 ? 'y' : 'ies'?> found
        </div>
        <div class="muted">
            <?= $purpose === 'sale' ? 'For Sale' : ($purpose === 'rent' ? 'For Rent' : 'All categories') ?>
        </div>
    </div>

    <!-- Grid -->
    <?php if (!$properties): ?>
        <div class="box empty-state">
            <h3>No properties found</h3>
            <p>Try adjusting the filters or check a different category.</p>
            <a class="btn" href="<?=BASE?>/properties.php">Show all properties</a>
        </div>
    <?php else: ?>
        <div class="prop-grid">
            <?php foreach ($properties as $p): ?>
                <div class="prop-card">
                    <a href="<?=BASE?>/property.php?id=<?=(int)$p['id']?>">
                        <img class="prop-img" src="<?=e(prop_image_src($p))?>" alt="<?=e($p['title'])?>">
                    </a>
                    <div class="prop-body">
                        <h3 class="prop-title"><?=e($p['title'])?></h3>
                        <div class="prop-loc"><i class="bi bi-geo-alt"></i> <?=e($p['location'])?></div>
                        <div class="prop-tags">
                            <span class="prop-tag purpose-<?=e($p['purpose'])?>">
                                <?= $p['purpose'] === 'rent' ? 'For Rent' : 'For Sale' ?>
                            </span>
                            <span class="prop-tag type"><?=e($p['type'])?></span>
                        </div>
                        <div class="prop-price">
                            KShs <?=number_format((float)$p['price'])?>
                            <?php if ($p['purpose'] === 'rent'): ?><small>/month</small><?php endif; ?>
                        </div>
                        <div class="muted" style="font-size:.8rem;margin-bottom:8px">
                            <?= (int)$p['bedrooms'] ?> bed ·
                            <?= (int)$p['bathrooms'] ?> bath ·
                            <?=e($p['size'] ?: '—')?>
                        </div>
                        <div class="prop-actions">
                            <a class="btn sm" href="<?=BASE?>/property.php?id=<?=(int)$p['id']?>">
                                View
                            </a>
                            <?php if (user()): ?>
                                <form method="post" action="<?=BASE?>/cart_action.php" style="display:inline">
                                    <?=field()?>
                                    <input type="hidden" name="action" value="add">
                                    <input type="hidden" name="property_id" value="<?=(int)$p['id']?>">
                                    <input type="hidden" name="type" value="<?= $p['purpose']==='rent' ? 'rental' : 'purchase' ?>">
                                    <input type="hidden" name="months" value="1">
                                    <button class="btn sm ghost">
                                        <i class="bi bi-cart-plus"></i>
                                        <?= $p['purpose']==='rent' ? 'Rent' : 'Buy' ?>
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</section>
<?php include 'includes/footer.php'; ?>