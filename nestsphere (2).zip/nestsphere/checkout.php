<?php
require 'config.php';
require 'includes/cart_helpers.php';
need_login();

$totals = cart_totals();
if ($totals['count'] === 0) {
    go('/cart.php');
}

$u = user();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check();

    $phone = trim($_POST['phone'] ?? '');

    if (!preg_match('/^(?:\+?254|0)?7\d{8}$/', $phone)) {
        $errors[] = 'Enter a valid M-Pesa phone (e.g. 0712345678).';
    }

    if (!$errors) {
        $ref = make_order_ref();
        db()->prepare("INSERT INTO orders(order_ref, user_id, order_type, total_amount, status) VALUES(?,?,?,?, 'pending')")
            ->execute([$ref, $u['id'], $totals['type'], $totals['total']]);
        $orderId = (int)db()->lastInsertId();

        $insItem = db()->prepare("INSERT INTO order_items(order_id, property_id, item_type, price, months, subtotal) VALUES(?,?,?,?,?,?)");
        $insRent = db()->prepare("INSERT INTO rentals(order_id, user_id, property_id, monthly_rent, months, start_date) VALUES(?,?,?,?,?, CURDATE())");

        foreach ($totals['items'] as $it) {
            $lineMonths = $it['type'] === 'rental' ? (int)$it['months'] : 1;
            $insItem->execute([$orderId, $it['property_id'], $it['type'], (float)$it['price'], $lineMonths, line_subtotal($it)]);
            if ($it['type'] === 'rental') {
                $insRent->execute([$orderId, $u['id'], $it['property_id'], (float)$it['price'], $lineMonths]);
            }
        }

        $_SESSION['pending_order'] = [
            'order_id'  => $orderId,
            'order_ref' => $ref,
            'amount'    => $totals['total'],
            'phone'     => $phone,
        ];
        go('/mpesa.php');
    }
}

top('Checkout');
?>
<section class="wrap narrow">
    <h1>Checkout</h1>

    <?php if ($errors): ?>
        <div class="box bad">
            <?php foreach ($errors as $er): ?><p><?=e($er)?></p><?php endforeach; ?>
        </div>
    <?php endif; ?>

    <div class="box">
        <h2>Order summary</h2>
        <table class="tbl">
            <thead><tr><th>Property</th><th>Type</th><th>Months</th><th>Subtotal</th></tr></thead>
            <tbody>
            <?php foreach ($totals['items'] as $it): ?>
                <tr>
                    <td><?=e($it['title'])?></td>
                    <td><?= $it['type'] === 'rental' ? 'Rental' : 'Purchase' ?></td>
                    <td><?= $it['type'] === 'rental' ? (int)$it['months'] : '—' ?></td>
                    <td>KShs <?=number_format(line_subtotal($it), 2)?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr><th colspan="3" style="text-align:right">Total</th><th>KShs <?=number_format($totals['total'], 2)?></th></tr>
            </tfoot>
        </table>
    </div>

    <form method="post" class="box">
        <?=field()?>
        <h2>Payment details</h2>
        <label>M-Pesa phone
            <input type="tel" name="phone" placeholder="0712345678" value="<?=e($u['phone'] ?? '')?>" required>
        </label>
        <p class="muted">You'll be redirected to pay <strong>KShs <?=number_format($totals['total'], 2)?></strong> via M-Pesa.</p>
        <button class="btn">Pay with M-Pesa &rarr;</button>
        <a class="btn ghost" href="<?=BASE?>/cart.php">Back to cart</a>
    </form>
</section>
<?php include 'includes/footer.php'; ?>