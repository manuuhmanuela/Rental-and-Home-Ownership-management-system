<?php
require 'config.php';
require 'includes/cart_helpers.php';
need_login();

$action = $_POST['action'] ?? $_GET['action'] ?? '';

if ($action === 'add') {
    check();
    $id     = (int)($_POST['property_id'] ?? 0);
    $type   = $_POST['type'] ?? 'purchase';
    $months = (int)($_POST['months'] ?? 1);

    $stmt = db()->prepare("SELECT id, title, location, image_url, price, purpose, status FROM properties WHERE id = ?");
    $stmt->execute([$id]);
    $p = $stmt->fetch();

    if ($p && $p['status'] === 'approved') {
        cart_add(
            $p['id'],
            $type === 'rental' ? 'rental' : 'purchase',
            $months,
            $p['price'], $p['title'], $p['location'], $p['image_url']
        );
    }
    go('/cart.php');
}

if ($action === 'update') {
    check();
    cart_update($_POST['key'] ?? '', (int)($_POST['months'] ?? 1));
    go('/cart.php');
}

if ($action === 'remove') {
    cart_remove($_GET['key'] ?? '');
    go('/cart.php');
}

if ($action === 'clear') {
    cart_clear();
    go('/cart.php');
}

go('/cart.php');