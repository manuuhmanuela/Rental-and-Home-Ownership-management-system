<?php
require 'config.php';

if (user()) {
    go(user()['role'] === 'admin' ? '/admin/dashboard.php' : '/user/dashboard.php');
}

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check();
    $n  = trim($_POST['name'] ?? '');
    $e  = trim($_POST['email'] ?? '');
    $p  = trim($_POST['phone'] ?? '');
    $c  = trim($_POST['city'] ?? '');
    $pw = $_POST['password'] ?? '';

    if ($n === '' || $e === '' || $p === '' || $pw === '') {
        $err = 'Please fill in all required fields.';
    } elseif (!filter_var($e, FILTER_VALIDATE_EMAIL)) {
        $err = 'Please enter a valid email address.';
    } elseif (strlen($pw) < 6) {
        $err = 'Password must be at least 6 characters.';
    } else {
        $exists = q("SELECT id FROM users WHERE email=?", [$e])->fetch();
        if ($exists) {
            $err = 'That email is already registered.';
        } else {
            q("INSERT INTO users(name,email,phone,city,password) VALUES(?,?,?,?,?)", [$n, $e, $p, $c, $pw]);
            $id = (int)db()->lastInsertId();
            session_regenerate_id(true);
            $_SESSION['user'] = ['id' => $id, 'name' => $n, 'role' => 'user'];
            logit('Registered an account');
            go('/user/dashboard.php');
        }
    }
}

top('Create an account');
?>
<section class="wrap narrow">
    <h1>Create an account</h1>
    <?php if ($err): ?><p class="bad"><?=e($err)?></p><?php endif; ?>
    <form method="post" class="box">
        <?=field()?>
        <label>Full name<input type="text" name="name" required value="<?=e($_POST['name'] ?? '')?>"></label>
        <label>Email<input type="email" name="email" required value="<?=e($_POST['email'] ?? '')?>"></label>
        <label>Phone<input type="text" name="phone" required value="<?=e($_POST['phone'] ?? '')?>"></label>
        <label>City<input type="text" name="city" value="<?=e($_POST['city'] ?? '')?>"></label>
        <label>Password<input type="password" name="password" required></label>
        <button class="btn">Sign up</button>
    </form>
    <p class="muted">Already have an account? <a href="<?=BASE?>/login.php">Log in</a>.</p>
</section>
<?php include 'includes/footer.php'; ?>