<?php require 'config.php';
if($_SERVER['REQUEST_METHOD'] === 'POST'){ check(); $f = fn($k) => trim($_POST[$k] ?? '');
  if($f('name') && filter_var($f('email'), FILTER_VALIDATE_EMAIL) && $f('message')){
    q("INSERT INTO messages(name,email,subject,message) VALUES(?,?,?,?)", [$f('name'), $f('email'), $f('subject') ?: 'General enquiry', $f('message')]);
    flash('Thanks, your message has been sent. We will reply by email.'); go('/contact.php');
  } flash('Enter your name, a valid email and a message.', 'bad');
}
top('Contact us'); $u = user(); ?>
<section class="wrap detail"><div><h1>Contact us</h1><p>Questions about a listing, your account or our services? Send us a message.</p>
<p><b>Office:</b> Nairobi, Kenya<br><b>Email:</b> info@nestsphere.co.ke<br><b>Phone:</b> +254 700 000 000</p>
<iframe class="map" loading="lazy" title="Map" src="https://maps.google.com/maps?q=Nairobi,Kenya&output=embed"></iframe></div>
<form method="post" class="box"><?=field()?><label>Full name<input name="name" required value="<?=e($u['name'] ?? '')?>"></label><label>Email<input type="email" name="email" required></label>
<label>Subject<input name="subject"></label><label>Message<textarea name="message" rows="5" required></textarea></label><button class="btn">Send message</button></form></section>
<?php include 'includes/footer.php';
