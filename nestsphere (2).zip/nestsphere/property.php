<?php
require 'config.php';
require 'includes/cart_helpers.php';

$id = (int)($_GET['id'] ?? 0);
$stmt = db()->prepare("SELECT p.*, u.name AS owner_name, u.phone AS owner_phone
                       FROM properties p
                       JOIN users u ON u.id = p.owner_id
                       WHERE p.id = ?");
$stmt->execute([$id]);
$p = $stmt->fetch();

if (!$p) {
    http_response_code(404);
    die('Property not found.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    need_login();
    check();
    $action = $_POST['action'] ?? '';

    if ($action === 'add_cart') {
        $type   = ($p['purpose'] === 'rent') ? 'rental' : 'purchase';
        $months = (int)($_POST['months'] ?? 1);
        cart_add($p['id'], $type, $months, $p['price'], $p['title'], $p['location'], $p['image_url']);
        go('/cart.php');
    }

    if ($action === 'buy_now' || $action === 'rent_now') {
        cart_clear();
        $type   = ($action === 'rent_now') ? 'rental' : 'purchase';
        $months = (int)($_POST['months'] ?? 1);
        cart_add($p['id'], $type, $months, $p['price'], $p['title'], $p['location'], $p['image_url']);
        go('/checkout.php');
    }
}

top($p['title']);
?>
<section class="wrap">
    <a href="<?=BASE?>/properties.php" class="muted">&larr; Back to properties</a>

    <div class="box" style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:14px">
        <div>
            <img src="<?=e($p['image_url'] ?: 'https://picsum.photos/seed/'.$p['id'].'/800/500')?>"
                 alt="<?=e($p['title'])?>"
                 style="width:100%;border-radius:12px;object-fit:cover;max-height:420px">
        </div>
        <div>
            <h1 style="margin-top:0"><?=e($p['title'])?></h1>
            <p class="muted"><?=e($p['type'])?> &middot; <?=e($p['location'])?> &middot; <?=e($p['purpose'] === 'rent' ? 'For Rent' : 'For Sale')?></p>
            <p>
                <strong><?=e($p['bedrooms'])?></strong> bed &middot;
                <strong><?=e($p['bathrooms'])?></strong> bath &middot;
                <?=e($p['size'])?>
            </p>
            <p style="font-size:1.5rem;font-weight:800;color:#2563eb">
                KShs <?=number_format((float)$p['price'], 2)?>
                <?php if ($p['purpose'] === 'rent'): ?><small style="font-size:.85rem;color:#6b7280">/ month</small><?php endif; ?>
            </p>
            <p><?=nl2br(e($p['description']))?></p>
            <p class="muted">Listed by <?=e($p['owner_name'])?> &middot; <?=e($p['owner_phone'])?></p>

            <?php if ($p['status'] !== 'approved'): ?>
                <p class="bad">This property is not yet approved for purchase or rent.</p>
            <?php elseif (!user()): ?>
                <div class="box" style="border-left:4px solid #2563eb">
                    <p style="margin:0 0 8px"><strong>Log in to buy or rent this property.</strong></p>
                    <a class="btn" href="<?=BASE?>/login.php">Log in</a>
                    <a class="btn ghost" href="<?=BASE?>/register.php">Create account</a>
                </div>
            <?php else: ?>
                <form method="post" class="box" style="margin-top:14px">
                    <?=field()?>
                    <?php if ($p['purpose'] === 'rent'): ?>
                        <label>Months to rent
                            <input type="number" name="months" min="1" max="24" value="1" required>
                        </label>
                        <div style="display:flex;gap:8px;flex-wrap:wrap">
                            <button name="action" value="rent_now" class="btn">Rent now &rarr; Checkout</button>
                            <button name="action" value="add_cart" class="btn ghost">Add to cart</button>
                        </div>
                    <?php else: ?>
                        <div style="display:flex;gap:8px;flex-wrap:wrap">
                            <button name="action" value="buy_now" class="btn">Buy now &rarr; Checkout</button>
                            <button name="action" value="add_cart" class="btn ghost">Add to cart</button>
                        </div>
                    <?php endif; ?>
                </form>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php include 'includes/footer.php'; ?>