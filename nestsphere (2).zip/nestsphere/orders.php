<?php
require '../config.php';
need_login();

$u = user();

$orders = q("SELECT o.*,
                    (SELECT COUNT(*) FROM order_items oi WHERE oi.order_id=o.order_id) AS item_count
             FROM orders o
             WHERE o.user_id=?
             ORDER BY o.created_at DESC", [$u['id']])->fetchAll();

$paidCount    = 0;
$pendingCount = 0;
$totalPaid    = 0.0;
foreach ($orders as $o) {
    if ($o['status'] === 'paid') { $paidCount++; $totalPaid += (float)$o['total_amount']; }
    elseif ($o['status'] === 'pending') $pendingCount++;
}

top('My orders');
?>
<style>
    .order-card {
        background: #fff; border: 1px solid #e5e7eb; border-radius: 12px;
        padding: 14px 16px; margin-bottom: 12px;
        box-shadow: 0 2px 8px rgba(15,23,42,.04);
        display: grid;
        grid-template-columns: 1fr auto;
        gap: 12px;
        align-items: center;
    }
    .order-card .ref { font-weight: 700; font-size: 1rem; }
    .order-card .meta { color: #6b7280; font-size: .82rem; margin-top: 4px; }
    .order-card .amt { font-weight: 800; font-size: 1.1rem; color: #2563eb; }
    .order-card .actions { display: flex; gap: 6px; flex-wrap: wrap; justify-content: flex-end; }
    .kpi-grid {
        display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 12px; margin-bottom: 18px;
    }
    .kpi {
        background: #fff; border: 1px solid #e5e7eb; border-radius: 12px;
        padding: 14px 16px;
    }
    .kpi .l { font-size: .72rem; text-transform: uppercase; color: #6b7280; font-weight: 700; letter-spacing: .4px; }
    .kpi .v { font-size: 1.35rem; font-weight: 800; color: #111827; margin-top: 4px; }
    @media (max-width: 640px) {
        .order-card { grid-template-columns: 1fr; }
        .order-card .actions { justify-content: flex-start; }
    }
</style>

<section class="wrap">
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:16px">
        <div>
            <h1 style="margin:0">My orders</h1>
            <p class="muted" style="margin:4px 0 0">Purchases and rentals you've made</p>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
            <a class="btn" href="<?=BASE?>/properties.php">Browse properties</a>
            <a class="btn ghost" href="<?=BASE?>/user/rentals.php">My rentals</a>
        </div>
    </div>

    <div class="kpi-grid">
        <div class="kpi"><div class="l">Total orders</div><div class="v"><?=count($orders)?></div></div>
        <div class="kpi"><div class="l">Paid</div><div class="v" style="color:#16a34a"><?=$paidCount?></div></div>
        <div class="kpi"><div class="l">Pending</div><div class="v" style="color:#d97706"><?=$pendingCount?></div></div>
        <div class="kpi"><div class="l">Total paid</div><div class="v">KShs <?=number_format($totalPaid, 0)?></div></div>
    </div>

    <?php if (!$orders): ?>
        <div class="box" style="text-align:center;padding:40px">
            <p class="muted">You haven't placed any orders yet.</p>
            <a class="btn" href="<?=BASE?>/properties.php">Browse properties</a>
        </div>
    <?php else: ?>
        <?php foreach ($orders as $o): ?>
            <div class="order-card">
                <div>
                    <div class="ref"><?=e($o['order_ref'])?></div>
                    <div class="meta">
                        <?=date('d M Y H:i', strtotime($o['created_at']))?>
                        · <?=ucfirst(e($o['order_type']))?>
                        · <?=(int)$o['item_count']?> item(s)
                    </div>
                    <div style="margin-top:6px">
                        <span class="badge <?= $o['status']==='paid'?'ok':($o['status']==='pending'?'warn':'bad') ?>">
                            <?=e($o['status'])?>
                        </span>
                        <?php if ($o['payment_ref']): ?>
                            <small class="muted" style="margin-left:8px">Ref: <?=e($o['payment_ref'])?></small>
                        <?php endif; ?>
                    </div>
                </div>
                <div style="text-align:right">
                    <div class="amt">KShs <?=number_format((float)$o['total_amount'], 2)?></div>
                    <div class="actions" style="margin-top:8px">
                        <a class="btn sm" href="<?=BASE?>/track_order.php?id=<?=(int)$o['order_id']?>">
                            <i class="bi bi-geo-alt"></i> Track
                        </a>
                        <?php if ($o['status'] === 'pending'): ?>
                            <a class="btn sm bad" href="<?=BASE?>/cart.php">Pay now</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</section>
<?php include '../includes/footer.php'; ?>