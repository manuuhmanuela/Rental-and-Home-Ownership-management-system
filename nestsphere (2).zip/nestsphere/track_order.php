<?php
require 'config.php';
require 'includes/cart_helpers.php';
need_login();

$ref = trim($_GET['ref'] ?? '');
$id  = (int)($_GET['id'] ?? 0);
$u   = user();

/* Fetch the order (must belong to this user, unless admin) */
$sql = "SELECT o.*, us.name AS user_name, us.email AS user_email, us.phone AS user_phone
        FROM orders o
        JOIN users us ON us.id = o.user_id
        WHERE ";
$params = [];
if ($id > 0) {
    $sql .= "o.order_id = ?";
    $params[] = $id;
} else {
    $sql .= "o.order_ref = ?";
    $params[] = $ref;
}
$stmt = db()->prepare($sql);
$stmt->execute($params);
$order = $stmt->fetch();

if (!$order) {
    http_response_code(404);
    top('Order not found');
    echo '<section class="wrap narrow"><h1>Order not found</h1><p class="muted">That order doesn\'t exist.</p><a class="btn" href="'.BASE.'/user/orders.php">Back to my orders</a></section>';
    include 'includes/footer.php';
    exit;
}

/* Permission */
if (($order['user_id'] ?? 0) != ($u['id'] ?? 0) && ($u['role'] ?? '') !== 'admin') {
    http_response_code(403);
    die('You do not have access to this order.');
}

/* Order items */
$items = db()->prepare("SELECT oi.*, p.title, p.location, p.image_url, p.type AS ptype, p.purpose
                        FROM order_items oi
                        JOIN properties p ON p.id = oi.property_id
                        WHERE oi.order_id = ?
                        ORDER BY oi.item_id ASC");
$items->execute([$order['order_id']]);
$items = $items->fetchAll();

/* Rentals attached to this order */
$rentals = db()->prepare("SELECT r.*, p.title, p.location
                          FROM rentals r
                          JOIN properties p ON p.id = r.property_id
                          WHERE r.order_id = ?");
$rentals->execute([$order['order_id']]);
$rentals = $rentals->fetchAll();

/* Status timeline */
$steps = [
    ['key' => 'placed',    'label' => 'Order placed',       'when' => $order['created_at'], 'icon' => '📝'],
    ['key' => 'payment',   'label' => 'Payment ' . ($order['status'] === 'paid' ? 'received' : 'pending'), 'when' => $order['paid_at'], 'icon' => '💳'],
    ['key' => 'processing','label' => 'Processing',         'when' => $order['status'] === 'paid' ? $order['paid_at'] : null, 'icon' => '⚙️'],
    ['key' => 'completed', 'label' => $order['status'] === 'paid' ? 'Completed' : 'Awaiting payment', 'when' => $order['status'] === 'paid' ? $order['paid_at'] : null, 'icon' => '✅'],
];

top('Track order ' . $order['order_ref']);
?>
<style>
    .track-head {
        display: flex; justify-content: space-between; align-items: center;
        flex-wrap: wrap; gap: 10px; margin-bottom: 16px;
    }
    .track-head h1 { margin: 0; }
    .track-head .ref { color: #6b7280; font-size: .9rem; }

    .status-pill {
        display: inline-block; padding: 6px 14px; border-radius: 999px;
        font-size: .8rem; font-weight: 700; text-transform: uppercase; letter-spacing: .4px;
    }
    .status-pill.paid       { background: #dcfce7; color: #166534; }
    .status-pill.pending    { background: #fef3c7; color: #92400e; }
    .status-pill.cancelled  { background: #fee2e2; color: #991b1b; }
    .status-pill.failed     { background: #fee2e2; color: #991b1b; }

    .timeline {
        display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
        gap: 12px; margin: 8px 0 22px;
    }
    .step {
        background: #fff; border: 1px solid #e5e7eb; border-radius: 12px;
        padding: 14px 16px; position: relative;
    }
    .step.done { border-color: #bbf7d0; background: #f0fdf4; }
    .step.current { border-color: #bfdbfe; background: #eff6ff; }
    .step .icon { font-size: 1.4rem; }
    .step .label { font-weight: 700; margin: 6px 0 2px; }
    .step .when { font-size: .78rem; color: #6b7280; }

    .box h2 { font-size: 1rem; }

    .item-row {
        display: grid; grid-template-columns: 80px 1fr auto; gap: 12px;
        align-items: center; padding: 12px 0; border-bottom: 1px solid #f1f5f9;
    }
    .item-row:last-child { border-bottom: none; }
    .item-thumb {
        width: 80px; height: 60px; border-radius: 8px;
        object-fit: cover; background: #eef2f7;
    }

    @media (max-width: 640px) {
        .track-head { flex-direction: column; align-items: flex-start; }
        .item-row { grid-template-columns: 60px 1fr; }
        .item-row .item-right { grid-column: 1 / -1; text-align: right; }
    }
</style>

<section class="wrap">
    <div class="track-head">
        <div>
            <h1>Track order</h1>
            <div class="ref"><?=e($order['order_ref'])?> · placed <?=date('d M Y H:i', strtotime($order['created_at']))?></div>
        </div>
        <div>
            <span class="status-pill <?=e($order['status'])?>"><?=e($order['status'])?></span>
            <a class="btn ghost" href="<?=BASE?>/user/orders.php" style="margin-left:8px">&larr; My orders</a>
        </div>
    </div>

    <!-- TIMELINE -->
    <div class="timeline">
        <?php foreach ($steps as $s): ?>
            <div class="step <?= $s['when'] ? 'done' : '' ?>">
                <div class="icon"><?=$s['icon']?></div>
                <div class="label"><?=e($s['label'])?></div>
                <div class="when">
                    <?= $s['when'] ? e(date('d M Y H:i', strtotime($s['when']))) : '—' ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- SUMMARY -->
    <div class="box" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px">
        <div>
            <div class="muted" style="font-size:.78rem">Type</div>
            <div style="font-weight:700"><?=ucfirst(e($order['order_type']))?></div>
        </div>
        <div>
            <div class="muted" style="font-size:.78rem">Total amount</div>
            <div style="font-weight:700;font-size:1.2rem;color:#2563eb">KShs <?=number_format((float)$order['total_amount'], 2)?></div>
        </div>
        <div>
            <div class="muted" style="font-size:.78rem">Payment method</div>
            <div style="font-weight:700"><?=e($order['payment_method'] ?: '—')?></div>
        </div>
        <div>
            <div class="muted" style="font-size:.78rem">Payment ref</div>
            <div style="font-weight:700"><?=e($order['payment_ref'] ?: '—')?></div>
        </div>
        <div>
            <div class="muted" style="font-size:.78rem">Paid at</div>
            <div style="font-weight:700"><?= $order['paid_at'] ? date('d M Y H:i', strtotime($order['paid_at'])) : '—' ?></div>
        </div>
    </div>

    <!-- ITEMS -->
    <div class="box">
        <h2>Items</h2>
        <?php if (!$items): ?>
            <p class="muted">No items.</p>
        <?php else: ?>
            <?php foreach ($items as $it):
                $v = trim((string)($it['image_url'] ?? ''));
                if ($v === '') $img = 'https://picsum.photos/seed/'.$it['property_id'].'/160/120';
                elseif (preg_match('#^https?://#i', $v)) $img = $v;
                elseif (strpos($v, '/') === 0) $img = $v;
                else $img = rtrim(BASE, '/') . '/uploads/properties/' . rawurlencode(basename($v));
            ?>
                <div class="item-row">
                    <img class="item-thumb" src="<?=e($img)?>" alt="">
                    <div>
                        <strong><?=e($it['title'])?></strong><br>
                        <span class="muted" style="font-size:.82rem"><?=e($it['location'])?> · <?=e($it['ptype'])?></span>
                        <div class="muted" style="font-size:.8rem;margin-top:4px">
                            <?= $it['item_type'] === 'rental' ? 'Rental · '.(int)$it['months'].' month(s)' : 'Purchase' ?>
                        </div>
                    </div>
                    <div class="item-right" style="text-align:right">
                        <div>KShs <?=number_format((float)$it['price'], 2)?></div>
                        <strong>KShs <?=number_format((float)$it['subtotal'], 2)?></strong>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- RENTALS -->
    <?php if ($rentals): ?>
        <div class="box">
            <h2>Rental agreements</h2>
            <table class="tbl">
                <thead><tr><th>Property</th><th>Monthly rent</th><th>Months</th><th>Start</th><th>Status</th></tr></thead>
                <tbody>
                <?php foreach ($rentals as $r): ?>
                    <tr>
                        <td><?=e($r['title'])?><br><span class="muted" style="font-size:.78rem"><?=e($r['location'])?></span></td>
                        <td>KShs <?=number_format((float)$r['monthly_rent'], 2)?></td>
                        <td><?=(int)$r['months']?></td>
                        <td><?=e($r['start_date'])?></td>
                        <td>
                            <span class="badge <?= $r['status']==='active'?'ok':($r['status']==='expired'?'muted':'bad') ?>">
                                <?=e($r['status'])?>
                            </span>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>

    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:12px">
        <a class="btn" href="<?=BASE?>/properties.php">Browse more properties</a>
        <a class="btn ghost" href="<?=BASE?>/user/orders.php">All my orders</a>
    </div>
</section>
<?php include 'includes/footer.php'; ?>