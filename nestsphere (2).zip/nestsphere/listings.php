<?php require 'config.php';
$w = ["status='approved'"]; $p = [];
if(($s = trim($_GET['q'] ?? '')) !== ''){ $w[] = "(location LIKE ? OR title LIKE ?)"; array_push($p, "%$s%", "%$s%"); }
if(in_array($_GET['type'] ?? '', TYPES)){ $w[] = "type=?"; $p[] = $_GET['type']; }
if(in_array($_GET['purpose'] ?? '', ['sale','rent'])){ $w[] = "purpose=?"; $p[] = $_GET['purpose']; }
if(!empty($_GET['min'])){ $w[] = "price>=?"; $p[] = (float)$_GET['min']; }
if(!empty($_GET['max'])){ $w[] = "price<=?"; $p[] = (float)$_GET['max']; }
if(!empty($_GET['beds'])){ $w[] = "bedrooms>=?"; $p[] = (int)$_GET['beds']; }
$where = implode(' AND ', $w); $per = 9; $page = max(1, (int)($_GET['page'] ?? 1));
$total = n("SELECT COUNT(*) FROM properties WHERE $where", $p); $pages = max(1, (int)ceil($total / $per));
$order = ['price_asc'=>'price ASC','price_desc'=>'price DESC'][$_GET['sort'] ?? ''] ?? 'featured DESC, id DESC';
$rows = q("SELECT * FROM properties WHERE $where ORDER BY $order LIMIT $per OFFSET ".(($page-1)*$per), $p)->fetchAll();
$g = fn($k) => e($_GET[$k] ?? '');
top('Property listings'); ?>
<section class="wrap"><h1>Property listings</h1>
<form class="filters box" method="get"><input name="q" placeholder="Location or title" value="<?=$g('q')?>">
<select name="purpose"><option value="">Buy or rent</option><option value="sale"<?=($g('purpose')==='sale')?' selected':''?>>Buy</option><option value="rent"<?=($g('purpose')==='rent')?' selected':''?>>Rent</option></select>
<select name="type"><option value="">Any type</option><?=opts(TYPES, $_GET['type'] ?? '')?></select>
<input type="number" name="min" min="0" placeholder="Min price" value="<?=$g('min')?>"><input type="number" name="max" min="0" placeholder="Max price" value="<?=$g('max')?>">
<select name="beds"><option value="">Any beds</option><?php foreach([1,2,3,4,5] as $b) echo '<option value="'.$b.'"'.(($_GET['beds'] ?? '') == $b ? ' selected' : '').'>'.$b.'+ beds</option>'; ?></select>
<select name="sort"><option value="">Newest first</option><option value="price_asc"<?=($g('sort')==='price_asc')?' selected':''?>>Price: low to high</option><option value="price_desc"<?=($g('sort')==='price_desc')?' selected':''?>>Price: high to low</option></select>
<button class="btn">Filter</button></form>
<p class="muted"><?=$total?> building<?=$total == 1 ? '' : 's'?> found</p>
<?php if(!$rows) echo '<p class="empty">No buildings match those filters. Widen the price range or clear the location.</p>'; ?>
<div class="grid"><?php foreach($rows as $r) echo card($r); ?></div>
<div class="pager"><?php for($i = 1; $i <= $pages; $i++) echo '<a class="'.($i == $page ? 'on' : '').'" href="?'.e(http_build_query(array_merge($_GET, ['page'=>$i]))).'">'.$i.'</a>'; ?></div></section>
<?php include 'includes/footer.php';
