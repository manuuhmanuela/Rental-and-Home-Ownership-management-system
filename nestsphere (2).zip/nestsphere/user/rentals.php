<?php
require '../config.php';
need_login();

$u = user();

$rentals = q("SELECT r.*, p.title, p.location, p.image_url, p.type AS ptype,
                     o.order_ref
              FROM rentals r
              JOIN properties p ON p.id = r.property_id
              JOIN orders o ON o.order_id = r.order_id
              WHERE r.user_id=?
              ORDER BY r.created_at DESC", [$u['id']])->fetchAll();

$active    = 0;
$expired   = 0;
$cancelled = 0;
$monthly   = 0.0;
foreach ($rentals as $r) {
    if ($r['status'] === 'active') { $active++; $monthly += (float)$r['monthly_rent']; }
    elseif ($r['status'] === 'expired') $expired++;
    elseif ($r['status'] === 'cancelled') $cancelled++;
}

function rental_img($p) {
    $v = trim((string)($p['image_url'] ?? ''));
    if ($v === '') return 'https://picsum.photos/seed/' . (int)$p['property_id'] . '/200/140';
    if (preg_match('#^https?://#i', $v)) return $v;
    if (strpos($v, '/') === 0) return $v;
    return rtrim(BASE, '/') . '/uploads/properties/' . rawurlencode(basename($v));
}

top('My rentals');
?>
<style>
    .kpi-grid {
        display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 12px; margin-bottom: 18px;
    }
    .kpi {
        background: #fff; border: 1px solid #e5e7eb; border-radius: 12px;
        padding: 14px 16px;
    }
    .kpi .l { font-size: .72rem; text-transform: uppercase; color: #6b7280; font-weight: 700; letter-spacing: .4px; }
    .kpi .v { font-size: 1.35rem; font-weight: 800; color: #111827; margin-top: 4px; }

    .rental-card {
        background: #fff; border: 1px solid #e5e7eb; border-radius: 12px;
        overflow: hidden; box-shadow: 0 2px 8px rgba(15,23,42,.04);
        display: grid;
        grid-template-columns: 160px 1fr auto;
        gap: 12px;
        align-items: stretch;
        margin-bottom: 12px;
    }
    .rental-card .thumb {
        width: 160px; height: 100%; min-height: 110px;
        object-fit: cover; background: #eef2f7;
    }
    .rental-card .body { padding: 14px 0; }
    .rental-card .body .title { font-weight: 700; font-size: 1rem; }
    .rental-card .body .muted { font-size: .82rem; }
    .rental-card .right {
        padding: 14px 16px; text-align: right;
        display: flex; flex-direction: column; justify-content: center; gap: 6px;
    }
    .rental-card .right .price { font-weight: 800; font-size: 1.1rem; color: #2563eb; }
    @media (max-width: 640px) {
        .rental-card { grid-template-columns: 1fr; }
        .rental-card .thumb { width: 100%; height: 160px; }
        .rental-card .body { padding: 0 14px; }
        .rental-card .right { padding: 0 14px 14px; text-align: left; align-items: flex-start; }
    }
</style>

<section class="wrap">
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:16px">
        <div>
            <h1 style="margin:0">My rentals</h1>
            <p class="muted" style="margin:4px 0 0">Monthly rentals and lease agreements</p>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
            <a class="btn" href="<?=BASE?>/properties.php?purpose=rent">Rent a property</a>
            <a class="btn ghost" href="<?=BASE?>/user/orders.php">My orders</a>
        </div>
    </div>

    <div class="kpi-grid">
        <div class="kpi"><div class="l">Active rentals</div><div class="v" style="color:#16a34a"><?=$active?></div></div>
        <div class="kpi"><div class="l">Monthly total</div><div class="v">KShs <?=number_format($monthly, 0)?></div></div>
        <div class="kpi"><div class="l">Expired</div><div class="v"><?=$expired?></div></div>
        <div class="kpi"><div class="l">Cancelled</div><div class="v"><?=$cancelled?></div></div>
    </div>

    <?php if (!$rentals): ?>
        <div class="box" style="text-align:center;padding:40px">
            <p class="muted">You don't have any rentals yet.</p>
            <a class="btn" href="<?=BASE?>/properties.php?purpose=rent">Browse rentals</a>
        </div>
    <?php else: ?>
        <?php foreach ($rentals as $r): ?>
            <div class="rental-card">
                <img class="thumb" src="<?=e(rental_img($r))?>" alt="">
                <div class="body">
                    <div class="title"><?=e($r['title'])?></div>
                    <div class="muted"><?=e($r['location'])?> · <?=e($r['ptype'])?></div>
                    <div class="muted" style="margin-top:4px">
                        Started <?=e($r['start_date'])?> · <?=(int)$r['months']?> month(s)
                        · Order <?=e($r['order_ref'])?>
                    </div>
                    <div style="margin-top:8px">
                        <span class="badge <?= $r['status']==='active'?'ok':($r['status']==='expired'?'muted':'bad') ?>">
                            <?=e($r['status'])?>
                        </span>
                    </div>
                </div>
                <div class="right">
                    <div class="price">KShs <?=number_format((float)$r['monthly_rent'], 2)?></div>
                    <div class="muted" style="font-size:.78rem">per month</div>
                    <a class="btn sm ghost" href="<?=BASE?>/track_order.php?id=<?=(int)$r['order_id']?>">
                        Track
                    </a>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</section>
<?php include '../includes/footer.php'; ?>