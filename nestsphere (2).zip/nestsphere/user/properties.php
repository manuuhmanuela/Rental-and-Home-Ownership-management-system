<?php
require '../config.php';
need_login();

$u = user();
$created = isset($_GET['created']);

$mine = q("SELECT * FROM properties WHERE owner_id=? ORDER BY created_at DESC", [$u['id']])->fetchAll();

$byStatus = ['approved'=>0,'pending'=>0,'rejected'=>0,'sold'=>0];
foreach ($mine as $p) {
    if (!isset($byStatus[$p['status']])) $byStatus[$p['status']] = 0;
    $byStatus[$p['status']]++;
}

/* Resolve image path (uploaded file, URL, or placeholder) */
function my_prop_image($p) {
    $v = trim((string)($p['image_url'] ?? ''));
    if ($v === '') {
        return 'https://picsum.photos/seed/' . (int)$p['id'] . '/200/140';
    }
    if (preg_match('#^https?://#i', $v)) return $v;
    if (strpos($v, '/') === 0) return $v;
    return rtrim(BASE, '/') . '/uploads/properties/' . rawurlencode(basename($v));
}

top('My properties');
?>
<style>
    .stat-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
        gap: 12px;
        margin-bottom: 16px;
    }
    .stat {
        background: #fff;
        border: 1px solid #e5e7eb;
        border-radius: 12px;
        padding: 14px 16px;
        box-shadow: 0 2px 8px rgba(15,23,42,.04);
    }
    .stat .l {
        font-size: .72rem;
        text-transform: uppercase;
        letter-spacing: .4px;
        font-weight: 700;
        color: #6b7280;
    }
    .stat .v {
        font-size: 1.35rem;
        font-weight: 800;
        margin-top: 4px;
        color: #111827;
    }
    .stat.ok   .v { color: #16a34a; }
    .stat.warn .v { color: #d97706; }
    .stat.bad  .v { color: #dc2626; }

    .page-head {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 10px;
        margin-bottom: 16px;
    }
    .page-head h1 { margin: 0; }
    .page-head .muted { margin: 4px 0 0; }

    .flash {
        background: #fff;
        border: 1px solid #bbf7d0;
        border-left: 4px solid #16a34a;
        border-radius: 12px;
        padding: 14px 16px;
        margin-bottom: 16px;
    }
    .flash strong { color: #16a34a; }

    .table-wrap {
        overflow-x: auto;
        border-radius: 12px;
        border: 1px solid #e5e7eb;
        background: #fff;
    }
    .table-wrap .tbl { margin: 0; }

    .thumb {
        width: 60px;
        height: 44px;
        object-fit: cover;
        border-radius: 6px;
        border: 1px solid #e5e7eb;
        display: block;
    }

    .badge {
        display: inline-block;
        padding: 2px 8px;
        border-radius: 999px;
        font-size: .7rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: .3px;
    }
    .badge.ok   { background: #dcfce7; color: #166534; }
    .badge.warn { background: #fef3c7; color: #92400e; }
    .badge.bad  { background: #fee2e2; color: #991b1b; }
    .badge.muted{ background: #e5e7eb; color: #374151; }

    .empty-state {
        text-align: center;
        padding: 50px 20px;
        background: #fff;
        border: 1px solid #e5e7eb;
        border-radius: 12px;
    }
    .empty-state h3 { margin: 0 0 8px; }
    .empty-state p  { color: #6b7280; margin: 0 0 16px; }

    @media (max-width: 640px) {
        .page-head { flex-direction: column; align-items: flex-start; }
        .page-head .btn { width: 100%; }
    }
</style>

<section class="wrap">
    <div class="page-head">
        <div>
            <h1>My properties</h1>
            <p class="muted">
                <?=count($mine)?> listing<?=count($mine) === 1 ? '' : 's'?>
            </p>
        </div>
        <a class="btn" href="<?=BASE?>/list_property.php">
            <i class="bi bi-plus-circle"></i> List a new property
        </a>
    </div>

    <?php if ($created): ?>
        <div class="flash">
            <strong>Listing submitted!</strong>
            <div class="muted" style="margin-top:2px">An admin will review your property shortly.</div>
        </div>
    <?php endif; ?>

    <div class="stat-grid">
        <div class="stat ok">
            <div class="l">Approved</div>
            <div class="v"><?=$byStatus['approved']?></div>
        </div>
        <div class="stat warn">
            <div class="l">Pending</div>
            <div class="v"><?=$byStatus['pending']?></div>
        </div>
        <div class="stat bad">
            <div class="l">Rejected</div>
            <div class="v"><?=$byStatus['rejected']?></div>
        </div>
        <div class="stat">
            <div class="l">Sold</div>
            <div class="v"><?=$byStatus['sold']?></div>
        </div>
    </div>

    <?php if (!$mine): ?>
        <div class="empty-state">
            <h3>No listings yet</h3>
            <p>You haven't listed any properties. Start now and reach buyers and renters.</p>
            <a class="btn" href="<?=BASE?>/list_property.php">
                <i class="bi bi-plus-circle"></i> List your first property
            </a>
        </div>
    <?php else: ?>
        <div class="table-wrap">
            <table class="tbl">
                <thead>
                    <tr>
                        <th></th>
                        <th>Property</th>
                        <th>Purpose</th>
                        <th>Type</th>
                        <th>Price</th>
                        <th>Views</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($mine as $p): ?>
                    <tr>
                        <td>
                            <img class="thumb" src="<?=e(my_prop_image($p))?>" alt="">
                        </td>
                        <td>
                            <strong><?=e($p['title'])?></strong><br>
                            <span class="muted" style="font-size:.8rem"><?=e($p['location'])?></span>
                        </td>
                        <td>
                            <span class="badge <?= $p['purpose']==='rent'?'warn':'ok' ?>">
                                <?= $p['purpose'] === 'rent' ? 'Rent' : 'Sale' ?>
                            </span>
                        </td>
                        <td><?=e($p['type'])?></td>
                        <td>
                            KShs <?=number_format((float)$p['price'], 2)?>
                            <?php if ($p['purpose'] === 'rent'): ?>
                                <small class="muted">/mo</small>
                            <?php endif; ?>
                        </td>
                        <td><?=(int)$p['views']?></td>
                        <td>
                            <span class="badge <?= $p['status']==='approved'?'ok':($p['status']==='pending'?'warn':'bad') ?>">
                                <?=e($p['status'])?>
                            </span>
                            <?php if ($p['status'] === 'rejected' && !empty($p['reject_reason'])): ?>
                                <br><small class="bad" style="font-size:.75rem"><?=e($p['reject_reason'])?></small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($p['status'] === 'approved'): ?>
                                <a class="btn sm ghost" href="<?=BASE?>/property.php?id=<?=(int)$p['id']?>">
                                    View public
                                </a>
                            <?php else: ?>
                                <span class="muted">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>
<?php include '../includes/footer.php'; ?>