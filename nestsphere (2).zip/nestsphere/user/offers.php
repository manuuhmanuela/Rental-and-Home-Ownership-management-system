<?php require '../config.php'; need(); $me = user()['id'];
if($_SERVER['REQUEST_METHOD'] === 'POST' && in_array($_POST['do'] ?? '', ['accepted','rejected'])){ check();
  q("UPDATE offers SET status=? WHERE id=? AND status='pending' AND property_id IN (SELECT id FROM properties WHERE owner_id=?)", [$_POST['do'], (int)$_POST['id'], $me]); logit('Offer '.$_POST['do']); flash('Offer '.$_POST['do'].'.'); go('/user/offers.php'); }
$recv = q("SELECT o.*, p.title, u.name, u.phone FROM offers o JOIN properties p ON p.id=o.property_id JOIN users u ON u.id=o.user_id WHERE p.owner_id=? ORDER BY o.id DESC", [$me])->fetchAll();
$sent = q("SELECT o.*, p.title FROM offers o JOIN properties p ON p.id=o.property_id WHERE o.user_id=? ORDER BY o.id DESC", [$me])->fetchAll();
top('Offers'); ?>
<section class="wrap"><h1>Offers</h1><h2>Received on my listings</h2><?php if(!$recv) echo '<p class="empty">No offers yet.</p>'; else { ?><div class="scroll"><table><tr><th>Property</th><th>From</th><th>Offer</th><th>Status</th><th></th></tr>
<?php foreach($recv as $o): ?><tr><td><?=e($o['title'])?></td><td><?=e($o['name'])?><br><span class="muted"><?=e($o['phone'])?></span></td><td><?=kes($o['amount'])?><br><span class="muted"><?=e($o['note'])?></span></td><td><?=pill($o['status'])?></td>
<td class="act"><?php if($o['status']==='pending'): ?><form method="post"><?=field()?><input type="hidden" name="id" value="<?=$o['id']?>"><button name="do" value="accepted" class="btn sm">Accept</button><button name="do" value="rejected" class="btn sm danger">Reject</button></form><?php endif; ?></td></tr><?php endforeach; ?></table></div><?php } ?>
<h2>Made by me</h2><?php if(!$sent) echo '<p class="empty">You have not made an offer yet.</p>'; else { ?><div class="scroll"><table><tr><th>Property</th><th>My offer</th><th>Status</th><th>Date</th></tr>
<?php foreach($sent as $o) echo '<tr><td>'.e($o['title']).'</td><td>'.kes($o['amount']).'</td><td>'.pill($o['status']).'</td><td>'.e($o['created_at']).'</td></tr>'; ?></table></div><?php } ?></section>
<?php include '../includes/footer.php';
