<?php require '../config.php'; need(); $me = user()['id'];
$rows = q("SELECT p.* FROM favourites f JOIN properties p ON p.id=f.property_id WHERE f.user_id=? AND p.status IN ('approved','sold') ORDER BY p.id DESC", [$me])->fetchAll();
top('Favourites'); ?>
<section class="wrap"><h1>Favourites</h1><?php if(!$rows) echo '<p class="empty">No saved properties yet. Open a listing and choose Save to favourites.</p>'; ?>
<div class="grid"><?php foreach($rows as $r) echo card($r); ?></div></section><?php include '../includes/footer.php';
