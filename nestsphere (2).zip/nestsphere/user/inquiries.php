<?php require '../config.php'; need(); $me = user()['id'];
if($_SERVER['REQUEST_METHOD'] === 'POST'){ check(); $r = trim($_POST['reply'] ?? '');
  if($r !== ''){ q("UPDATE inquiries SET reply=? WHERE id=? AND property_id IN (SELECT id FROM properties WHERE owner_id=?)", [$r, (int)$_POST['id'], $me]); logit('Replied to an inquiry'); flash('Reply sent.'); }
  go('/user/inquiries.php'); }
$recv = q("SELECT i.*, p.title, u.name, u.phone FROM inquiries i JOIN properties p ON p.id=i.property_id JOIN users u ON u.id=i.user_id WHERE p.owner_id=? ORDER BY i.id DESC", [$me])->fetchAll();
$sent = q("SELECT i.*, p.title FROM inquiries i JOIN properties p ON p.id=i.property_id WHERE i.user_id=? ORDER BY i.id DESC", [$me])->fetchAll();
top('Inquiries'); ?>
<section class="wrap"><h1>Inquiries</h1><h2>Received on my listings</h2><?php if(!$recv) echo '<p class="empty">No inquiries received yet.</p>'; foreach($recv as $i): ?>
<div class="box"><b><?=e($i['title'])?></b><span class="muted"><?=e($i['name'])?> &middot; <?=e($i['phone'])?> &middot; <?=e($i['created_at'])?></span><p><?=nl2br(e($i['message']))?></p>
<?php if($i['reply']): ?><p class="ok">Your reply: <?=e($i['reply'])?></p><?php else: ?><form method="post"><?=field()?><input type="hidden" name="id" value="<?=$i['id']?>"><label>Reply<textarea name="reply" rows="2" required></textarea></label><button class="btn sm">Send reply</button></form><?php endif; ?></div><?php endforeach; ?>
<h2>Sent by me</h2><?php if(!$sent) echo '<p class="empty">You have not sent any inquiry.</p>'; foreach($sent as $i): ?>
<div class="box"><b><?=e($i['title'])?></b><p><?=nl2br(e($i['message']))?></p><?=$i['reply'] ? '<p class="ok">Reply: '.e($i['reply']).'</p>' : '<p class="muted">Waiting for a reply.</p>'?></div><?php endforeach; ?></section>
<?php include '../includes/footer.php';
