<?php
require '../config.php';
need_login();

$u = user();
$err = '';
$ok  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check();
    $action = $_POST['action'] ?? '';

    if ($action === 'profile') {
        $n = trim($_POST['name'] ?? '');
        $p = trim($_POST['phone'] ?? '');
        $c = trim($_POST['city'] ?? '');
        $b = trim($_POST['bio'] ?? '');
        if ($n === '' || $p === '') {
            $err = 'Name and phone are required.';
        } else {
            q("UPDATE users SET name=?, phone=?, city=?, bio=? WHERE id=?", [$n, $p, $c, $b, $u['id']]);
            $_SESSION['user']['name'] = $n;
            logit('Updated profile');
            $ok = 'Profile saved.';
        }
    }

    if ($action === 'password') {
        $cur = $_POST['current'] ?? '';
        $new = $_POST['new'] ?? '';
        $row = q("SELECT password FROM users WHERE id=?", [$u['id']])->fetch();
        if ($row['password'] !== $cur) {
            $err = 'Current password is incorrect.';
        } elseif (strlen($new) < 6) {
            $err = 'New password must be at least 6 characters.';
        } else {
            q("UPDATE users SET password=? WHERE id=?", [$new, $u['id']]);
            logit('Changed password');
            $ok = 'Password changed.';
        }
    }
}

$row = q("SELECT * FROM users WHERE id=?", [$u['id']])->fetch();

top('My profile');
?>
<section class="wrap narrow">
    <h1>My profile</h1>
    <?php if ($err): ?><div class="box bad"><?=e($err)?></div><?php endif; ?>
    <?php if ($ok): ?><div class="box good"><?=e($ok)?></div><?php endif; ?>

    <form method="post" class="box">
        <?=field()?>
        <input type="hidden" name="action" value="profile">
        <h2>Profile details</h2>

        <label>Name
            <input type="text" name="name" value="<?=e($row['name'])?>" required>
        </label>
        <label>Email
            <input type="email" value="<?=e($row['email'])?>" disabled>
        </label>
        <label>Phone
            <input type="text" name="phone" value="<?=e($row['phone'])?>" required>
        </label>
        <label>City
            <input type="text" name="city" value="<?=e($row['city'])?>">
        </label>
        <label>Bio
            <textarea name="bio" rows="4"><?=e($row['bio'])?></textarea>
        </label>

        <button class="btn">Save profile</button>
    </form>

    <form method="post" class="box">
        <?=field()?>
        <input type="hidden" name="action" value="password">
        <h2>Change password</h2>

        <label>Current password
            <input type="password" name="current" required>
        </label>
        <label>New password
            <input type="password" name="new" required minlength="6">
        </label>

        <button class="btn">Change password</button>
    </form>
</section>
<?php include '../includes/footer.php'; ?>