<?php require '../config.php'; need(); $me = user()['id']; $id = (int)($_GET['id'] ?? 0); $err = [];
$p = ['title'=>'','type'=>'Apartment','purpose'=>'sale','location'=>'','price'=>'','bedrooms'=>0,'bathrooms'=>0,'size'=>'','description'=>'','image_url'=>''];
if($id){ $r = q("SELECT * FROM properties WHERE id=? AND owner_id=?", [$id, $me])->fetch(); if(!$r){ http_response_code(404); exit('Listing not found'); } $p = $r; }
if($_SERVER['REQUEST_METHOD'] === 'POST'){ check(); $p = array_merge($p, array_map('trim', array_intersect_key($_POST, $p)));
  if(strlen($p['title']) < 5) $err[] = 'Enter a title of at least 5 characters.';
  if(!$p['location']) $err[] = 'Enter the location.';
  if((float)$p['price'] <= 0) $err[] = 'Enter a price above zero.';
  if(!in_array($p['type'], TYPES) || !in_array($p['purpose'], ['sale','rent'])) $err[] = 'Choose a valid type and purpose.';
  $img = upload($_FILES['image'] ?? []); if($img === false) $err[] = 'Photo must be a JPG, PNG or WebP under 2 MB.';
  if(!$err){ $url = $img ?: ($p['image_url'] ?: 'https://picsum.photos/seed/'.rand(1,999).'/800/500'); $a = [$p['title'],$p['type'],$p['purpose'],$p['location'],(float)$p['price'],(int)$p['bedrooms'],(int)$p['bathrooms'],$p['size'],$p['description'],$url];
    if($id){ q("UPDATE properties SET title=?,type=?,purpose=?,location=?,price=?,bedrooms=?,bathrooms=?,size=?,description=?,image_url=?,status='pending',reject_reason=NULL WHERE id=? AND owner_id=?", array_merge($a, [$id, $me])); logit("Edited listing #$id"); flash('Listing updated and sent for re-approval.'); }
    else { q("INSERT INTO properties(owner_id,title,type,purpose,location,price,bedrooms,bathrooms,size,description,image_url) VALUES(?,?,?,?,?,?,?,?,?,?,?)", array_merge([$me], $a)); logit('Submitted a new listing'); flash('Listing submitted. It goes live once an admin approves it.'); }
    go('/user/my_listings.php'); }
}
top($id ? 'Edit listing' : 'List a property'); ?>
<section class="wrap narrow2"><h1><?=$id ? 'Edit listing' : 'List a property'?></h1><?php foreach($err as $x) echo '<p class="bad">'.e($x).'</p>'; ?>
<form method="post" enctype="multipart/form-data" class="box two"><?=field()?>
<label>Title<input name="title" required value="<?=e($p['title'])?>"></label><label>Location<input name="location" required placeholder="Kilimani, Nairobi" value="<?=e($p['location'])?>"></label>
<label>Property type<select name="type"><?=opts(TYPES, $p['type'])?></select></label>
<label>Purpose<select name="purpose"><option value="sale"<?=$p['purpose']==='sale'?' selected':''?>>For sale</option><option value="rent"<?=$p['purpose']==='rent'?' selected':''?>>For rent (per month)</option></select></label>
<label>Price (KES)<input type="number" name="price" min="1" required value="<?=e($p['price'])?>"></label><label>Size<input name="size" placeholder="120 sqm or 0.25 acre" value="<?=e($p['size'])?>"></label>
<label>Bedrooms<input type="number" name="bedrooms" min="0" value="<?=(int)$p['bedrooms']?>"></label><label>Bathrooms<input type="number" name="bathrooms" min="0" value="<?=(int)$p['bathrooms']?>"></label>
<label class="full">Photo (JPG, PNG or WebP, max 2 MB)<input type="file" name="image" accept="image/jpeg,image/png,image/webp"></label>
<label class="full">Description<textarea name="description" rows="5"><?=e($p['description'])?></textarea></label><button class="btn">Submit for approval</button></form></section>
<?php include '../includes/footer.php';
