<?php require '../config.php'; need(); $me = user()['id'];
if($_SERVER['REQUEST_METHOD'] === 'POST'){ check(); $id = (int)$_POST['id'];
  if($_POST['do'] === 'sold'){ q("UPDATE properties SET status='sold' WHERE id=? AND owner_id=? AND status='approved'", [$id, $me]); logit("Marked listing #$id as sold"); flash('Marked as sold.'); }
  if($_POST['do'] === 'delete'){ q("DELETE FROM properties WHERE id=? AND owner_id=?", [$id, $me]); logit("Deleted listing #$id"); flash('Listing deleted.'); }
  go('/user/my_listings.php'); }
$rows = q("SELECT p.*, (SELECT COUNT(*) FROM inquiries WHERE property_id=p.id) inq, (SELECT COUNT(*) FROM offers WHERE property_id=p.id) off FROM properties p WHERE owner_id=? ORDER BY id DESC", [$me])->fetchAll();
$step = ['pending'=>1,'approved'=>2,'sold'=>3,'rejected'=>1];
top('My listings'); ?>
<section class="wrap"><h1>My listings</h1><p><a class="btn" href="<?=BASE?>/user/add_listing.php">List a property</a></p>
<?php if(!$rows) echo '<p class="empty">You have not listed a property yet.</p>'; else { ?><div class="scroll"><table><tr><th>Building</th><th>Track status</th><th>Views</th><th>Inquiries</th><th>Offers</th><th>Actions</th></tr>
<?php foreach($rows as $r): $s = $step[$r['status']]; ?><tr><td><a href="<?=BASE?>/property.php?id=<?=$r['id']?>"><?=e($r['title'])?></a><br><span class="muted"><?=e($r['location'])?> &middot; <?=kes($r['price'])?></span></td>
<td><ol class="steps"><li class="<?=$s>=1?'on':''?>">Submitted</li><li class="<?=$s>=2?'on':''?>">Live</li><li class="<?=$s>=3?'on':''?>">Sold</li></ol><?=pill($r['status'])?>
<?php if($r['status']==='rejected') echo '<br><span class="muted">Reason: '.e($r['reject_reason'] ?: 'Not specified').'</span>'; ?></td>
<td><?=(int)$r['views']?></td><td><?=$r['inq']?></td><td><?=$r['off']?></td>
<td class="act"><a class="btn sm alt" href="<?=BASE?>/user/add_listing.php?id=<?=$r['id']?>">Edit</a>
<form method="post"><?=field()?><input type="hidden" name="id" value="<?=$r['id']?>"><?php if($r['status']==='approved'): ?><button name="do" value="sold" class="btn sm">Mark sold</button><?php endif; ?>
<button name="do" value="delete" class="btn sm danger" onclick="return confirm('Delete this listing?')">Delete</button></form></td></tr><?php endforeach; ?></table></div><?php } ?></section>
<?php include '../includes/footer.php';
