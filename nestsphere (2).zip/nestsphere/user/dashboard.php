<?php
require '../config.php';
require '../includes/cart_helpers.php';
need_login();

$u = user();

/* ─────────── STATS ─────────── */
$myProps     = (int)q("SELECT COUNT(*) FROM properties WHERE owner_id=?", [$u['id']])->fetchColumn();
$myFavs      = (int)q("SELECT COUNT(*) FROM favourites WHERE user_id=?", [$u['id']])->fetchColumn();
$myInquiries = (int)q("SELECT COUNT(*) FROM inquiries WHERE user_id=?", [$u['id']])->fetchColumn();
$myOffers    = (int)q("SELECT COUNT(*) FROM offers WHERE user_id=?", [$u['id']])->fetchColumn();
$myOrders    = (int)q("SELECT COUNT(*) FROM orders WHERE user_id=?", [$u['id']])->fetchColumn();
$myPaid      = (int)q("SELECT COUNT(*) FROM orders WHERE user_id=? AND status='paid'", [$u['id']])->fetchColumn();
$myRentals   = (int)q("SELECT COUNT(*) FROM rentals WHERE user_id=? AND status='active'", [$u['id']])->fetchColumn();
$mySpend     = (float)q("SELECT COALESCE(SUM(total_amount),0) FROM orders WHERE user_id=? AND status='paid'", [$u['id']])->fetchColumn();

$myApproved  = (int)q("SELECT COUNT(*) FROM properties WHERE owner_id=? AND status='approved'", [$u['id']])->fetchColumn();
$myPending   = (int)q("SELECT COUNT(*) FROM properties WHERE owner_id=? AND status='pending'", [$u['id']])->fetchColumn();

/* ─────────── RECENT ─────────── */
$recentOrders  = q("SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC LIMIT 5", [$u['id']])->fetchAll();
$recentProps   = q("SELECT * FROM properties WHERE owner_id=? ORDER BY created_at DESC LIMIT 5", [$u['id']])->fetchAll();
$recentInq     = q("SELECT i.*, p.title FROM inquiries i JOIN properties p ON p.id=i.property_id WHERE i.user_id=? ORDER BY i.created_at DESC LIMIT 5", [$u['id']])->fetchAll();
$recentRentals = q("SELECT r.*, p.title FROM rentals r JOIN properties p ON p.id=r.property_id WHERE r.user_id=? ORDER BY r.created_at DESC LIMIT 5", [$u['id']])->fetchAll();

top('My Dashboard');
?>
<style>
    .dash-head {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 10px;
        margin-bottom: 16px;
    }
    .dash-head h1 { margin: 0; }
    .dash-head .muted { margin: 4px 0 0; }

    .kpi-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
        gap: 12px;
        margin-bottom: 18px;
    }
    .kpi {
        background: #fff;
        border: 1px solid #e5e7eb;
        border-radius: 12px;
        padding: 14px 16px;
        box-shadow: 0 2px 8px rgba(15,23,42,.04);
        position: relative;
        overflow: hidden;
    }
    .kpi::before {
        content: "";
        position: absolute;
        left: 0; top: 0; bottom: 0;
        width: 4px;
        background: #2563eb;
    }
    .kpi.green::before { background: #16a34a; }
    .kpi.amber::before { background: #d97706; }
    .kpi.violet::before{ background: #7c3aed; }
    .kpi .l {
        font-size: .7rem;
        text-transform: uppercase;
        letter-spacing: .4px;
        color: #6b7280;
        font-weight: 700;
    }
    .kpi .v {
        font-size: 1.4rem;
        font-weight: 800;
        margin-top: 4px;
        color: #111827;
        line-height: 1.2;
    }
    .kpi .s { font-size: .76rem; color: #6b7280; margin-top: 2px; }

    .panel {
        background: #fff;
        border: 1px solid #e5e7eb;
        border-radius: 12px;
        padding: 18px;
        margin-bottom: 16px;
        box-shadow: 0 2px 8px rgba(15,23,42,.04);
    }
    .panel h2 {
        font-size: 1rem;
        margin: 0 0 12px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 8px;
    }
    .panel h2 a {
        font-size: .78rem;
        font-weight: 600;
    }
    .panel .empty {
        color: #9ca3af;
        font-size: .9rem;
        padding: 10px 0;
        text-align: center;
    }

    .mini {
        width: 100%;
        border-collapse: collapse;
        font-size: .85rem;
    }
    .mini th {
        text-align: left;
        font-size: .7rem;
        text-transform: uppercase;
        letter-spacing: .4px;
        color: #6b7280;
        padding: 6px 8px;
        border-bottom: 1px solid #e5e7eb;
    }
    .mini td {
        padding: 8px;
        border-bottom: 1px solid #f1f5f9;
        vertical-align: top;
    }
    .mini tr:last-child td { border-bottom: none; }

    .quick-links {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
        gap: 10px;
    }
    .quick-link {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 12px 14px;
        border: 1px solid #e5e7eb;
        border-radius: 10px;
        background: #f9fafb;
        color: #111827;
        text-decoration: none;
        transition: background .15s, border-color .15s;
    }
    .quick-link:hover { background: #eff6ff; border-color: #bfdbfe; color: #111827; text-decoration: none; }
    .quick-link .icon {
        width: 34px; height: 34px;
        border-radius: 8px;
        display: flex; align-items: center; justify-content: center;
        background: #dbeafe; color: #1e40af;
        font-size: 1rem;
        flex-shrink: 0;
    }
    .quick-link .text { font-size: .85rem; font-weight: 600; }
    .quick-link .sub  { font-size: .72rem; color: #6b7280; }

    .two-col {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
        gap: 16px;
    }

    @media (max-width: 640px) {
        .dash-head { flex-direction: column; align-items: flex-start; }
    }
</style>

<section class="wrap">
    <div class="dash-head">
        <div>
            <h1>Welcome, <?=e($u['name'])?></h1>
            <p class="muted">Here's what's happening on your account</p>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
            <a class="btn" href="<?=BASE?>/list_property.php">
                <i class="bi bi-plus-circle"></i> List a property
            </a>
            <a class="btn ghost" href="<?=BASE?>/properties.php">
                <i class="bi bi-search"></i> Browse
            </a>
        </div>
    </div>

    <!-- KPI GRID -->
    <div class="kpi-grid">
        <div class="kpi green">
            <div class="l">Active rentals</div>
            <div class="v"><?=$myRentals?></div>
            <div class="s">Ongoing leases</div>
        </div>
        <div class="kpi">
            <div class="l">Orders</div>
            <div class="v"><?=$myOrders?></div>
            <div class="s"><?=$myPaid?> paid</div>
        </div>
        <div class="kpi violet">
            <div class="l">Total paid</div>
            <div class="v">KShs <?=number_format($mySpend, 0)?></div>
            <div class="s">Across all orders</div>
        </div>
        <div class="kpi amber">
            <div class="l">Favourites</div>
            <div class="v"><?=$myFavs?></div>
            <div class="s">Saved properties</div>
        </div>
        <div class="kpi">
            <div class="l">My listings</div>
            <div class="v"><?=$myProps?></div>
            <div class="s"><?=$myApproved?> approved · <?=$myPending?> pending</div>
        </div>
        <div class="kpi">
            <div class="l">Inquiries &amp; offers</div>
            <div class="v"><?=$myInquiries + $myOffers?></div>
            <div class="s"><?=$myInquiries?> inquiries · <?=$myOffers?> offers</div>
        </div>
    </div>

    <!-- QUICK ACTIONS -->
    <div class="panel">
        <h2>Quick actions</h2>
        <div class="quick-links">
            <a class="quick-link" href="<?=BASE?>/list_property.php">
                <div class="icon"><i class="bi bi-plus-circle"></i></div>
                <div>
                    <div class="text">List a property</div>
                    <div class="sub">Sell or rent it out</div>
                </div>
            </a>
            <a class="quick-link" href="<?=BASE?>/user/properties.php">
                <div class="icon"><i class="bi bi-house-gear"></i></div>
                <div>
                    <div class="text">My listings</div>
                    <div class="sub"><?=$myProps?> total</div>
                </div>
            </a>
            <a class="quick-link" href="<?=BASE?>/properties.php">
                <div class="icon"><i class="bi bi-search"></i></div>
                <div>
                    <div class="text">Browse</div>
                    <div class="sub">Buy or rent</div>
                </div>
            </a>
            <a class="quick-link" href="<?=BASE?>/cart.php">
                <div class="icon"><i class="bi bi-cart3"></i></div>
                <div>
                    <div class="text">My cart</div>
                    <div class="sub">Ready to checkout</div>
                </div>
            </a>
            <a class="quick-link" href="<?=BASE?>/user/profile.php">
                <div class="icon"><i class="bi bi-person-gear"></i></div>
                <div>
                    <div class="text">Profile</div>
                    <div class="sub">Edit details</div>
                </div>
            </a>
        </div>
    </div>

    <!-- RECENT ORDERS -->
    <div class="panel">
        <h2>
            Recent orders
            <a href="<?=BASE?>/user/orders.php">View all</a>
        </h2>
        <?php if (!$recentOrders): ?>
            <div class="empty">No orders yet. <a href="<?=BASE?>/properties.php">Start browsing</a>.</div>
        <?php else: ?>
            <div style="overflow-x:auto">
                <table class="mini">
                    <thead><tr><th>Ref</th><th>Type</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead>
                    <tbody>
                    <?php foreach ($recentOrders as $o): ?>
                        <tr>
                            <td><strong><?=e($o['order_ref'])?></strong></td>
                            <td><?=ucfirst(e($o['order_type']))?></td>
                            <td>KShs <?=number_format((float)$o['total_amount'], 2)?></td>
                            <td>
                                <span class="badge <?= $o['status']==='paid'?'ok':($o['status']==='pending'?'warn':'bad') ?>">
                                    <?=e($o['status'])?>
                                </span>
                            </td>
                            <td class="muted"><?=date('d M Y', strtotime($o['created_at']))?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

    <!-- TWO-COLUMN: rentals & listings -->
    <div class="two-col">
        <div class="panel">
            <h2>My rentals</h2>
            <?php if (!$recentRentals): ?>
                <div class="empty">No rentals yet.</div>
            <?php else: ?>
                <table class="mini">
                    <thead><tr><th>Property</th><th>Rent</th><th>Status</th></tr></thead>
                    <tbody>
                    <?php foreach ($recentRentals as $r): ?>
                        <tr>
                            <td><?=e($r['title'])?></td>
                            <td>KShs <?=number_format((float)$r['monthly_rent'], 2)?>/mo</td>
                            <td>
                                <span class="badge <?= $r['status']==='active'?'ok':($r['status']==='expired'?'muted':'bad') ?>">
                                    <?=e($r['status'])?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <div class="panel">
            <h2>
                My listings
                <a href="<?=BASE?>/user/properties.php">Manage</a>
            </h2>
            <?php if (!$recentProps): ?>
                <div class="empty">
                    No listings yet. <a href="<?=BASE?>/list_property.php">List one now</a>.
                </div>
            <?php else: ?>
                <table class="mini">
                    <thead><tr><th>Title</th><th>Price</th><th>Status</th></tr></thead>
                    <tbody>
                    <?php foreach ($recentProps as $p): ?>
                        <tr>
                            <td><?=e($p['title'])?></td>
                            <td>
                                KShs <?=number_format((float)$p['price'], 0)?>
                                <?= $p['purpose']==='rent' ? '<small class="muted">/mo</small>' : '' ?>
                            </td>
                            <td>
                                <span class="badge <?= $p['status']==='approved'?'ok':($p['status']==='pending'?'warn':'bad') ?>">
                                    <?=e($p['status'])?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>

    <!-- RECENT INQUIRIES -->
    <div class="panel">
        <h2>Recent inquiries</h2>
        <?php if (!$recentInq): ?>
            <div class="empty">No inquiries yet.</div>
        <?php else: ?>
            <table class="mini">
                <thead><tr><th>Property</th><th>Message</th><th>Reply</th><th>Date</th></tr></thead>
                <tbody>
                <?php foreach ($recentInq as $i): ?>
                    <tr>
                        <td><?=e($i['title'])?></td>
                        <td style="max-width:320px"><?=e(mb_strimwidth($i['message'], 0, 90, '…'))?></td>
                        <td style="max-width:320px">
                            <?= $i['reply'] ? e(mb_strimwidth($i['reply'], 0, 90, '…')) : '<span class="muted">Pending</span>' ?>
                        </td>
                        <td class="muted"><?=date('d M Y', strtotime($i['created_at']))?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</section>
<?php include '../includes/footer.php'; ?>