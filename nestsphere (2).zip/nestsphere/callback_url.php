<?php
/*
==========================================================================
  M-PESA CALLBACK — callback_url.php
==========================================================================
  Safaricom calls this URL after the customer enters their PIN.
  This file receives the result and saves the transaction.

  IMPORTANT: This URL MUST be:
    - Publicly accessible on the internet (not localhost)
    - HTTPS (required by Safaricom for live transactions)
    - Not password-protected

  OPTIONAL: Connect to your database below to save transactions.
==========================================================================
*/

header('Content-Type: application/json');

// Read raw input from Safaricom
$mpesaResponse = file_get_contents('php://input');

// Always log everything — useful for debugging
$logFile = __DIR__ . '/mpesa_transactions.log';
file_put_contents($logFile, date('Y-m-d H:i:s') . " | " . $mpesaResponse . PHP_EOL, FILE_APPEND);

// Decode the callback data
$data = json_decode($mpesaResponse, true);

if (isset($data['Body']['stkCallback'])) {
    $callback       = $data['Body']['stkCallback'];
    $ResultCode     = $callback['ResultCode'];
    $ResultDesc     = $callback['ResultDesc'];
    $MerchantRequestID = $callback['MerchantRequestID'] ?? '';
    $CheckoutRequestID = $callback['CheckoutRequestID'] ?? '';

    if ($ResultCode == 0) {
        // ── Payment SUCCESSFUL ──
        $metadata = $callback['CallbackMetadata']['Item'] ?? [];

        $fields = [];
        foreach ($metadata as $item) {
            $fields[$item['Name']] = $item['Value'] ?? '';
        }

        $amount          = $fields['Amount']            ?? '';
        $mpesaReceiptNo  = $fields['MpesaReceiptNumber'] ?? '';
        $transactionDate = $fields['TransactionDate']   ?? '';
        $phoneNumber     = $fields['PhoneNumber']       ?? '';

        /*
        ================================================================
          SAVE TO DATABASE (optional — uncomment and fill in your DB)
        ================================================================
        $pdo = new PDO('mysql:host=localhost;dbname=YOUR_DB', 'DB_USER', 'DB_PASS');
        $stmt = $pdo->prepare("
            INSERT INTO mpesa_payments
              (receipt_no, phone, amount, transaction_date, checkout_request_id, created_at)
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([$mpesaReceiptNo, $phoneNumber, $amount, $transactionDate, $CheckoutRequestID]);
        ================================================================
        */

        // Log success details
        $successLog = "SUCCESS | Receipt: $mpesaReceiptNo | Amount: $amount | Phone: $phoneNumber | Date: $transactionDate\n";
        file_put_contents($logFile, date('Y-m-d H:i:s') . " | " . $successLog, FILE_APPEND);

    } else {
        // ── Payment FAILED or CANCELLED ──
        $failLog = "FAILED | Code: $ResultCode | Desc: $ResultDesc | CheckoutID: $CheckoutRequestID\n";
        file_put_contents($logFile, date('Y-m-d H:i:s') . " | " . $failLog, FILE_APPEND);
    }
}

// Respond to Safaricom — always send this, even on failure
echo json_encode([
    'ResultCode' => 0,
    'ResultDesc' => 'Callback received successfully'
]);
