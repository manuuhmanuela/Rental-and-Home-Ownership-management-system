<?php
require 'config.php';
require 'includes/cart_helpers.php';

$featured = q("SELECT p.*, u.name AS owner_name
               FROM properties p
               JOIN users u ON u.id = p.owner_id
               WHERE p.status='approved' AND p.featured=1
               ORDER BY p.created_at DESC
               LIMIT 6")->fetchAll();

top('Welcome');
?>

<section style="background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:#fff;padding:50px 20px;border-radius:0 0 24px 24px;margin-bottom:24px">
    <div class="wrap" style="text-align:center">
        <h1 style="font-size:clamp(1.6rem,4vw,2.6rem);margin:0 0 10px">Find your next home</h1>
        <p style="opacity:.9;margin:0 0 20px;font-size:1.05rem">Buy, rent and manage property across Kenya — all in one place.</p>
        <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap">
            <a class="btn" style="background:#fff;color:#2563eb" href="<?=BASE?>/properties.php">
                <i class="bi bi-search"></i> Browse properties
            </a>
            <?php if (!user()): ?>
                <a class="btn ghost" style="background:rgba(255,255,255,.15);color:#fff;border:1px solid rgba(255,255,255,.4)" href="<?=BASE?>/register.php">
                    <i class="bi bi-person-plus"></i> Create account
                </a>
            <?php endif; ?>
        </div>
    </div>
</section>

<section class="wrap">
    <h2 style="margin-top:0">Featured properties</h2>
    <?php if (!$featured): ?>
        <div class="box"><p class="muted">No featured properties yet.</p></div>
    <?php else: ?>
        <div class="grid">
            <?php foreach ($featured as $p): ?>
                <a href="<?=BASE?>/property.php?id=<?=(int)$p['id']?>" class="box" style="text-decoration:none;color:inherit;display:block">
                    <img src="<?=e($p['image_url'] ?: 'https://picsum.photos/seed/'.$p['id'].'/600/400')?>"
                         alt="" style="width:100%;height:160px;object-fit:cover;border-radius:8px;margin-bottom:10px">
                    <strong style="display:block;font-size:1rem;margin-bottom:4px"><?=e($p['title'])?></strong>
                    <div class="muted" style="font-size:.85rem"><?=e($p['location'])?></div>
                    <div style="margin-top:8px;font-weight:700;color:#2563eb">
                        KShs <?=number_format((float)$p['price'])?>
                        <?php if ($p['purpose']==='rent'): ?><small>/month</small><?php endif; ?>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</section>

<?php include 'includes/footer.php'; ?>