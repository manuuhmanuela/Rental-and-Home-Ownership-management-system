<?php
/*
==========================================================================
  M-PESA STK PUSH — stk_initiate.php
==========================================================================

  HOW MONEY COMES TO YOUR ACCOUNT (254724753730)
  ------------------------------------------------
  You have TWO options. Choose ONE:

  OPTION A — TILL NUMBER (Buy Goods):
    - Register a Till Number at any Safaricom dealer or via MySafaricom app
    - Money lands directly in your M-PESA wallet linked to that till
    - Set $TransactionType = 'CustomerBuyGoodsOnline'
    - Set $PartyB = your Till Number
    - BusinessShortCode = your Till Number too

  OPTION B — PAYBILL (most common for businesses):
    - Register a Paybill at safaricom.co.ke or dealer
    - Money lands in a Business Till you withdraw from
    - Set $TransactionType = 'CustomerPayBillOnline'
    - Set $PartyB = your Paybill number
    - $AccountReference = your customer/invoice reference

  SANDBOX vs LIVE:
    Sandbox = test only, no real money moves
    Live = real transactions — change the URLs below

  CURRENT SETUP: SANDBOX (for testing)
  To go live: flip $LIVE = true; to $LIVE = true; and fill in your live credentials.

==========================================================================
*/

header('Content-Type: application/json');

if (!isset($_POST['submit'])) {
    echo json_encode(['errorMessage' => 'Invalid request']);
    exit;
}

/* =====================================================================
   1. TOGGLE SANDBOX vs LIVE
   ===================================================================== */
$LIVE = false;   // ← Set to TRUE when you go to production

/* =====================================================================
   2. YOUR CREDENTIALS
   Fill in your OWN Daraja app credentials here.
   Get them from: https://developer.safaricom.co.ke
   ===================================================================== */
if ($LIVE) {
    // ── LIVE credentials (from your production Daraja app) ──
    $consumerKey    = 'uD4AfyBoRRjf1XNYXprcPrquDBiCLjM9R2mLbI5ljFA0Cp3O';
    $consumerSecret = 'zF3lW9yerjTAF5TVy1fXm7e2Gti2S6BcEhMli12DPCBiNtyyjXoiRqyAtyuBMJVZ';
    $access_token_url = 'https://api.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';
    $initiate_url     = 'https://api.safaricom.co.ke/mpesa/stkpush/v1/processrequest';
    $CallBackURL      = 'https://yourdomain.co.ke/callback_url.php'; // ← your live HTTPS callback
} else {
    // ── SANDBOX credentials (for testing only) ──
    $consumerKey    = 'nk16Y74eSbTaGQgc9WF8j6FigApqOMWr';
    $consumerSecret = '40fD1vRXCq90XFaU';
    $access_token_url = 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';
    $initiate_url     = 'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest';
    $CallBackURL      = 'https://morning-basin-87523.herokuapp.com/callback_url.php';
}

/* =====================================================================
   3. YOUR TILL / PAYBILL DETAILS
   =====================================================================

   TO RECEIVE MONEY ON 254724753730:
   ----------------------------------
   You need to register a Safaricom Till Number or Paybill linked to
   your phone number. Then replace the values below.

   SANDBOX TEST VALUES (do not change for sandbox testing):
     BusinessShortCode = 174379
     Passkey = bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919

   LIVE VALUES (replace with yours when going live):
     BusinessShortCode = your actual Till or Paybill number
     Passkey = the passkey Safaricom gives you for your live app
*/

if ($LIVE) {
    $BusinessShortCode = 'YOUR_TILL_OR_PAYBILL_NUMBER';  // e.g. 522533 or 400200
    $Passkey = 'YOUR_LIVE_PASSKEY_FROM_SAFARICOM';

    /*
      CHOOSE your transaction type:
        'CustomerBuyGoodsOnline'  → Till Number  (money to your M-PESA wallet)
        'CustomerPayBillOnline'   → Paybill       (money to your business account)
    */
    $TransactionType = 'CustomerBuyGoodsOnline'; // ← change to match your setup

    /*
      PartyB:
        For Till:    your Till Number
        For Paybill: your Paybill Number
    */
    $PartyB = 'YOUR_TILL_OR_PAYBILL_NUMBER';

} else {
    // Sandbox test credentials — leave as-is
    $BusinessShortCode = '174379';
    $Passkey = 'bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919';
    $TransactionType = 'CustomerPayBillOnline';
    $PartyB = $BusinessShortCode;
}

/* =====================================================================
   4. TRANSACTION DETAILS (from form)
   ===================================================================== */
date_default_timezone_set('Africa/Nairobi');

$Amount    = intval($_POST['amount']);   // M-PESA requires whole numbers
$PartyA    = trim($_POST['phone']);      // Customer's phone e.g. 254712345678
$AccountReference = 'Payment';          // Change to your invoice/order ref if needed
$TransactionDesc  = 'Payment';

/* =====================================================================
   5. GENERATE PASSWORD & TIMESTAMP
   ===================================================================== */
$Timestamp = date('YmdHis');
$Password  = base64_encode($BusinessShortCode . $Passkey . $Timestamp);

/* =====================================================================
   6. GET ACCESS TOKEN
   ===================================================================== */
$curl = curl_init($access_token_url);
curl_setopt_array($curl, [
    CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HEADER         => false,
    CURLOPT_USERPWD        => $consumerKey . ':' . $consumerSecret,
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_TIMEOUT        => 30,
]);
$tokenResult = curl_exec($curl);
$httpCode    = curl_getinfo($curl, CURLINFO_HTTP_CODE);
curl_close($curl);

if ($httpCode !== 200) {
    echo json_encode(['errorMessage' => 'Could not get access token. Check your credentials.', 'httpCode' => $httpCode]);
    exit;
}

$tokenData    = json_decode($tokenResult);
$access_token = $tokenData->access_token ?? '';

if (empty($access_token)) {
    echo json_encode(['errorMessage' => 'Empty access token received.']);
    exit;
}

/* =====================================================================
   7. INITIATE STK PUSH
   ===================================================================== */
$payload = [
    'BusinessShortCode' => $BusinessShortCode,
    'Password'          => $Password,
    'Timestamp'         => $Timestamp,
    'TransactionType'   => $TransactionType,
    'Amount'            => $Amount,
    'PartyA'            => $PartyA,
    'PartyB'            => $PartyB,
    'PhoneNumber'       => $PartyA,
    'CallBackURL'       => $CallBackURL,
    'AccountReference'  => $AccountReference,
    'TransactionDesc'   => $TransactionDesc,
];

$curl = curl_init($initiate_url);
curl_setopt_array($curl, [
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $access_token,
    ],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => json_encode($payload),
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_TIMEOUT        => 30,
]);
$response = curl_exec($curl);
curl_close($curl);

// Return the raw M-PESA response as JSON to the frontend
echo $response;
