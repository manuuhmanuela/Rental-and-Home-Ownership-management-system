<?php include __DIR__.'/head.php'; $unread = n("SELECT COUNT(*) FROM messages WHERE is_read=0"); ?>
<body><header class="nav adm"><a class="logo" href="<?=BASE?>/admin/">NestSphere Admin</a>
<input type="checkbox" id="m"><label for="m" class="burger">&#9776;</label>
<nav><a href="<?=BASE?>/">View site</a><span class="who"><?=e(user()['name'])?> (admin)</span><a class="btn" href="<?=BASE?>/logout.php">Log out</a></nav></header>
<div class="sub"><a href="<?=BASE?>/admin/">Dashboard</a><a href="<?=BASE?>/admin/listings.php">Track listings</a><a href="<?=BASE?>/admin/users.php">Users</a><a href="<?=BASE?>/admin/inquiries.php">Inquiries</a><a href="<?=BASE?>/admin/offers.php">Offers</a><a href="<?=BASE?>/admin/messages.php">Messages<?=$unread ? ' ('.$unread.')' : ''?></a><a href="<?=BASE?>/admin/activity.php">Activity log</a><a href="<?=BASE?>/admin/profile.php">My profile</a></div><main><?=flash()?>
