<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function cart_get() {
    if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    return $_SESSION['cart'];
}

function cart_add($property_id, $type = 'purchase', $months = 1, $price = 0, $title = '', $location = '', $image = '') {
    $property_id = (int)$property_id;
    $type = $type === 'rental' ? 'rental' : 'purchase';
    $months = max(1, (int)$months);

    $cart = cart_get();
    $key = $property_id . ':' . $type;

    if (isset($cart[$key])) {
        if ($type === 'rental') {
            $cart[$key]['months'] = $months;
        }
    } else {
        $cart[$key] = [
            'property_id' => $property_id,
            'type'        => $type,
            'months'      => $months,
            'price'       => (float)$price,
            'title'       => $title,
            'location'    => $location,
            'image'       => $image,
        ];
    }
    $_SESSION['cart'] = $cart;
}

function cart_update($key, $months) {
    $cart = cart_get();
    if (isset($cart[$key]) && $cart[$key]['type'] === 'rental') {
        $cart[$key]['months'] = max(1, (int)$months);
        $_SESSION['cart'] = $cart;
    }
}

function cart_remove($key) {
    $cart = cart_get();
    unset($cart[$key]);
    $_SESSION['cart'] = $cart;
}

function cart_clear() {
    $_SESSION['cart'] = [];
}

function line_subtotal($item) {
    if ($item['type'] === 'rental') {
        return (float)$item['price'] * (int)$item['months'];
    }
    return (float)$item['price'];
}

function cart_totals() {
    $cart = cart_get();
    $total = 0.0;
    $hasPurchase = false;
    $hasRental   = false;

    foreach ($cart as $item) {
        $total += line_subtotal($item);
        if ($item['type'] === 'rental') $hasRental = true;
        else $hasPurchase = true;
    }

    $type = 'purchase';
    if ($hasPurchase && $hasRental) $type = 'mixed';
    elseif ($hasRental) $type = 'rental';

    return [
        'total' => $total,
        'count' => count($cart),
        'type'  => $type,
        'items' => $cart,
    ];
}

function make_order_ref() {
    return 'NS-' . date('YmdHis') . '-' . strtoupper(bin2hex(random_bytes(3)));
}