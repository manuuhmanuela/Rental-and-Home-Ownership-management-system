</main>

<footer style="background:#fff;border-top:1px solid #e5e7eb;padding:20px;text-align:center;color:#6b7280;font-size:.85rem;margin-top:40px">
    <div style="max-width:1180px;margin:0 auto;display:flex;flex-wrap:wrap;gap:10px;justify-content:space-between;align-items:center">
        <div>&copy; <?= date('Y') ?> <strong style="color:#1f2937">NestSphere</strong> — Buy, rent and manage property in Kenya.</div>
        <div style="display:flex;gap:14px;flex-wrap:wrap">
            <a href="<?= defined('BASE') ? BASE : '' ?>/properties.php" style="color:#6b7280">Browse</a>
            <a href="<?= defined('BASE') ? BASE : '' ?>/login.php" style="color:#6b7280">Log in</a>
            <a href="<?= defined('BASE') ? BASE : '' ?>/register.php" style="color:#6b7280">Register</a>
        </div>
    </div>
</footer>

</body>
</html>