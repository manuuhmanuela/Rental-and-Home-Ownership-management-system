<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=e($t)?> | NestSphere</title><link rel="stylesheet" href="<?=BASE?>/assets/style.css"></head>
