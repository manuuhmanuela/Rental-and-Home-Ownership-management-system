<?php include __DIR__.'/head.php'; ?>
<body><header class="nav pub"><a class="logo" href="<?=BASE?>/">NestSphere</a>
<input type="checkbox" id="m"><label for="m" class="burger">&#9776;</label>
<nav><a href="<?=BASE?>/">Home</a><a href="<?=BASE?>/listings.php">Property listings</a><a href="<?=BASE?>/services.php">Our services</a><a href="<?=BASE?>/contact.php">Contact us</a><a href="<?=BASE?>/login.php">Log in</a><a class="btn" href="<?=BASE?>/register.php">Create account</a></nav></header><main><?=flash()?>
