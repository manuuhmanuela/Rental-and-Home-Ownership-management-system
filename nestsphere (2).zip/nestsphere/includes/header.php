<?php
if (!defined('BASE')) {
    require_once __DIR__ . '/../config.php';
}
if (!function_exists('cart_totals')) {
    require_once __DIR__ . '/cart_helpers.php';
}

$u = user();
$cartCount = 0;
try {
    $cartCount = cart_totals()['count'];
} catch (Throwable $ex) {
    $cartCount = 0;
}

$pageTitle = $GLOBALS['__title'] ?? 'NestSphere';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> — NestSphere</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        *, *::before, *::after { box-sizing: border-box; }
        html, body { margin: 0; padding: 0; }
        body {
            font-family: 'DM Sans', system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
            background: #f4f6fb;
            color: #1f2937;
            line-height: 1.55;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        main { flex: 1; }
        a { color: #2563eb; text-decoration: none; }
        a:hover { color: #1d4ed8; }

        /* ---------- NAV ---------- */
        nav.top {
            background: #fff;
            border-bottom: 1px solid #e5e7eb;
            padding: 12px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
            box-shadow: 0 1px 3px rgba(0,0,0,.04);
            position: sticky;
            top: 0;
            z-index: 50;
        }
        nav.top .brand {
            font-size: 1.1rem;
            font-weight: 800;
            color: #1f2937;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        nav.top .brand:hover { color: #2563eb; }
        nav.top .nav-links {
            display: flex;
            gap: 14px;
            flex-wrap: wrap;
            align-items: center;
        }
        nav.top .nav-links a {
            color: #374151;
            font-weight: 600;
            font-size: .88rem;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 6px 8px;
            border-radius: 6px;
            transition: color .15s, background .15s;
        }
        nav.top .nav-links a:hover {
            color: #2563eb;
            background: #eff6ff;
        }
        .cart-badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 18px;
            height: 18px;
            padding: 0 5px;
            border-radius: 999px;
            background: #2563eb;
            color: #fff;
            font-size: .68rem;
            font-weight: 700;
            line-height: 1;
        }
        .user-menu {
            position: relative;
            display: inline-block;
        }
        .user-chip {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 4px 10px 4px 4px;
            background: #f1f5f9;
            border-radius: 999px;
            font-size: .85rem;
            font-weight: 600;
            color: #1f2937;
            cursor: pointer;
            border: 0;
            font-family: inherit;
        }
        .user-chip:hover { background: #e2e8f0; }
        .user-chip .avatar {
            width: 26px;
            height: 26px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: #fff;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: .75rem;
            font-weight: 700;
            text-transform: uppercase;
        }
        .role-pill {
            font-size: .65rem;
            padding: 2px 8px;
            border-radius: 999px;
            text-transform: uppercase;
            font-weight: 700;
            letter-spacing: .3px;
        }
        .role-pill.admin { background: #fef3c7; color: #92400e; }
        .role-pill.user  { background: #dbeafe; color: #1e40af; }

        .dropdown {
            position: absolute;
            right: 0;
            top: calc(100% + 6px);
            background: #fff;
            border: 1px solid #e5e7eb;
            border-radius: 10px;
            box-shadow: 0 8px 24px rgba(15,23,42,.1);
            min-width: 200px;
            padding: 6px;
            display: none;
            z-index: 100;
        }
        .dropdown.open { display: block; }
        .dropdown a {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 10px;
            border-radius: 6px;
            font-size: .88rem;
            color: #1f2937;
            font-weight: 600;
        }
        .dropdown a:hover { background: #eff6ff; color: #2563eb; }
        .dropdown .divider {
            height: 1px;
            background: #e5e7eb;
            margin: 4px 0;
        }

        /* ---------- LAYOUT ---------- */
        .wrap { max-width: 1180px; margin: 0 auto; padding: 24px 16px 60px; width: 100%; }
        .wrap.narrow { max-width: 640px; }
        .wrap.wide   { max-width: 1320px; }

        .box {
            background: #fff;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            padding: 18px;
            margin-bottom: 16px;
            box-shadow: 0 2px 8px rgba(15,23,42,.04);
        }
        .box h1, .box h2 { margin-top: 0; }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            padding: 10px 16px;
            border-radius: 8px;
            background: #2563eb;
            color: #fff;
            border: 1px solid transparent;
            cursor: pointer;
            font-weight: 600;
            font-size: .9rem;
            font-family: inherit;
            transition: background .15s;
            white-space: nowrap;
        }
        .btn:hover { background: #1d4ed8; color: #fff; }
        .btn.ghost { background: #fff; color: #1f2937; border-color: #d1d5db; }
        .btn.ghost:hover { background: #f9fafb; color: #1f2937; }
        .btn.sm { padding: 6px 10px; font-size: .8rem; }
        .btn.bad { background: #dc2626; }
        .btn.bad:hover { background: #b91c1c; }
        .btn.ok { background: #16a34a; }
        .btn.ok:hover { background: #15803d; }

        .muted { color: #6b7280; }
        .good { color: #16a34a; }
        .bad { color: #dc2626; }

        .tbl { width: 100%; border-collapse: collapse; font-size: .9rem; }
        .tbl th, .tbl td {
            padding: 9px 10px;
            border-bottom: 1px solid #e5e7eb;
            text-align: left;
            vertical-align: top;
        }
        .tbl th {
            background: #f1f5f9;
            font-size: .72rem;
            text-transform: uppercase;
            letter-spacing: .4px;
            color: #475569;
            font-weight: 700;
        }
        .tbl tbody tr:hover { background: #fafbfc; }
        .tbl tfoot td, .tbl tfoot th {
            background: #f1f5f9;
            font-weight: 700;
            border-top: 2px solid #e5e7eb;
        }

        label {
            display: block;
            margin-bottom: 12px;
            font-size: .85rem;
            font-weight: 600;
            color: #374151;
        }
        label input, label select, label textarea {
            display: block;
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            font-size: .95rem;
            font-family: inherit;
            margin-top: 5px;
            background: #fff;
            color: #1f2937;
        }
        label input:focus, label select:focus, label textarea:focus {
            outline: none;
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37,99,235,.15);
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 12px;
        }

        .badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 999px;
            font-size: .7rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .3px;
        }
        .badge.ok   { background:#dcfce7; color:#166534; }
        .badge.warn { background:#fef3c7; color:#92400e; }
        .badge.bad  { background:#fee2e2; color:#991b1b; }
        .badge.muted{ background:#e5e7eb; color:#374151; }

        @media (max-width: 700px) {
            nav.top { flex-direction: column; align-items: flex-start; }
            nav.top .nav-links {
                width: 100%;
                justify-content: flex-start;
                gap: 8px;
                overflow-x: auto;
                padding-bottom: 4px;
            }
            nav.top .nav-links a { font-size: .82rem; }
            .wrap { padding: 16px 12px 40px; }
        }
    </style>
</head>
<body>

<nav class="top">
    <a class="brand" href="<?= BASE ?>/index.php">
        <i class="bi bi-house-door-fill" style="color:#2563eb"></i> NestSphere
    </a>

    <div class="nav-links">
        <a href="<?= BASE ?>/properties.php">
            <i class="bi bi-buildings"></i> Properties
        </a>

        <?php if ($u): ?>
            <?php if (($u['role'] ?? '') === 'admin'): ?>
                <!-- ADMIN LINKS -->
                <a href="<?= BASE ?>/admin/dashboard.php"><i class="bi bi-speedometer2"></i> Admin</a>
                <a href="<?= BASE ?>/admin/orders.php"><i class="bi bi-receipt"></i> Orders</a>
                <a href="<?= BASE ?>/admin/rentals.php"><i class="bi bi-key"></i> Rentals</a>
                <a href="<?= BASE ?>/admin/reports.php"><i class="bi bi-file-earmark-bar-graph"></i> Reports</a>
                <a href="<?= BASE ?>/admin/properties.php"><i class="bi bi-house-gear"></i> Properties</a>
                <a href="<?= BASE ?>/admin/users.php"><i class="bi bi-people"></i> Users</a>
                 <a href="mail.php"><i class="bi bi-people"></i> Email Reports</a>
            <?php else: ?>
                <!-- REGULAR USER LINKS -->
                <a href="<?= BASE ?>/user/dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
                <a href="<?= BASE ?>/user/orders.php"><i class="bi bi-receipt"></i> My orders</a>
                <a href="<?= BASE ?>/user/rentals.php"><i class="bi bi-key"></i> My rentals</a>
                <a href="<?= BASE ?>/list_property.php"><i class="bi bi-plus-circle"></i> List</a>
                <a href="<?= BASE ?>/user/properties.php"><i class="bi bi-house-gear"></i> My listings</a>
                <a href="<?= BASE ?>/cart.php">
                    <i class="bi bi-cart3"></i> Cart
                    <?php if ($cartCount > 0): ?>
                        <span class="cart-badge"><?= (int)$cartCount ?></span>
                    <?php endif; ?>
                </a>
            <?php endif; ?>

            <div class="user-menu">
                <button type="button" class="user-chip" onclick="toggleUserMenu(event)">
                    <span class="avatar"><?= e(mb_substr($u['name'] ?? 'U', 0, 1)) ?></span>
                    <span><?= e($u['name'] ?? '') ?></span>
                    <span class="role-pill <?= ($u['role'] ?? '') === 'admin' ? 'admin' : 'user' ?>">
                        <?= e($u['role'] ?? 'user') ?>
                    </span>
                </button>

                <div class="dropdown" id="userMenu">
                    <?php if (($u['role'] ?? '') === 'user'): ?>
                        <a href="<?= BASE ?>/user/dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
                        <a href="<?= BASE ?>/user/orders.php"><i class="bi bi-receipt"></i> My orders</a>
                        <a href="<?= BASE ?>/user/rentals.php"><i class="bi bi-key"></i> My rentals</a>
                        <a href="<?= BASE ?>/user/properties.php"><i class="bi bi-house-gear"></i> My listings</a>
                        <a href="<?= BASE ?>/user/profile.php"><i class="bi bi-person-gear"></i> My profile</a>
                    <?php else: ?>
                        <a href="<?= BASE ?>/admin/dashboard.php"><i class="bi bi-speedometer2"></i> Admin dashboard</a>
                    <?php endif; ?>
                    <div class="divider"></div>
                    <a href="<?= BASE ?>/logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
                </div>
            </div>
        <?php else: ?>
            <a href="<?= BASE ?>/login.php"><i class="bi bi-box-arrow-in-right"></i> Log in</a>
            <a href="<?= BASE ?>/register.php"><i class="bi bi-person-plus"></i> Register</a>
        <?php endif; ?>
    </div>
</nav>

<main>

<script>
    function toggleUserMenu(e) {
        e.stopPropagation();
        document.getElementById('userMenu').classList.toggle('open');
    }
    document.addEventListener('click', function () {
        const menu = document.getElementById('userMenu');
        if (menu) menu.classList.remove('open');
    });
</script>