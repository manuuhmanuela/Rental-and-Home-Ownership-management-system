<?php include __DIR__.'/head.php'; ?>
<body><header class="nav usr"><a class="logo" href="<?=BASE?>/">NestSphere</a>
<input type="checkbox" id="m"><label for="m" class="burger">&#9776;</label>
<nav><a href="<?=BASE?>/">Home</a><a href="<?=BASE?>/listings.php">Property listings</a><a href="<?=BASE?>/services.php">Our services</a><a href="<?=BASE?>/contact.php">Contact us</a>
<span class="who"><?=e(user()['name'])?></span><a class="btn" href="<?=BASE?>/logout.php">Log out</a></nav></header>
<div class="sub"><a href="<?=BASE?>/user/dashboard.php">Dashboard</a><a href="<?=BASE?>/user/add_listing.php">List a property</a><a href="<?=BASE?>/user/my_listings.php">My listings</a><a href="<?=BASE?>/user/favourites.php">Favourites</a><a href="<?=BASE?>/user/inquiries.php">Inquiries</a><a href="<?=BASE?>/user/offers.php">Offers</a><a href="<?=BASE?>/user/profile.php">My profile</a></div><main><?=flash()?>
