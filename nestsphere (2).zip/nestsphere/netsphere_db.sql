-- ============================================================
-- NestSphere — Full Database + Rich Demo Data
-- PLAINTEXT passwords only — no hashing
-- Demo password for ALL accounts: Admin@123
-- Safe to import multiple times.
-- ============================================================

CREATE DATABASE IF NOT EXISTS nestsphere CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE nestsphere;

-- ============================================================
-- USERS
-- ============================================================
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    city VARCHAR(80),
    bio TEXT,
    password VARCHAR(255) NOT NULL,
    role ENUM('user','admin') NOT NULL DEFAULT 'user',
    status ENUM('active','suspended') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_users_email (email),
    INDEX idx_users_role (role),
    INDEX idx_users_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- PROPERTIES
-- ============================================================
CREATE TABLE IF NOT EXISTS properties (
    id INT AUTO_INCREMENT PRIMARY KEY,
    owner_id INT NOT NULL,
    title VARCHAR(150) NOT NULL,
    type ENUM('Apartment','Bungalow','Townhouse','Land','Commercial') NOT NULL,
    purpose ENUM('sale','rent') NOT NULL DEFAULT 'sale',
    location VARCHAR(120) NOT NULL,
    price DECIMAL(14,2) NOT NULL,
    bedrooms INT DEFAULT 0,
    bathrooms INT DEFAULT 0,
    size VARCHAR(40),
    description TEXT,
    image_url VARCHAR(255),
    status ENUM('pending','approved','rejected','sold') NOT NULL DEFAULT 'pending',
    reject_reason VARCHAR(255),
    featured TINYINT(1) NOT NULL DEFAULT 0,
    views INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_props_status (status),
    INDEX idx_props_purpose (purpose),
    INDEX idx_props_type (type),
    INDEX idx_props_owner (owner_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- INQUIRIES
-- ============================================================
CREATE TABLE IF NOT EXISTS inquiries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    property_id INT NOT NULL,
    user_id INT NOT NULL,
    message TEXT NOT NULL,
    reply TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_inq_prop (property_id),
    INDEX idx_inq_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- OFFERS
-- ============================================================
CREATE TABLE IF NOT EXISTS offers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    property_id INT NOT NULL,
    user_id INT NOT NULL,
    amount DECIMAL(14,2) NOT NULL,
    note VARCHAR(200),
    status ENUM('pending','accepted','rejected') NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_offers_prop (property_id),
    INDEX idx_offers_user (user_id),
    INDEX idx_offers_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- FAVOURITES
-- ============================================================
CREATE TABLE IF NOT EXISTS favourites (
    user_id INT NOT NULL,
    property_id INT NOT NULL,
    PRIMARY KEY (user_id, property_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- MESSAGES
-- ============================================================
CREATE TABLE IF NOT EXISTS messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(120),
    subject VARCHAR(150),
    message TEXT,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_msg_read (is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- ACTIVITY
-- ============================================================
CREATE TABLE IF NOT EXISTS activity (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    action VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_act_user (user_id),
    INDEX idx_act_date (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- ORDERS
-- ============================================================
CREATE TABLE IF NOT EXISTS orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    order_ref VARCHAR(40) NOT NULL UNIQUE,
    user_id INT NOT NULL,
    order_type ENUM('purchase','rental','mixed') NOT NULL DEFAULT 'purchase',
    total_amount DECIMAL(14,2) NOT NULL,
    status ENUM('pending','paid','cancelled','failed') NOT NULL DEFAULT 'pending',
    payment_method VARCHAR(40) NULL,
    payment_ref VARCHAR(80) NULL,
    paid_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_orders_user (user_id),
    INDEX idx_orders_status (status),
    INDEX idx_orders_ref (order_ref)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- ORDER ITEMS
-- ============================================================
CREATE TABLE IF NOT EXISTS order_items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    property_id INT NOT NULL,
    item_type ENUM('purchase','rental') NOT NULL,
    price DECIMAL(14,2) NOT NULL,
    months INT NOT NULL DEFAULT 1,
    subtotal DECIMAL(14,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE,
    INDEX idx_items_order (order_id),
    INDEX idx_items_prop (property_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- RENTALS
-- ============================================================
CREATE TABLE IF NOT EXISTS rentals (
    rental_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    user_id INT NOT NULL,
    property_id INT NOT NULL,
    monthly_rent DECIMAL(14,2) NOT NULL,
    months INT NOT NULL DEFAULT 1,
    start_date DATE NOT NULL,
    status ENUM('active','expired','cancelled') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE,
    INDEX idx_rental_user (user_id),
    INDEX idx_rental_prop (property_id),
    INDEX idx_rental_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- USERS DATA — PLAINTEXT PASSWORDS (Admin@123)
-- ============================================================
INSERT INTO users (name, email, phone, city, bio, password, role, status) VALUES
('Site Admin',     'admin@nestsphere.co.ke', '0700000000', 'Nairobi', 'Platform administrator',    'Admin@123', 'admin', 'active'),
('Wanjiru Kamau',  'user@nestsphere.co.ke',  '0711000000', 'Nairobi', 'Looking for a family home', 'Admin@123', 'user',  'active'),
('Brian Otieno',   'brian@example.com',      '0722000001', 'Mombasa', 'Investor',                  'Admin@123', 'user',  'active'),
('Aisha Mohamed',  'aisha@example.com',      '0733000002', 'Nairobi', 'First-time buyer',          'Admin@123', 'user',  'active'),
('Peter Njoroge',  'peter@example.com',      '0744000003', 'Nakuru',  'Landlord',                  'Admin@123', 'user',  'active'),
('Grace Wambui',   'grace@example.com',      '0755000004', 'Kisumu',  'Relocating for work',       'Admin@123', 'user',  'suspended'),
('Samuel Kariuki', 'samuel@example.com',     '0766000005', 'Nairobi', 'Property developer',        'Admin@123', 'user',  'active'),
('Fatuma Hassan',  'fatuma@example.com',     '0777000006', 'Mombasa', 'Holiday home seeker',       'Admin@123', 'user',  'active'),
('Joseph Mwangi',  'joseph@example.com',     '0788000007', 'Nairobi', 'Commercial buyer',          'Admin@123', 'user',  'active'),
('Lucy Achieng',   'lucy@example.com',       '0799000008', 'Kisumu',  'Family of four',            'Admin@123', 'user',  'active'),
('Daniel Kiprop',  'daniel@example.com',     '0700000009', 'Eldoret', 'Farmer turned investor',    'Admin@123', 'user',  'active'),
('Mary Wanjiku',   'mary@example.com',       '0700000010', 'Thika',   'First home buyer',          'Admin@123', 'user',  'active')
ON DUPLICATE KEY UPDATE
    name = VALUES(name),
    phone = VALUES(phone),
    city = VALUES(city),
    bio = VALUES(bio),
    password = VALUES(password),
    role = VALUES(role),
    status = VALUES(status);

-- ============================================================
-- PROPERTIES DATA — 22 approved + 1 pending
-- ============================================================
INSERT INTO properties
(owner_id, title, type, purpose, location, price, bedrooms, bathrooms, size, description, image_url, status, featured, views)
SELECT * FROM (
    SELECT 2, 'Modern 3-bedroom apartment',        'Apartment',  'sale', 'Kilimani, Nairobi',     14500000, 3, 2, '140 sqm',  'Bright apartment with balcony, backup generator, gym and 24-hour security.', 'https://picsum.photos/seed/kilimani/800/500', 'approved', 1, 142 UNION ALL
    SELECT 2, 'Family bungalow with garden',       'Bungalow',   'sale', 'Runda, Nairobi',        48000000, 4, 4, '0.25 acre','Gated community bungalow with staff quarter, borehole and landscaped garden.', 'https://picsum.photos/seed/runda/800/500',   'approved', 1, 130 UNION ALL
    SELECT 2, 'Townhouse near Thika Road',         'Townhouse',  'sale', 'Ruiru, Kiambu',          9800000, 3, 3, '160 sqm',  'Maisonette in a gated estate close to the bypass with a shared playground.', 'https://picsum.photos/seed/ruiru/800/500',   'approved', 0, 118 UNION ALL
    SELECT 2, 'Quarter-acre plot, title ready',    'Land',       'sale', 'Kikuyu, Kiambu',         3500000, 0, 0, '0.25 acre','Flat plot with ready title deed, water and electricity on the road.', 'https://picsum.photos/seed/kikuyu/800/500',  'approved', 0,  92 UNION ALL
    SELECT 5, 'Commercial plot near highway',      'Land',       'sale', 'Naivasha Road, Nakuru',  8500000, 0, 0, '1 acre',   'Great for warehousing or a petrol station.', 'https://picsum.photos/seed/naivasha/800/500', 'approved', 0,  87 UNION ALL
    SELECT 7, 'Luxury 4-bedroom maisonette',       'Townhouse',  'sale', 'Kitisuru, Nairobi',     38500000, 4, 4, '260 sqm',  'High-end finishes, rooftop terrace, borehole and solar.', 'https://picsum.photos/seed/kitisuru/800/500', 'approved', 1, 168 UNION ALL
    SELECT 8, 'Penthouse with city views',         'Apartment',  'sale', 'Westlands, Nairobi',    32000000, 3, 3, '190 sqm',  'Top-floor penthouse, rooftop pool, 2 parking slots.', 'https://picsum.photos/seed/penthouse/800/500','approved', 1, 156 UNION ALL
    SELECT 9, 'Office block for sale',             'Commercial', 'sale', 'Upper Hill, Nairobi',   78000000, 0, 4, '800 sqm',  'Four-storey office block, ready title, generator backup.', 'https://picsum.photos/seed/upperhill/800/500','approved', 1, 211 UNION ALL
    SELECT 10,'5-acre land, ready for development','Land',       'sale', 'Ngong, Kajiado',        15000000, 0, 0, '5 acre',   'Prime land with road access and utilities available.', 'https://picsum.photos/seed/ngong/800/500',    'approved', 0,  59 UNION ALL
    SELECT 11,'Bungalow for sale, quiet area',     'Bungalow',   'sale', 'Milimani, Kisumu',      12500000, 3, 2, '180 sqm',  'Family-friendly home in a leafy suburb, ready title deed.', 'https://picsum.photos/seed/milimani/800/500', 'approved', 0,  67 UNION ALL
    SELECT 3, 'Beachfront villa for rent',         'Bungalow',   'rent', 'Nyali, Mombasa',          180000, 4, 3, '300 sqm',  'Ocean-facing villa with private pool, fully furnished.', 'https://picsum.photos/seed/nyali/800/500',    'approved', 1, 245 UNION ALL
    SELECT 4, 'Executive 2-bedroom to let',        'Apartment',  'rent', 'Lavington, Nairobi',       90000, 2, 2, '110 sqm',  'Modern finishes, gym, pool, secure parking.', 'https://picsum.photos/seed/lavington/800/500','approved', 0, 121 UNION ALL
    SELECT 7, 'Studio apartment to let',           'Apartment',  'rent', 'Kileleshwa, Nairobi',      35000, 1, 1, '45 sqm',   'Compact studio near Yaya Centre, water and security included.', 'https://picsum.photos/seed/kileleshwa/800/500','approved',0, 143 UNION ALL
    SELECT 7, 'Modern shop for rent',              'Commercial', 'rent', 'Mombasa Road, Nairobi',    80000, 0, 1, '60 sqm',   'Ground-floor shop on a busy highway, ideal for retail.', 'https://picsum.photos/seed/mombasaroad/800/500','approved',0, 54 UNION ALL
    SELECT 3, 'Sea-view 3-bedroom apartment',      'Apartment',  'rent', 'Nyali, Mombasa',          120000, 3, 2, '130 sqm',  'Furnished apartment overlooking the Indian Ocean.', 'https://picsum.photos/seed/seaview/800/500',  'approved', 1, 187 UNION ALL
    SELECT 3, 'Holiday bungalow, Diani',           'Bungalow',   'rent', 'Diani, Kwale',            250000, 3, 3, '220 sqm',  'Beach access, private garden, perfect for short stays.', 'https://picsum.photos/seed/diani/800/500',    'approved', 0, 209 UNION ALL
    SELECT 8, '2-bedroom apartment to let',        'Apartment',  'rent', 'Kilimani, Nairobi',        75000, 2, 2, '95 sqm',   'Newly built, modern kitchen, balcony, secure estate.', 'https://picsum.photos/seed/kilimani2/800/500', 'approved', 0,  63 UNION ALL
    SELECT 9, 'Warehouse near industrial area',    'Commercial', 'rent', 'Industrial Area, Nairobi',200000, 0, 1, '500 sqm',  'Fully enclosed warehouse with loading bay and offices.', 'https://picsum.photos/seed/warehouse/800/500', 'approved', 0,  38 UNION ALL
    SELECT 10,'Garden cottage to let',             'Bungalow',   'rent', 'Karen, Nairobi',          150000, 2, 2, '150 sqm',  'Quiet, gated compound with mature garden and staff quarters.', 'https://picsum.photos/seed/karen/800/500',    'approved', 0,  76 UNION ALL
    SELECT 11,'Lakeview 2-bedroom to let',         'Apartment',  'rent', 'Kisumu CBD, Kisumu',       45000, 2, 1, '80 sqm',   'Lake view, walking distance to town, secure parking.', 'https://picsum.photos/seed/kisumu/800/500',    'approved', 0,  41 UNION ALL
    SELECT 12,'Starter 1-bedroom to let',          'Apartment',  'rent', 'Thika Town, Kiambu',       28000, 1, 1, '50 sqm',   'Affordable one-bedroom close to Thika Road, ideal for young professionals.', 'https://picsum.photos/seed/thika2/800/500',   'approved', 0, 132 UNION ALL
    SELECT 2, 'Garden townhouse awaiting review',  'Townhouse',  'sale', 'Limuru, Kiambu',        11200000, 4, 3, '210 sqm',  'Cool-climate townhouse with a fireplace. Pending admin approval.', 'https://picsum.photos/seed/limuru/800/500',    'pending',  0,   0
) AS tmp
WHERE NOT EXISTS (SELECT 1 FROM properties LIMIT 1);

-- ============================================================
-- INQUIRIES DATA
-- ============================================================
INSERT INTO inquiries (property_id, user_id, message, reply)
SELECT * FROM (
    SELECT 1,  3, 'Is the apartment still available? Can I view this weekend?', 'Yes, Saturday 10am works.' UNION ALL
    SELECT 2,  4, 'Does the bungalow have a borehole?',                        NULL UNION ALL
    SELECT 5,  3, 'Is the rent negotiable for a 12-month lease?',              'Slightly negotiable.' UNION ALL
    SELECT 8,  5, 'Is the villa furnished? Are pets allowed?',                 NULL UNION ALL
    SELECT 11, 6, 'Can I see the sea-view apartment on Saturday?',             NULL UNION ALL
    SELECT 13, 4, 'Is parking included in the rent?',                          'Yes, two slots.' UNION ALL
    SELECT 16, 8, 'Is the office block fully tenanted?',                       NULL UNION ALL
    SELECT 19, 9, 'What deposit do you require?',                              'Two months deposit.' UNION ALL
    SELECT 21, 10,'Is the apartment near public transport?',                   NULL
) AS tmp
WHERE NOT EXISTS (SELECT 1 FROM inquiries LIMIT 1);

-- ============================================================
-- OFFERS DATA
-- ============================================================
INSERT INTO offers (property_id, user_id, amount, note, status)
SELECT * FROM (
    SELECT 1,  3, 14000000.00, 'Cash offer, ready in 2 weeks', 'pending'  UNION ALL
    SELECT 2,  4, 46500000.00, 'Bank pre-approved',            'pending'  UNION ALL
    SELECT 3,  5,  9500000.00, 'Counter-offer',                'accepted' UNION ALL
    SELECT 4,  3,  3400000.00, 'Quick close',                  'rejected' UNION ALL
    SELECT 8,  5, 37500000.00, 'Cash offer',                   'pending'  UNION ALL
    SELECT 13, 4, 31000000.00, 'Bank financing',               'pending'  UNION ALL
    SELECT 16, 9, 75000000.00, 'Serious buyer',                'pending'  UNION ALL
    SELECT 20, 6, 12000000.00, 'Ready to sign',                'accepted'
) AS tmp
WHERE NOT EXISTS (SELECT 1 FROM offers LIMIT 1);

-- ============================================================
-- FAVOURITES DATA
-- ============================================================
INSERT IGNORE INTO favourites (user_id, property_id) VALUES
(3, 1), (3, 5), (4, 2), (5, 8), (2, 1),
(6, 11),(7, 13),(8, 16),(9, 19),(10, 21);

-- ============================================================
-- MESSAGES DATA
-- ============================================================
INSERT INTO messages (name, email, subject, message, is_read)
SELECT * FROM (
    SELECT 'Brian Otieno',  'brian@example.com', 'Listing a plot',     'How long does approval take?',        0 UNION ALL
    SELECT 'Aisha Mohamed', 'aisha@example.com', 'Viewing request',    'Can I schedule a viewing?',            0 UNION ALL
    SELECT 'Peter Njoroge', 'peter@example.com', 'Payment question',   'Do you accept bank transfers?',        1 UNION ALL
    SELECT 'Fatuma Hassan', 'fatuma@example.com','Diani bungalow',     'Available in December?',               0 UNION ALL
    SELECT 'Joseph Mwangi', 'joseph@example.com','Office block query', 'Can I get floor plans?',               0
) AS tmp
WHERE NOT EXISTS (SELECT 1 FROM messages LIMIT 1);

-- ============================================================
-- ACTIVITY DATA
-- ============================================================
INSERT INTO activity (user_id, action)
SELECT * FROM (
    SELECT 1, 'Created admin account'          UNION ALL
    SELECT 2, 'Registered an account'          UNION ALL
    SELECT 3, 'Added a property to favourites' UNION ALL
    SELECT 2, 'Listed a new property'          UNION ALL
    SELECT 4, 'Sent an inquiry'                UNION ALL
    SELECT 5, 'Submitted an offer'             UNION ALL
    SELECT 1, 'Approved a property listing'
) AS tmp
WHERE NOT EXISTS (SELECT 1 FROM activity LIMIT 1);

-- ============================================================
-- ORDERS 1 — PAID PURCHASE
-- ============================================================
INSERT INTO orders (order_ref, user_id, order_type, total_amount, status, payment_method, payment_ref, paid_at) VALUES
('NS-202501010001', 3, 'purchase', 14500000.00, 'paid', 'mpesa', 'MPESA-ABCD1234', NOW() - INTERVAL 5 DAY)
ON DUPLICATE KEY UPDATE
    total_amount = VALUES(total_amount),
    status = VALUES(status),
    payment_method = VALUES(payment_method),
    payment_ref = VALUES(payment_ref),
    paid_at = VALUES(paid_at);

SET @order1 = (SELECT order_id FROM orders WHERE order_ref = 'NS-202501010001');
INSERT INTO order_items (order_id, property_id, item_type, price, months, subtotal)
SELECT @order1, 1, 'purchase', 14500000.00, 1, 14500000.00
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM order_items WHERE order_id = @order1 AND property_id = 1);
UPDATE properties SET status='sold' WHERE id=1;

-- ============================================================
-- ORDERS 2 — PAID RENTAL
-- ============================================================
INSERT INTO orders (order_ref, user_id, order_type, total_amount, status, payment_method, payment_ref, paid_at) VALUES
('NS-202501010002', 4, 'rental', 360000.00, 'paid', 'mpesa', 'MPESA-EFGH5678', NOW() - INTERVAL 3 DAY)
ON DUPLICATE KEY UPDATE
    total_amount = VALUES(total_amount),
    status = VALUES(status),
    payment_method = VALUES(payment_method),
    payment_ref = VALUES(payment_ref),
    paid_at = VALUES(paid_at);

SET @order2 = (SELECT order_id FROM orders WHERE order_ref = 'NS-202501010002');
INSERT INTO order_items (order_id, property_id, item_type, price, months, subtotal)
SELECT @order2, 11, 'rental', 120000.00, 3, 360000.00
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM order_items WHERE order_id = @order2 AND property_id = 11);

INSERT INTO rentals (order_id, user_id, property_id, monthly_rent, months, start_date, status)
SELECT @order2, 4, 11, 120000.00, 3, CURDATE(), 'active'
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM rentals WHERE order_id = @order2 AND property_id = 11);

-- ============================================================
-- ORDERS 3 — PENDING PURCHASE
-- ============================================================
INSERT INTO orders (order_ref, user_id, order_type, total_amount, status) VALUES
('NS-202501010003', 5, 'purchase', 9800000.00, 'pending')
ON DUPLICATE KEY UPDATE
    total_amount = VALUES(total_amount),
    status = VALUES(status);

SET @order3 = (SELECT order_id FROM orders WHERE order_ref = 'NS-202501010003');
INSERT INTO order_items (order_id, property_id, item_type, price, months, subtotal)
SELECT @order3, 3, 'purchase', 9800000.00, 1, 9800000.00
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM order_items WHERE order_id = @order3 AND property_id = 3);

-- ============================================================
-- ORDERS 4 — PENDING RENTAL
-- ============================================================
INSERT INTO orders (order_ref, user_id, order_type, total_amount, status) VALUES
('NS-202501010004', 3, 'rental', 180000.00, 'pending')
ON DUPLICATE KEY UPDATE
    total_amount = VALUES(total_amount),
    status = VALUES(status);

SET @order4 = (SELECT order_id FROM orders WHERE order_ref = 'NS-202501010004');
INSERT INTO order_items (order_id, property_id, item_type, price, months, subtotal)
SELECT @order4, 6, 'rental', 90000.00, 2, 180000.00
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM order_items WHERE order_id = @order4 AND property_id = 6);

INSERT INTO rentals (order_id, user_id, property_id, monthly_rent, months, start_date, status)
SELECT @order4, 3, 6, 90000.00, 2, CURDATE(), 'active'
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM rentals WHERE order_id = @order4 AND property_id = 6);

-- ============================================================
-- END
-- ============================================================