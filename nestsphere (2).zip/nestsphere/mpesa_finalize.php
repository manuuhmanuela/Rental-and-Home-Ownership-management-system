<?php
require 'config.php';
require 'includes/cart_helpers.php';
need_login();

header('Content-Type: application/json');

$orderRef = $_POST['order_ref'] ?? '';
$orderId  = (int)($_POST['order_id'] ?? 0);

if (!$orderRef || !$orderId) {
    echo json_encode(['ok' => false, 'error' => 'Missing order details']);
    exit;
}

$stmt = db()->prepare("SELECT * FROM orders WHERE order_id = ? AND order_ref = ? AND user_id = ?");
$stmt->execute([$orderId, $orderRef, user()['id']]);
$order = $stmt->fetch();

if (!$order) {
    echo json_encode(['ok' => false, 'error' => 'Order not found']);
    exit;
}

if ($order['status'] === 'paid') {
    cart_clear();
    unset($_SESSION['pending_order']);
    echo json_encode(['ok' => true, 'already' => true]);
    exit;
}

db()->prepare("UPDATE orders SET status='paid', payment_method='mpesa', payment_ref=?, paid_at=NOW() WHERE order_id=?")
    ->execute(['MPESA-' . strtoupper(bin2hex(random_bytes(4))), $orderId]);

$items = db()->prepare("SELECT property_id, item_type FROM order_items WHERE order_id=?");
$items->execute([$orderId]);
foreach ($items->fetchAll() as $row) {
    if ($row['item_type'] === 'purchase') {
        db()->prepare("UPDATE properties SET status='sold' WHERE id=?")->execute([$row['property_id']]);
    }
}

cart_clear();
unset($_SESSION['pending_order']);

echo json_encode(['ok' => true]);