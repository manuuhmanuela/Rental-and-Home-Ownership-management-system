-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 29, 2026 at 07:12 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nestsphere`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity`
--

CREATE TABLE `activity` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `activity`
--

INSERT INTO `activity` (`id`, `user_id`, `action`, `created_at`) VALUES
(1, 1, 'Logged in', '2026-10-29 17:07:00'),
(2, 1, 'Listed a new property: 3 BEDROOM', '2026-10-29 17:07:51'),
(3, 1, 'Logged out', '2026-10-29 17:07:56'),
(4, 13, 'Registered an account', '2026-10-29 17:08:29'),
(5, 13, 'Listed a new property: 4 BEDROOM', '2026-10-29 17:09:08'),
(6, 13, 'Logged out', '2026-10-29 17:09:14'),
(7, 1, 'Logged in', '2026-10-29 17:09:40'),
(8, 1, 'Admin set property #2 to approved', '2026-10-29 17:11:36'),
(9, 1, 'Admin set property #1 to approved', '2026-10-29 17:11:46'),
(10, 1, 'Admin added property: 5 BEDROOM', '2026-10-29 17:12:54'),
(11, 1, 'Admin added property: 2 BEDROOM', '2026-10-29 17:13:45'),
(12, 1, 'Admin added property: 1 BEDROOM', '2026-10-29 17:14:42'),
(13, 1, 'Logged out', '2026-10-29 17:16:05'),
(14, 13, 'Logged in', '2026-10-29 17:16:19'),
(15, 13, 'Logged out', '2026-10-29 17:47:26'),
(16, 13, 'Logged in', '2026-10-29 17:47:30'),
(17, 13, 'Logged out', '2026-10-29 17:48:17'),
(18, 1, 'Logged in', '2026-10-29 17:49:52'),
(19, 1, 'Logged out', '2026-10-29 17:59:32'),
(20, 13, 'Logged in', '2026-10-29 17:59:37'),
(21, 13, 'Logged out', '2026-10-29 18:00:23'),
(22, 1, 'Logged in', '2026-10-29 18:00:50');

-- --------------------------------------------------------

--
-- Table structure for table `favourites`
--

CREATE TABLE `favourites` (
  `user_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `inquiries`
--

CREATE TABLE `inquiries` (
  `id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `reply` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(120) DEFAULT NULL,
  `subject` varchar(150) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

CREATE TABLE `offers` (
  `id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(14,2) NOT NULL,
  `note` varchar(200) DEFAULT NULL,
  `status` enum('pending','accepted','rejected') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `order_ref` varchar(40) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_type` enum('purchase','rental','mixed') NOT NULL DEFAULT 'purchase',
  `total_amount` decimal(14,2) NOT NULL,
  `status` enum('pending','paid','cancelled','failed') NOT NULL DEFAULT 'pending',
  `payment_method` varchar(40) DEFAULT NULL,
  `payment_ref` varchar(80) DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `order_ref`, `user_id`, `order_type`, `total_amount`, `status`, `payment_method`, `payment_ref`, `paid_at`, `created_at`) VALUES
(1, 'NS-20261029181641-CA1C42', 13, 'rental', '3000000.00', 'paid', 'mpesa', 'MPESA-EBFA5449', '2026-10-29 17:16:49', '2026-10-29 17:16:41'),
(2, 'NS-20261029190001-16C420', 13, 'rental', '3000000.00', 'paid', 'mpesa', 'MPESA-6F0A8BBC', '2026-10-29 18:00:07', '2026-10-29 18:00:01');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `item_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `item_type` enum('purchase','rental') NOT NULL,
  `price` decimal(14,2) NOT NULL,
  `months` int(11) NOT NULL DEFAULT 1,
  `subtotal` decimal(14,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`item_id`, `order_id`, `property_id`, `item_type`, `price`, `months`, `subtotal`) VALUES
(1, 1, 4, 'rental', '3000000.00', 1, '3000000.00'),
(2, 2, 4, 'rental', '3000000.00', 1, '3000000.00');

-- --------------------------------------------------------

--
-- Table structure for table `properties`
--

CREATE TABLE `properties` (
  `id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `type` enum('Apartment','Bungalow','Townhouse','Land','Commercial') NOT NULL,
  `purpose` enum('sale','rent') NOT NULL DEFAULT 'sale',
  `location` varchar(120) NOT NULL,
  `price` decimal(14,2) NOT NULL,
  `bedrooms` int(11) DEFAULT 0,
  `bathrooms` int(11) DEFAULT 0,
  `size` varchar(40) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `status` enum('pending','approved','rejected','sold') NOT NULL DEFAULT 'pending',
  `reject_reason` varchar(255) DEFAULT NULL,
  `featured` tinyint(1) NOT NULL DEFAULT 0,
  `views` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `properties`
--

INSERT INTO `properties` (`id`, `owner_id`, `title`, `type`, `purpose`, `location`, `price`, `bedrooms`, `bathrooms`, `size`, `description`, `image_url`, `status`, `reject_reason`, `featured`, `views`, `created_at`) VALUES
(1, 1, '3 BEDROOM', 'Apartment', 'sale', 'kilimani', '6000000.00', 2, 2, '0.25ha', '', '/nestsphere/uploads/properties/1-20261029180751-ae9830.jpg', 'approved', NULL, 0, 0, '2026-10-29 17:07:51'),
(2, 13, '4 BEDROOM', 'Apartment', 'sale', 'kilimani', '70000000.00', 3, 2, '0.25ha', '', '/nestsphere/uploads/properties/2-20261029180908-b85025.jpg', 'approved', NULL, 0, 0, '2026-10-29 17:09:08'),
(3, 4, '5 BEDROOM', 'Bungalow', 'rent', 'JUJA', '500000.00', 2, 1, '0.25ha', 'BIG', '/nestsphere/uploads/properties/3-20261029181254-d2a155.jpg', 'approved', NULL, 0, 0, '2026-10-29 17:12:54'),
(4, 1, '2 BEDROOM', 'Townhouse', 'rent', 'KILELESHWA', '3000000.00', 1, 1, '0.25ha', '', '/nestsphere/uploads/properties/4-20261029181345-1666c7.jpg', 'approved', NULL, 0, 0, '2026-10-29 17:13:45'),
(5, 1, '1 BEDROOM', 'Apartment', 'rent', 'kilimani', '46000.00', 1, 1, '0.25ha', '', '/nestsphere/uploads/properties/5-20261029181442-2316d3.jpg', 'approved', NULL, 0, 0, '2026-10-29 17:14:42');

-- --------------------------------------------------------

--
-- Table structure for table `rentals`
--

CREATE TABLE `rentals` (
  `rental_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `monthly_rent` decimal(14,2) NOT NULL,
  `months` int(11) NOT NULL DEFAULT 1,
  `start_date` date NOT NULL,
  `status` enum('active','expired','cancelled') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rentals`
--

INSERT INTO `rentals` (`rental_id`, `order_id`, `user_id`, `property_id`, `monthly_rent`, `months`, `start_date`, `status`, `created_at`) VALUES
(1, 1, 13, 4, '3000000.00', 1, '2026-10-29', 'active', '2026-10-29 17:16:41'),
(2, 2, 13, 4, '3000000.00', 1, '2026-10-29', 'active', '2026-10-29 18:00:01');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(120) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `city` varchar(80) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') NOT NULL DEFAULT 'user',
  `status` enum('active','suspended') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `city`, `bio`, `password`, `role`, `status`, `created_at`) VALUES
(1, 'Site Admin', 'admin@nestsphere.co.ke', '0700000000', 'Nairobi', 'Platform administrator', 'Admin@123', 'admin', 'active', '2026-10-29 17:04:43'),
(2, 'Wanjiru Kamau', 'user@nestsphere.co.ke', '0711000000', 'Nairobi', 'Looking for a family home', 'Admin@123', 'user', 'active', '2026-10-29 17:04:43'),
(3, 'Brian Otieno', 'brian@example.com', '0722000001', 'Mombasa', 'Investor', 'Admin@123', 'user', 'active', '2026-10-29 17:04:43'),
(4, 'Aisha Mohamed', 'aisha@example.com', '0733000002', 'Nairobi', 'First-time buyer', 'Admin@123', 'user', 'active', '2026-10-29 17:04:43'),
(5, 'Peter Njoroge', 'peter@example.com', '0744000003', 'Nakuru', 'Landlord', 'Admin@123', 'user', 'active', '2026-10-29 17:04:43'),
(6, 'Grace Wambui', 'grace@example.com', '0755000004', 'Kisumu', 'Relocating for work', 'Admin@123', 'user', 'suspended', '2026-10-29 17:04:43'),
(7, 'Samuel Kariuki', 'samuel@example.com', '0766000005', 'Nairobi', 'Property developer', 'Admin@123', 'user', 'active', '2026-10-29 17:04:43'),
(8, 'Fatuma Hassan', 'fatuma@example.com', '0777000006', 'Mombasa', 'Holiday home seeker', 'Admin@123', 'user', 'active', '2026-10-29 17:04:43'),
(9, 'Joseph Mwangi', 'joseph@example.com', '0788000007', 'Nairobi', 'Commercial buyer', 'Admin@123', 'user', 'active', '2026-10-29 17:04:43'),
(10, 'Lucy Achieng', 'lucy@example.com', '0799000008', 'Kisumu', 'Family of four', 'Admin@123', 'user', 'active', '2026-10-29 17:04:43'),
(11, 'Daniel Kiprop', 'daniel@example.com', '0700000009', 'Eldoret', 'Farmer turned investor', 'Admin@123', 'user', 'active', '2026-10-29 17:04:43'),
(12, 'Mary Wanjiku', 'mary@example.com', '0700000010', 'Thika', 'First home buyer', 'Admin@123', 'user', 'active', '2026-10-29 17:04:43'),
(13, 'manuuh manuela', 'emm@gmail.com', '0799444663', 'KAPSABET', NULL, '12345678', 'user', 'active', '2026-10-29 17:08:29');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity`
--
ALTER TABLE `activity`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_act_user` (`user_id`),
  ADD KEY `idx_act_date` (`created_at`);

--
-- Indexes for table `favourites`
--
ALTER TABLE `favourites`
  ADD PRIMARY KEY (`user_id`,`property_id`),
  ADD KEY `property_id` (`property_id`);

--
-- Indexes for table `inquiries`
--
ALTER TABLE `inquiries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_inq_prop` (`property_id`),
  ADD KEY `idx_inq_user` (`user_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_msg_read` (`is_read`);

--
-- Indexes for table `offers`
--
ALTER TABLE `offers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_offers_prop` (`property_id`),
  ADD KEY `idx_offers_user` (`user_id`),
  ADD KEY `idx_offers_status` (`status`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD UNIQUE KEY `order_ref` (`order_ref`),
  ADD KEY `idx_orders_user` (`user_id`),
  ADD KEY `idx_orders_status` (`status`),
  ADD KEY `idx_orders_ref` (`order_ref`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `idx_items_order` (`order_id`),
  ADD KEY `idx_items_prop` (`property_id`);

--
-- Indexes for table `properties`
--
ALTER TABLE `properties`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_props_status` (`status`),
  ADD KEY `idx_props_purpose` (`purpose`),
  ADD KEY `idx_props_type` (`type`),
  ADD KEY `idx_props_owner` (`owner_id`);

--
-- Indexes for table `rentals`
--
ALTER TABLE `rentals`
  ADD PRIMARY KEY (`rental_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `idx_rental_user` (`user_id`),
  ADD KEY `idx_rental_prop` (`property_id`),
  ADD KEY `idx_rental_status` (`status`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_users_email` (`email`),
  ADD KEY `idx_users_role` (`role`),
  ADD KEY `idx_users_status` (`status`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity`
--
ALTER TABLE `activity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `inquiries`
--
ALTER TABLE `inquiries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `offers`
--
ALTER TABLE `offers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `properties`
--
ALTER TABLE `properties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `rentals`
--
ALTER TABLE `rentals`
  MODIFY `rental_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity`
--
ALTER TABLE `activity`
  ADD CONSTRAINT `activity_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `favourites`
--
ALTER TABLE `favourites`
  ADD CONSTRAINT `favourites_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `favourites_ibfk_2` FOREIGN KEY (`property_id`) REFERENCES `properties` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `inquiries`
--
ALTER TABLE `inquiries`
  ADD CONSTRAINT `inquiries_ibfk_1` FOREIGN KEY (`property_id`) REFERENCES `properties` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `inquiries_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `offers`
--
ALTER TABLE `offers`
  ADD CONSTRAINT `offers_ibfk_1` FOREIGN KEY (`property_id`) REFERENCES `properties` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `offers_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`property_id`) REFERENCES `properties` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `properties`
--
ALTER TABLE `properties`
  ADD CONSTRAINT `properties_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `rentals`
--
ALTER TABLE `rentals`
  ADD CONSTRAINT `rentals_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `rentals_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `rentals_ibfk_3` FOREIGN KEY (`property_id`) REFERENCES `properties` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
