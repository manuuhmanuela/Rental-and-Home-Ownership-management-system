<?php
/* ============================================================
   NestSphere — Global config & helpers
   Save as: nestsphere/config.php
   ============================================================ */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!defined('BASE')) {
    define('BASE', '/nestsphere');
}

if (!defined('DB_HOST')) define('DB_HOST', 'localhost');
if (!defined('DB_USER')) define('DB_USER', 'root');
if (!defined('DB_PASS')) define('DB_PASS', '');
if (!defined('DB_NAME')) define('DB_NAME', 'nestsphere');

function db() {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $ex) {
            die('Database connection failed: ' . htmlspecialchars($ex->getMessage()));
        }
    }
    return $pdo;
}

function q($sql, $params = []) {
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt;
}

function e($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function user() {
    return $_SESSION['user'] ?? null;
}

function isLoggedIn() {
    return isset($_SESSION['user']['id']);
}

function isAdmin() {
    return isset($_SESSION['user']['role']) && $_SESSION['user']['role'] === 'admin';
}

function need_login() {
    if (!isLoggedIn()) {
        header('Location: ' . BASE . '/login.php');
        exit;
    }
}

function need_admin() {
    if (!isLoggedIn()) {
        header('Location: ' . BASE . '/login.php');
        exit;
    }
    if (!isAdmin()) {
        header('Location: ' . BASE . '/user/dashboard.php');
        exit;
    }
}

function go($path) {
    if (preg_match('#^https?://#i', $path)) {
        header('Location: ' . $path);
        exit;
    }
    if (strpos($path, BASE . '/') === 0 || $path === BASE) {
        header('Location: ' . $path);
    } else {
        header('Location: ' . BASE . '/' . ltrim($path, '/'));
    }
    exit;
}

function csrf_token() {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function field() {
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function check() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        return;
    }
    $sent = $_POST['csrf'] ?? '';
    if (!hash_equals($_SESSION['csrf'] ?? '', $sent)) {
        http_response_code(419);
        die('Session expired. Please go back and try again.');
    }
}

function logit($action) {
    $uid = $_SESSION['user']['id'] ?? null;
    try {
        q("INSERT INTO activity(user_id, action) VALUES(?,?)", [$uid, $action]);
    } catch (Throwable $ex) {
        // never break the page for a log failure
    }
}

function top($title = 'NestSphere') {
    $GLOBALS['__title'] = $title;
    require __DIR__ . '/includes/header.php';
}