<?php
require 'config.php';

if (user()) {
    go(user()['role'] === 'admin' ? '/admin/dashboard.php' : '/user/dashboard.php');
}

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check();
    $u = q("SELECT * FROM users WHERE email=?", [trim($_POST['email'] ?? '')])->fetch();
    if ($u && ($_POST['password'] ?? '') === $u['password']) {
        if ($u['status'] !== 'active') {
            $err = 'This account is suspended. Contact support.';
        } else {
            session_regenerate_id(true);
            $_SESSION['user'] = ['id' => $u['id'], 'name' => $u['name'], 'role' => $u['role']];
            logit('Logged in');
            go($u['role'] === 'admin' ? '/admin/dashboard.php' : '/user/dashboard.php');
        }
    } else {
        $err = 'Email or password is incorrect.';
    }
}

top('Log in');
?>
<section class="wrap narrow">
    <h1>Log in</h1>
    <?php if ($err): ?><p class="bad"><?=e($err)?></p><?php endif; ?>
    <form method="post" class="box">
        <?=field()?>
        <label>Email<input type="email" name="email" required value="<?=e($_POST['email'] ?? '')?>"></label>
        <label>Password<input type="password" name="password" required></label>
        <button class="btn">Log in</button>
    </form>
    <p class="muted">New here? <a href="<?=BASE?>/register.php">Create an account</a>.</p>
    <p class="muted" style="font-size:.85rem">Demo: <code>admin@nestsphere.co.ke</code> / <code>Admin@123</code> · <code>user@nestsphere.co.ke</code> / <code>Admin@123</code></p>
</section>
<?php include 'includes/footer.php'; ?>