<?php
require 'config.php';
require 'includes/cart_helpers.php';
need_login();

$totals = cart_totals();

top('My cart');
?>
<section class="wrap">
    <h1>My cart</h1>

    <?php if ($totals['count'] === 0): ?>
        <div class="box">
            <p>Your cart is empty.</p>
            <a class="btn" href="<?=BASE?>/properties.php">Browse properties</a>
        </div>
    <?php else: ?>
        <div class="box">
            <table class="tbl">
                <thead>
                    <tr><th>Property</th><th>Type</th><th>Price</th><th>Months</th><th>Subtotal</th><th></th></tr>
                </thead>
                <tbody>
                <?php foreach ($totals['items'] as $key => $it): ?>
                    <tr>
                        <td>
                            <strong><?=e($it['title'])?></strong><br>
                            <span class="muted"><?=e($it['location'])?></span>
                        </td>
                        <td><?= $it['type'] === 'rental' ? 'Rental' : 'Purchase' ?></td>
                        <td>KShs <?=number_format((float)$it['price'], 2)?></td>
                        <td>
                            <?php if ($it['type'] === 'rental'): ?>
                                <form method="post" action="<?=BASE?>/cart_action.php" style="display:flex;gap:6px;align-items:center">
                                    <?=field()?>
                                    <input type="hidden" name="action" value="update">
                                    <input type="hidden" name="key" value="<?=e($key)?>">
                                    <input type="number" name="months" min="1" max="24" value="<?=(int)$it['months']?>" style="width:70px">
                                    <button class="btn sm">Update</button>
                                </form>
                            <?php else: ?>
                                &mdash;
                            <?php endif; ?>
                        </td>
                        <td>KShs <?=number_format(line_subtotal($it), 2)?></td>
                        <td>
                            <a class="btn sm bad" href="<?=BASE?>/cart_action.php?action=remove&key=<?=urlencode($key)?>"
                               onclick="return confirm('Remove this item?')">Remove</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th colspan="4" style="text-align:right">Total</th>
                        <th colspan="2">KShs <?=number_format($totals['total'], 2)?></th>
                    </tr>
                </tfoot>
            </table>

            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:14px">
                <a class="btn" href="<?=BASE?>/checkout.php">Proceed to checkout</a>
                <a class="btn ghost" href="<?=BASE?>/cart_action.php?action=clear" onclick="return confirm('Clear the whole cart?')">Clear cart</a>
                <a class="btn ghost" href="<?=BASE?>/properties.php">Continue shopping</a>
            </div>
        </div>
    <?php endif; ?>
</section>
<?php include 'includes/footer.php'; ?>