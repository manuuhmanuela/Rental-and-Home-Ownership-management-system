<?php
require 'config.php';
require 'includes/cart_helpers.php';
need_login();

$pending = $_SESSION['pending_order'] ?? null;
if (!$pending) {
    go('/cart.php');
}

$amount   = (float)($pending['amount']  ?? 0);
$phoneRaw = (string)($pending['phone']  ?? '');
$orderRef = (string)($pending['order_ref'] ?? '');

$digits = preg_replace('/\D+/', '', $phoneRaw);
if (strlen($digits) === 10 && $digits[0] === '0') {
    $digits = '254' . substr($digits, 1);
} elseif (strlen($digits) === 9) {
    $digits = '254' . $digits;
}
$phoneDisplay = $digits ?: $phoneRaw;

$user = user();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>M-PESA Payment — <?=e($orderRef)?></title>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet"/>
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    :root {
      --green: #00a651; --green-d: #007d3c; --green-l: #e6f7ef;
      --red: #e53935; --gray: #f5f6fa; --border: #e0e4ed;
      --text: #1a1f2e; --muted: #6b7280; --white: #fff;
      --shadow: 0 4px 24px rgba(0,0,0,0.10);
    }
    body {
      font-family: 'DM Sans', sans-serif;
      background: linear-gradient(135deg, #e8f5e9 0%, #f0faf4 60%, #e3f2fd 100%);
      min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 16px;
    }
    .card { background: #fff; border-radius: 20px; box-shadow: var(--shadow); width: 100%; max-width: 420px; overflow: hidden; }
    .card-header { background: var(--green); padding: 22px 28px 18px; display: flex; align-items: center; gap: 14px; }
    .mpesa-logo { background: #fff; border-radius: 10px; padding: 6px 12px; display: flex; align-items: center; gap: 4px; }
    .mpesa-logo span { font-size: 18px; font-weight: 700; color: var(--green); letter-spacing: -0.5px; }
    .mpesa-logo .m { color: #e53935; }
    .header-text { color: #fff; }
    .header-text h2 { font-size: 16px; font-weight: 600; }
    .header-text p { font-size: 12px; opacity: 0.85; margin-top: 2px; }
    .merchant-bar { background: var(--green-l); border-bottom: 1px solid var(--border); padding: 12px 28px; display: flex; align-items: center; gap: 10px; }
    .merchant-icon { width: 36px; height: 36px; border-radius: 50%; background: var(--green); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 16px; font-weight: 700; }
    .merchant-name { font-size: 14px; font-weight: 600; color: var(--text); }
    .merchant-till { font-size: 12px; color: var(--muted); margin-top: 1px; }
    .card-body { padding: 24px 28px 28px; }
    .order-line { display: flex; justify-content: space-between; align-items: center; background: var(--gray); border: 1px solid var(--border); border-radius: 10px; padding: 10px 14px; margin-bottom: 18px; font-size: 13px; color: var(--muted); }
    .order-line strong { color: var(--text); }
    .field { margin-bottom: 18px; }
    .field label { display: block; font-size: 12px; font-weight: 600; color: var(--muted); text-transform: uppercase; letter-spacing: 0.6px; margin-bottom: 7px; }
    .input-wrap { position: relative; }
    .input-wrap .prefix { position: absolute; left: 14px; top: 50%; transform: translateY(-50%); font-size: 14px; font-weight: 600; color: var(--muted); pointer-events: none; }
    .input-wrap input { width: 100%; border: 1.5px solid var(--border); border-radius: 10px; padding: 13px 14px; font-size: 16px; font-family: inherit; color: var(--text); background: var(--gray); outline: none; transition: border 0.2s; }
    .input-wrap input.has-prefix { padding-left: 36px; }
    .input-wrap input:focus { border-color: var(--green); background: #fff; }
    .input-wrap input.error { border-color: var(--red); background: #fff8f8; }
    .quick-amounts { display: flex; gap: 8px; margin-top: 9px; flex-wrap: wrap; }
    .pill { border: 1.5px solid var(--border); border-radius: 20px; padding: 5px 14px; font-size: 13px; font-weight: 500; color: var(--muted); cursor: pointer; background: var(--gray); transition: all 0.18s; }
    .pill:hover, .pill.active { border-color: var(--green); background: var(--green-l); color: var(--green); }
    .hint { font-size: 12px; color: var(--muted); margin-top: 6px; }
    .hint span { color: var(--green); font-weight: 600; }
    .btn-pay { width: 100%; background: var(--green); color: #fff; border: none; border-radius: 12px; padding: 15px; font-size: 16px; font-weight: 700; font-family: inherit; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 10px; margin-top: 4px; }
    .btn-pay:hover { background: var(--green-d); }
    .btn-pay:disabled { background: #9ecfb6; cursor: not-allowed; }
    .btn-pay .spinner { width: 20px; height: 20px; border: 2.5px solid rgba(255,255,255,0.4); border-top-color: #fff; border-radius: 50%; animation: spin 0.7s linear infinite; }
    @keyframes spin { to { transform: rotate(360deg); } }
    .cancel-link { display: block; text-align: center; margin-top: 14px; font-size: 13px; color: var(--muted); text-decoration: none; }
    .cancel-link:hover { color: var(--red); }
    .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.45); z-index: 100; align-items: center; justify-content: center; padding: 16px; }
    .modal-overlay.show { display: flex; animation: fadeIn 0.2s; }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    .modal { background: #fff; border-radius: 20px; width: 100%; max-width: 360px; padding: 32px 28px 28px; text-align: center; box-shadow: 0 8px 40px rgba(0,0,0,0.18); animation: slideUp 0.25s ease; }
    @keyframes slideUp { from { transform: translateY(30px); opacity: 0; } to { transform: none; opacity: 1; } }
    .modal-icon { width: 64px; height: 64px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px; font-size: 28px; }
    .modal-icon.waiting { background: #fff8e1; color: #f9a825; animation: pulse 1.5s infinite; }
    .modal-icon.success { background: var(--green-l); color: var(--green); }
    .modal-icon.error { background: #fdecea; color: var(--red); }
    @keyframes pulse { 0%,100% { transform: scale(1); } 50% { transform: scale(1.08); } }
    .modal h3 { font-size: 18px; font-weight: 700; color: var(--text); margin-bottom: 8px; }
    .modal p { font-size: 14px; color: var(--muted); line-height: 1.6; }
    .modal .amount-display { font-size: 28px; font-weight: 700; color: var(--green); margin: 12px 0 4px; }
    .modal .phone-display { font-size: 14px; color: var(--muted); margin-bottom: 16px; }
    .modal-steps { background: var(--gray); border-radius: 12px; padding: 14px 16px; margin: 16px 0; text-align: left; }
    .modal-steps p { font-size: 13px; color: var(--text); margin-bottom: 6px; font-weight: 600; }
    .step { display: flex; align-items: flex-start; gap: 10px; font-size: 13px; color: var(--muted); margin-top: 7px; line-height: 1.4; }
    .step-num { width: 20px; height: 20px; border-radius: 50%; background: var(--green); color: #fff; font-size: 11px; font-weight: 700; flex-shrink: 0; display: flex; align-items: center; justify-content: center; }
    .btn-close-modal { width: 100%; border: 1.5px solid var(--border); background: var(--gray); border-radius: 10px; padding: 12px; font-size: 14px; font-weight: 600; color: var(--text); cursor: pointer; font-family: inherit; margin-top: 4px; text-decoration: none; display: block; }
    .btn-close-modal:hover { background: #eaedf4; }
    .footer-note { text-align: center; font-size: 12px; color: var(--muted); margin-top: 20px; padding-top: 16px; border-top: 1px solid var(--border); display: flex; align-items: center; justify-content: center; gap: 6px; }
    .secure-badge { display: inline-flex; align-items: center; gap: 4px; background: var(--green-l); color: var(--green); border-radius: 20px; padding: 3px 10px; font-size: 11px; font-weight: 600; }
    @media (max-width: 480px) { .card-body { padding: 20px; } .card-header { padding: 18px 20px 14px; } .merchant-bar { padding: 10px 20px; } }
  </style>
</head>
<body>

<div class="card">
  <div class="card-header">
    <div class="mpesa-logo"><span class="m">M</span><span>-PESA</span></div>
    <div class="header-text"><h2>Lipa na M-PESA</h2><p>Secure mobile payment</p></div>
  </div>

  <div class="merchant-bar">
    <div class="merchant-icon">N</div>
    <div>
      <div class="merchant-name">NestSphere</div>
      <div class="merchant-till">Order: <?=e($orderRef)?></div>
    </div>
  </div>

  <div class="card-body">
    <div class="order-line"><span>Amount due</span><strong>KES <?=number_format($amount, 2)?></strong></div>

    <form id="payForm" action="stk_initiate.php" method="POST">
      <input type="hidden" name="order_ref" value="<?=e($orderRef)?>">
      <input type="hidden" name="order_id"  value="<?= (int)($pending['order_id'] ?? 0) ?>">

      <div class="field">
        <label>Amount (KES)</label>
        <div class="input-wrap">
          <span class="prefix">KES</span>
          <input type="number" name="amount" id="amount" class="has-prefix" placeholder="0.00" min="1" required value="<?=htmlspecialchars(number_format($amount, 2, '.', ''))?>" />
        </div>
        <div class="quick-amounts">
          <span class="pill" data-val="<?= (int)$amount ?>"><?= number_format($amount, 0) ?></span>
          <span class="pill" data-val="<?= (int)($amount * 2) ?>"><?= number_format($amount * 2, 0) ?></span>
          <span class="pill" data-val="<?= (int)($amount / 2) ?>"><?= number_format($amount / 2, 0) ?></span>
        </div>
      </div>

      <div class="field">
        <label>M-PESA Phone Number</label>
        <div class="input-wrap">
          <span class="prefix">+</span>
          <input type="tel" name="phone" id="phone" class="has-prefix" placeholder="254712345678" maxlength="12" required value="<?=htmlspecialchars($phoneDisplay)?>" />
        </div>
        <p class="hint">Format: <span>2547XXXXXXXX</span> (12 digits, no spaces)</p>
      </div>

      <button type="submit" class="btn-pay" id="payBtn"><span id="btnText">Pay Now</span></button>
    </form>

    <a href="checkout.php" class="cancel-link">Cancel and go back to checkout</a>

    <div class="footer-note">
      <span class="secure-badge">🔒 Secured</span> Powered by Safaricom M-PESA Daraja API
    </div>
  </div>
</div>

<div class="modal-overlay" id="waitingModal">
  <div class="modal">
    <div class="modal-icon waiting">📲</div>
    <h3>Check Your Phone</h3>
    <div class="amount-display" id="modalAmount"></div>
    <div class="phone-display" id="modalPhone"></div>
    <div class="modal-steps">
      <p>Follow these steps:</p>
      <div class="step"><div class="step-num">1</div><span>An M-PESA prompt has been sent to your phone</span></div>
      <div class="step"><div class="step-num">2</div><span>Enter your M-PESA PIN to confirm the payment</span></div>
      <div class="step"><div class="step-num">3</div><span>You will receive an SMS confirmation shortly</span></div>
    </div>
    <p style="font-size:12px;color:#9ca3af;">Waiting for confirmation… do not close this page</p>
  </div>
</div>

<div class="modal-overlay" id="successModal">
  <div class="modal">
    <div class="modal-icon success">✓</div>
    <h3>Payment Successful!</h3>
    <div class="amount-display" id="successAmount"></div>
    <p>Your payment has been received. You will get an M-PESA confirmation SMS shortly.</p>
    <a class="btn-close-modal" href="index.php">Done</a>
  </div>
</div>

<div class="modal-overlay" id="errorModal">
  <div class="modal">
    <div class="modal-icon error">✕</div>
    <h3>Payment Failed</h3>
    <p id="errorMsg">Something went wrong. Please try again.</p>
    <button class="btn-close-modal" style="margin-top:18px" onclick="closeAllModals()">Try Again</button>
  </div>
</div>

<script>
  document.querySelectorAll('.pill').forEach(pill => {
    pill.addEventListener('click', () => {
      document.querySelectorAll('.pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      document.getElementById('amount').value = pill.dataset.val;
    });
  });
  document.getElementById('amount').addEventListener('input', () => {
    document.querySelectorAll('.pill').forEach(p => p.classList.remove('active'));
  });
  function closeAllModals() {
    document.querySelectorAll('.modal-overlay').forEach(m => m.classList.remove('show'));
    const btn = document.getElementById('payBtn');
    btn.disabled = false;
    btn.innerHTML = '<span>Pay Now</span>';
  }
  document.getElementById('payForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const amount = document.getElementById('amount').value.trim();
    const phone  = document.getElementById('phone').value.trim();
    if (!amount || isNaN(amount) || Number(amount) < 1) {
      document.getElementById('amount').classList.add('error'); return;
    }
    document.getElementById('amount').classList.remove('error');
    if (!/^2547\d{8}$|^2541\d{8}$/.test(phone)) {
      document.getElementById('phone').classList.add('error');
      alert('Please enter a valid Safaricom number starting with 2547 or 2541 (12 digits).'); return;
    }
    document.getElementById('phone').classList.remove('error');

    const btn = document.getElementById('payBtn');
    btn.disabled = true;
    btn.innerHTML = '<div class="spinner"></div><span>Sending prompt…</span>';

    document.getElementById('modalAmount').textContent = 'KES ' + Number(amount).toLocaleString();
    document.getElementById('modalPhone').textContent = '+' + phone;
    document.getElementById('waitingModal').classList.add('show');

    const formData = new FormData(this);
    formData.append('submit', 'submit');

    fetch('stk_initiate.php', { method: 'POST', body: formData })
      .then(r => r.json())
      .then(data => {
        if (data.ResponseCode === '0') {
          markOrderPaid().then(() => {
            document.getElementById('waitingModal').classList.remove('show');
            document.getElementById('successAmount').textContent = 'KES ' + Number(amount).toLocaleString();
            document.getElementById('successModal').classList.add('show');
          });
        } else {
          document.getElementById('waitingModal').classList.remove('show');
          document.getElementById('errorMsg').textContent = data.errorMessage || data.ResponseDescription || 'Payment request failed. Please try again.';
          document.getElementById('errorModal').classList.add('show');
        }
        btn.disabled = false;
        btn.innerHTML = '<span>Pay Now</span>';
      })
      .catch(() => {
        document.getElementById('waitingModal').classList.remove('show');
        document.getElementById('errorMsg').textContent = 'Network error. Check your connection and try again.';
        document.getElementById('errorModal').classList.add('show');
        btn.disabled = false;
        btn.innerHTML = '<span>Pay Now</span>';
      });
  });
  function markOrderPaid() {
    return fetch('mpesa_finalize.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        order_ref: '<?=e($orderRef)?>',
        order_id: '<?= (int)($pending['order_id'] ?? 0) ?>'
      })
    }).then(r => r.json()).catch(() => ({ ok: false }));
  }
</script>
</body>
</html>