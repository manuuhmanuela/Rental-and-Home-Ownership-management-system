<?php
require '../config.php';
need_admin();

$totalUsers   = (int)db()->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalProps   = (int)db()->query("SELECT COUNT(*) FROM properties")->fetchColumn();
$pendingProps = (int)db()->query("SELECT COUNT(*) FROM properties WHERE status='pending'")->fetchColumn();
$soldProps    = (int)db()->query("SELECT COUNT(*) FROM properties WHERE status='sold'")->fetchColumn();
$unreadMsgs   = (int)db()->query("SELECT COUNT(*) FROM messages WHERE is_read=0")->fetchColumn();

$o = db()->query("SELECT
    COUNT(*) AS total,
    SUM(CASE WHEN status='paid' THEN 1 ELSE 0 END) AS paid,
    SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) AS pending,
    SUM(CASE WHEN status='paid' THEN total_amount ELSE 0 END) AS revenue,
    SUM(CASE WHEN status='paid' AND DATE(paid_at)=CURDATE() THEN total_amount ELSE 0 END) AS revenue_today
    FROM orders")->fetch();

$activeRentals = (int)db()->query("SELECT COUNT(*) FROM rentals WHERE status='active'")->fetchColumn();
$recentOrders  = db()->query("SELECT o.*, u.name AS user_name FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.created_at DESC LIMIT 6")->fetchAll();
$recentLogs    = db()->query("SELECT a.*, u.name AS user_name FROM activity a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.created_at DESC LIMIT 8")->fetchAll();

top('Admin Dashboard');
?>
<section class="wrap">
    <h1>Admin Dashboard</h1>

    <div class="box" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px">
        <div><small class="muted">Revenue</small><div style="font-size:1.3rem;font-weight:700">KShs <?=number_format((float)$o['revenue'], 2)?></div></div>
        <div><small class="muted">Today</small><div style="font-size:1.3rem;font-weight:700;color:#16a34a">KShs <?=number_format((float)$o['revenue_today'], 2)?></div></div>
        <div><small class="muted">Orders</small><div style="font-size:1.3rem;font-weight:700"><?=(int)$o['total']?></div></div>
        <div><small class="muted">Pending orders</small><div style="font-size:1.3rem;font-weight:700;color:#d97706"><?=(int)$o['pending']?></div></div>
        <div><small class="muted">Active rentals</small><div style="font-size:1.3rem;font-weight:700"><?=$activeRentals?></div></div>
        <div><small class="muted">Users</small><div style="font-size:1.3rem;font-weight:700"><?=$totalUsers?></div></div>
        
        <div><small class="muted">Properties</small><div style="font-size:1.3rem;font-weight:700"><?=$totalProps?></div></div>
        <div><small class="muted">Pending approvals</small><div style="font-size:1.3rem;font-weight:700;color:#d97706"><?=$pendingProps?></div></div>
        <div><small class="muted">Sold</small><div style="font-size:1.3rem;font-weight:700"><?=$soldProps?></div></div>
        <div><small class="muted">Unread messages</small><div style="font-size:1.3rem;font-weight:700;color:#dc2626"><?=$unreadMsgs?></div></div>
    </div>

    <div class="box">
        <h2>Quick actions</h2>
        <a class="btn" href="<?=BASE?>/admin/orders.php">Orders</a>
        <a class="btn ghost" href="<?=BASE?>/admin/rentals.php">Rentals</a>
        <a class="btn ghost" href="<?=BASE?>/admin/properties.php">Properties</a>
        <a class="btn ghost" href="<?=BASE?>/admin/users.php">Users</a>
        <a class="btn ghost" href="<?=BASE?>/admin/messages.php">Messages</a>
        <a class="btn ghost" href="<?=BASE?>/mail.php">✉️ Mail</a>
    </div>

    <div class="box">
        <h2>Recent orders</h2>
        <?php if (!$recentOrders): ?><p class="muted">No orders yet.</p>
        <?php else: ?>
            <table class="tbl">
                <thead><tr><th>Ref</th><th>Customer</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead>
                <tbody>
                <?php foreach ($recentOrders as $r): ?>
                    <tr>
                        <td><a href="<?=BASE?>/admin/order_view.php?id=<?=(int)$r['order_id']?>"><?=e($r['order_ref'])?></a></td>
                        <td><?=e($r['user_name'])?></td>
                        <td>KShs <?=number_format((float)$r['total_amount'], 2)?></td>
                        <td><?=e($r['status'])?></td>
                        <td><?=date('d M Y', strtotime($r['created_at']))?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <div class="box">
        <h2>Recent activity</h2>
        <?php if (!$recentLogs): ?><p class="muted">No activity yet.</p>
        <?php else: ?>
            <table class="tbl">
                <thead><tr><th>User</th><th>Action</th><th>When</th></tr></thead>
                <tbody>
                <?php foreach ($recentLogs as $l): ?>
                    <tr>
                        <td><?=e($l['user_name'] ?: 'System')?></td>
                        <td><?=e($l['action'])?></td>
                        <td><?=date('d M Y H:i', strtotime($l['created_at']))?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</section>
<?php include '../includes/footer.php'; ?>