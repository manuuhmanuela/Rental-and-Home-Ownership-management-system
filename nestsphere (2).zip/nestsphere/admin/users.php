<?php
require '../config.php';
need_admin();

$err = '';
$ok  = '';

/* ============================================================
   HANDLE POST
   ============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check();
    $action = $_POST['action'] ?? '';

    /* ---------- ADD USER ---------- */
    if ($action === 'add') {
        $n  = trim($_POST['name'] ?? '');
        $e  = trim($_POST['email'] ?? '');
        $p  = trim($_POST['phone'] ?? '');
        $c  = trim($_POST['city'] ?? '');
        $b  = trim($_POST['bio'] ?? '');
        $pw = $_POST['password'] ?? '';
        $r  = ($_POST['role'] ?? 'user') === 'admin' ? 'admin' : 'user';
        $s  = ($_POST['status'] ?? 'active') === 'suspended' ? 'suspended' : 'active';

        if ($n === '' || $e === '' || $p === '' || $pw === '') {
            $err = 'Name, email, phone and password are required.';
        } elseif (!filter_var($e, FILTER_VALIDATE_EMAIL)) {
            $err = 'Invalid email address.';
        } elseif (strlen($pw) < 6) {
            $err = 'Password must be at least 6 characters.';
        } elseif (q("SELECT id FROM users WHERE email=?", [$e])->fetch()) {
            $err = 'That email is already registered.';
        } else {
            q("INSERT INTO users(name,email,phone,city,bio,password,role,status)
               VALUES(?,?,?,?,?,?,?,?)",
                [$n, $e, $p, $c, $b, $pw, $r, $s]);
            logit("Admin added user $e");
            $ok = "User \"$n\" created.";
        }
    }

    /* ---------- SUSPEND / ACTIVATE ---------- */
    elseif ($action === 'status') {
        $id = (int)($_POST['id'] ?? 0);
        $s  = ($_POST['status'] ?? 'active') === 'suspended' ? 'suspended' : 'active';
        if ($id) {
            q("UPDATE users SET status=? WHERE id=? AND role<>'admin'", [$s, $id]);
            logit("Admin set user #$id status to $s");
            $ok = 'Status updated.';
        }
    }

    /* ---------- RESET PASSWORD ---------- */
    elseif ($action === 'password') {
        $id = (int)($_POST['id'] ?? 0);
        $pw = $_POST['password'] ?? '';
        if ($id && strlen($pw) >= 6) {
            q("UPDATE users SET password=? WHERE id=?", [$pw, $id]);
            logit("Admin reset password for user #$id");
            $ok = 'Password updated.';
        } else {
            $err = 'Password must be at least 6 characters.';
        }
    }

    /* ---------- DELETE ---------- */
    elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            q("DELETE FROM users WHERE id=? AND role<>'admin'", [$id]);
            logit("Admin deleted user #$id");
            $ok = 'User deleted.';
        }
    }
}

/* ============================================================
   LIST + FILTERS
   ============================================================ */
$filterRole   = $_GET['role'] ?? '';
$filterStatus = $_GET['status'] ?? '';
$search       = trim($_GET['q'] ?? '');

$sql = "SELECT * FROM users WHERE 1=1";
$params = [];
if (in_array($filterRole, ['user','admin'], true)) {
    $sql .= " AND role = ?";
    $params[] = $filterRole;
}
if (in_array($filterStatus, ['active','suspended'], true)) {
    $sql .= " AND status = ?";
    $params[] = $filterStatus;
}
if ($search !== '') {
    $sql .= " AND (name LIKE ? OR email LIKE ? OR phone LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
$sql .= " ORDER BY created_at DESC";

$stmt = db()->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll();

/* Summary */
$totalUsers   = (int)db()->query("SELECT COUNT(*) FROM users")->fetchColumn();
$adminUsers   = (int)db()->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn();
$activeUsers  = (int)db()->query("SELECT COUNT(*) FROM users WHERE status='active'")->fetchColumn();
$suspendUsers = (int)db()->query("SELECT COUNT(*) FROM users WHERE status='suspended'")->fetchColumn();

top('Manage users');
?>
<style>
    .kpi-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 12px;
        margin-bottom: 18px;
    }
    .kpi {
        background: #fff; border: 1px solid #e5e7eb; border-radius: 12px;
        padding: 14px 16px; box-shadow: 0 2px 8px rgba(15,23,42,.04);
    }
    .kpi .l { font-size: .72rem; text-transform: uppercase; letter-spacing: .4px; color: #6b7280; font-weight: 700; }
    .kpi .v { font-size: 1.35rem; font-weight: 800; color: #111827; margin-top: 4px; }

    .add-box {
        background: #f8fafc; border: 1px solid #e5e7eb;
        border-radius: 12px; padding: 16px; margin-bottom: 18px;
    }
    .add-box h2 { margin: 0 0 12px; font-size: 1rem; }
    .form-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 10px;
    }

    .filters {
        display: flex; gap: 10px; flex-wrap: wrap;
        align-items: end; margin-bottom: 14px;
    }
    .filters label { margin: 0; flex: 1; min-width: 160px; }

    .inline-actions { display: flex; gap: 6px; flex-wrap: wrap; align-items: center; }
    .inline-actions form { display: inline-flex; gap: 4px; align-items: center; margin: 0; }
    .inline-actions input[type="text"] {
        padding: 5px 8px; border: 1px solid #d1d5db; border-radius: 6px;
        font-size: .8rem; width: 110px;
    }

    .badge {
        display: inline-block; padding: 2px 8px; border-radius: 999px;
        font-size: .7rem; font-weight: 700; text-transform: uppercase; letter-spacing: .3px;
    }
    .badge.ok   { background:#dcfce7; color:#166534; }
    .badge.warn { background:#fef3c7; color:#92400e; }
    .badge.bad  { background:#fee2e2; color:#991b1b; }
    .badge.muted{ background:#e5e7eb; color:#374151; }
</style>

<section class="wrap wide">
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:16px">
        <div>
            <h1 style="margin:0">Manage users</h1>
            <p class="muted" style="margin:4px 0 0"><?=$totalUsers?> total accounts</p>
        </div>
        <a class="btn ghost" href="<?=BASE?>/admin/dashboard.php">&larr; Dashboard</a>
    </div>

    <?php if ($err): ?><div class="box bad"><?=e($err)?></div><?php endif; ?>
    <?php if ($ok): ?><div class="box good"><?=e($ok)?></div><?php endif; ?>

    <!-- KPI cards -->
    <div class="kpi-grid">
        <div class="kpi"><div class="l">Total users</div><div class="v"><?=$totalUsers?></div></div>
        <div class="kpi"><div class="l">Admins</div><div class="v"><?=$adminUsers?></div></div>
        <div class="kpi"><div class="l">Active</div><div class="v" style="color:#16a34a"><?=$activeUsers?></div></div>
        <div class="kpi"><div class="l">Suspended</div><div class="v" style="color:#dc2626"><?=$suspendUsers?></div></div>
    </div>

    <!-- ADD USER -->
    <div class="add-box">
        <h2>➕ Add a user</h2>
        <form method="post">
            <?=field()?>
            <input type="hidden" name="action" value="add">

            <div class="form-grid">
                <label>Name<input type="text" name="name" required maxlength="100"></label>
                <label>Email<input type="email" name="email" required maxlength="120"></label>
                <label>Phone<input type="text" name="phone" required maxlength="20"></label>
                <label>City<input type="text" name="city" maxlength="80"></label>
                <label>Password<input type="text" name="password" required minlength="6"></label>
                <label>Role
                    <select name="role">
                        <option value="user">User</option>
                        <option value="admin">Admin</option>
                    </select>
                </label>
                <label>Status
                    <select name="status">
                        <option value="active">Active</option>
                        <option value="suspended">Suspended</option>
                    </select>
                </label>
            </div>

            <label>Bio<textarea name="bio" rows="2"></textarea></label>

            <button class="btn">Add user</button>
        </form>
    </div>

    <!-- FILTERS -->
    <form method="get" class="filters box">
        <label>Search
            <input type="text" name="q" value="<?=e($search)?>" placeholder="Name, email, phone">
        </label>
        <label>Role
            <select name="role">
                <option value="">Any</option>
                <option value="user" <?=$filterRole==='user'?'selected':''?>>User</option>
                <option value="admin" <?=$filterRole==='admin'?'selected':''?>>Admin</option>
            </select>
        </label>
        <label>Status
            <select name="status">
                <option value="">Any</option>
                <option value="active" <?=$filterStatus==='active'?'selected':''?>>Active</option>
                <option value="suspended" <?=$filterStatus==='suspended'?'selected':''?>>Suspended</option>
            </select>
        </label>
        <button class="btn">Filter</button>
        <a class="btn ghost" href="<?=BASE?>/admin/users.php">Reset</a>
    </form>

    <!-- LIST -->
    <div class="box" style="overflow-x:auto">
        <?php if (!$users): ?>
            <p class="muted">No users found.</p>
        <?php else: ?>
            <table class="tbl">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>User</th>
                        <th>Phone / City</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Joined</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($users as $u): ?>
                    <tr>
                        <td><?=(int)$u['id']?></td>
                        <td>
                            <strong><?=e($u['name'])?></strong><br>
                            <span class="muted" style="font-size:.78rem"><?=e($u['email'])?></span>
                        </td>
                        <td>
                            <?=e($u['phone'])?><br>
                            <span class="muted" style="font-size:.78rem"><?=e($u['city'] ?: '—')?></span>
                        </td>
                        <td>
                            <span class="badge <?= $u['role']==='admin'?'warn':'muted' ?>">
                                <?=e($u['role'])?>
                            </span>
                        </td>
                        <td>
                            <span class="badge <?= $u['status']==='active'?'ok':'bad' ?>">
                                <?=e($u['status'])?>
                            </span>
                        </td>
                        <td class="muted"><?=date('d M Y', strtotime($u['created_at']))?></td>
                        <td>
                            <div class="inline-actions">
                                <?php if ($u['role'] !== 'admin'): ?>
                                    <!-- Suspend / activate -->
                                    <form method="post">
                                        <?=field()?>
                                        <input type="hidden" name="action" value="status">
                                        <input type="hidden" name="id" value="<?=(int)$u['id']?>">
                                        <input type="hidden" name="status" value="<?= $u['status']==='active'?'suspended':'active' ?>">
                                        <button class="btn sm <?= $u['status']==='active'?'bad':'ok' ?>">
                                            <?= $u['status']==='active' ? 'Suspend' : 'Activate' ?>
                                        </button>
                                    </form>

                                    <!-- Delete -->
                                    <form method="post" onsubmit="return confirm('Delete this user permanently?')">
                                        <?=field()?>
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?=(int)$u['id']?>">
                                        <button class="btn sm bad">Delete</button>
                                    </form>
                                <?php endif; ?>

                                <!-- Reset password -->
                                <form method="post">
                                    <?=field()?>
                                    <input type="hidden" name="action" value="password">
                                    <input type="hidden" name="id" value="<?=(int)$u['id']?>">
                                    <input type="text" name="password" placeholder="new password" required>
                                    <button class="btn sm">Reset</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</section>
<?php include '../includes/footer.php'; ?>