<?php
require '../config.php';
need_admin();

$id   = (int)($_GET['id'] ?? 0);
$from = $_GET['from'] ?? date('Y-m-01');
$to   = $_GET['to']   ?? date('Y-m-d');

$stmt = db()->prepare("SELECT o.*, u.name AS user_name, u.email AS user_email, u.phone AS user_phone, u.city AS user_city
                       FROM orders o JOIN users u ON u.id = o.user_id
                       WHERE o.order_id = ?");
$stmt->execute([$id]);
$o = $stmt->fetch();

if (!$o) {
    http_response_code(404);
    die('Order not found.');
}

$items = db()->prepare("SELECT oi.*, p.title, p.location, p.type AS ptype, p.purpose, p.size
                        FROM order_items oi
                        JOIN properties p ON p.id = oi.property_id
                        WHERE oi.order_id = ?
                        ORDER BY oi.item_id ASC");
$items->execute([$id]);
$items = $items->fetchAll();

$rentals = db()->prepare("SELECT r.*, p.title
                          FROM rentals r JOIN properties p ON p.id = r.property_id
                          WHERE r.order_id = ?");
$rentals->execute([$id]);
$rentals = $rentals->fetchAll();

$subtotal = 0.0;
foreach ($items as $it) $subtotal += (float)$it['subtotal'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Report — <?=e($o['order_ref'])?></title>
    <style>
        *, *::before, *::after { box-sizing: border-box; }
        body {
            font-family: system-ui, -apple-system, "Segoe UI", Roboto, Arial, sans-serif;
            margin: 0;
            padding: 24px;
            color: #111827;
            background: #fff;
            line-height: 1.5;
            font-size: 13px;
        }
        .container { max-width: 780px; margin: 0 auto; }
        h1 { font-size: 20px; margin: 0 0 4px; }
        h2 {
            font-size: 13px;
            margin: 24px 0 8px;
            text-transform: uppercase;
            letter-spacing: .5px;
            color: #475569;
            border-bottom: 1px solid #e5e7eb;
            padding-bottom: 4px;
        }
        .meta { color: #6b7280; font-size: 12px; margin-bottom: 16px; }
        .brand {
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 2px solid #2563eb;
            padding-bottom: 10px;
            margin-bottom: 18px;
        }
        .brand strong { font-size: 16px; color: #2563eb; }
        .brand span { font-size: 11px; color: #6b7280; }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 4px;
        }
        th, td {
            text-align: left;
            padding: 7px 9px;
            border: 1px solid #e5e7eb;
            vertical-align: top;
            font-size: 12.5px;
        }
        th { background: #f1f5f9; font-weight: 600; color: #334155; }
        .kv-table th { width: 180px; background: #f8fafc; }
        .right { text-align: right; }
        .totals { font-weight: 700; background: #f8fafc; }

        .section-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 8px;
        }
        .section-grid > div > h2 { margin-top: 0; }

        .signature {
            display: flex;
            justify-content: space-between;
            margin-top: 40px;
            font-size: 12px;
        }
        .signature .line {
            width: 45%;
            border-top: 1px dashed #94a3b8;
            padding-top: 6px;
            color: #475569;
            margin-top: 30px;
        }

        .footer-note {
            margin-top: 24px;
            font-size: 11px;
            color: #6b7280;
            text-align: center;
            border-top: 1px solid #e5e7eb;
            padding-top: 10px;
        }

        .badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 999px;
            font-size: 10.5px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .3px;
            border: 1px solid #d1d5db;
        }
        .badge.ok   { background: #dcfce7; color: #166534; border-color: #bbf7d0; }
        .badge.warn { background: #fef3c7; color: #92400e; border-color: #fde68a; }
        .badge.bad  { background: #fee2e2; color: #991b1b; border-color: #fecaca; }

        .no-print { text-align: center; margin-bottom: 16px; }
        .no-print button {
            padding: 8px 14px;
            border-radius: 8px;
            border: 1px solid #d1d5db;
            background: #fff;
            cursor: pointer;
            font-weight: 600;
            font-size: 12px;
        }

        @media print {
            body { padding: 0; }
            .no-print { display: none !important; }
            .container { max-width: 100%; }
            h1 { font-size: 16px; }
            h2 { font-size: 11px; }
            th, td { font-size: 11px; padding: 5px 6px; }
            .signature { margin-top: 30px; }
        }
    </style>
</head>
<body>

<div class="container">

    <div class="no-print">
        <button onclick="window.print()">🖨️ Print this report</button>
        <button onclick="window.close()">Close</button>
    </div>

    <div class="brand">
        <div>
            <strong>NestSphere</strong><br>
            <span>Property Marketplace · Nairobi, Kenya</span>
        </div>
        <div style="text-align:right">
            <strong>Order report</strong><br>
            <span><?=e($o['order_ref'])?></span>
        </div>
    </div>

    <h1>Order summary</h1>
    <div class="meta">
        Report period: <?=e(date('d M Y', strtotime($from)))?> → <?=e(date('d M Y', strtotime($to)))?>
        &middot; Printed <?=date('d M Y H:i')?>
    </div>

    <div class="section-grid">
        <div>
            <h2>Customer</h2>
            <table class="kv-table">
                <tr><th>Name</th><td><?=e($o['user_name'])?></td></tr>
                <tr><th>Email</th><td><?=e($o['user_email'])?></td></tr>
                <tr><th>Phone</th><td><?=e($o['user_phone'])?></td></tr>
                <tr><th>City</th><td><?=e($o['user_city'] ?: '—')?></td></tr>
            </table>
        </div>
        <div>
            <h2>Order</h2>
            <table class="kv-table">
                <tr><th>Reference</th><td><?=e($o['order_ref'])?></td></tr>
                <tr><th>Type</th><td><?=ucfirst(e($o['order_type']))?></td></tr>
                <tr><th>Status</th><td>
                    <span class="badge <?= $o['status']==='paid'?'ok':($o['status']==='pending'?'warn':'bad') ?>">
                        <?=e($o['status'])?>
                    </span>
                </td></tr>
                <tr><th>Payment method</th><td><?=e($o['payment_method'] ?: '—')?></td></tr>
                <tr><th>Payment ref</th><td><?=e($o['payment_ref'] ?: '—')?></td></tr>
                <tr><th>Paid at</th><td><?= $o['paid_at'] ? e(date('d M Y H:i', strtotime($o['paid_at']))) : '—' ?></td></tr>
                <tr><th>Created</th><td><?=e(date('d M Y H:i', strtotime($o['created_at'])))?></td></tr>
            </table>
        </div>
    </div>

    <h2>Items (<?=count($items)?>)</h2>
    <table>
        <thead>
            <tr>
                <th>Property</th>
                <th>Type</th>
                <th class="right">Price</th>
                <th class="right">Months</th>
                <th class="right">Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($items as $it): ?>
                <tr>
                    <td>
                        <strong><?=e($it['title'])?></strong><br>
                        <span style="color:#6b7280;font-size:11px"><?=e($it['location'])?> · <?=e($it['ptype'])?></span>
                    </td>
                    <td><?= $it['item_type'] === 'rental' ? 'Rental' : 'Purchase' ?></td>
                    <td class="right">KShs <?=number_format((float)$it['price'], 2)?></td>
                    <td class="right"><?= $it['item_type'] === 'rental' ? (int)$it['months'] : '—' ?></td>
                    <td class="right">KShs <?=number_format((float)$it['subtotal'], 2)?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr class="totals">
                <td colspan="4" class="right">Subtotal</td>
                <td class="right">KShs <?=number_format($subtotal, 2)?></td>
            </tr>
            <tr class="totals">
                <td colspan="4" class="right">TOTAL</td>
                <td class="right">KShs <?=number_format((float)$o['total_amount'], 2)?></td>
            </tr>
        </tfoot>
    </table>

    <?php if ($rentals): ?>
        <h2>Rental agreements</h2>
        <table>
            <thead>
                <tr>
                    <th>Property</th>
                    <th class="right">Monthly rent</th>
                    <th class="right">Months</th>
                    <th>Start</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rentals as $r): ?>
                    <tr>
                        <td><?=e($r['title'])?></td>
                        <td class="right">KShs <?=number_format((float)$r['monthly_rent'], 2)?></td>
                        <td class="right"><?=(int)$r['months']?></td>
                        <td><?=e($r['start_date'])?></td>
                        <td><?=e($r['status'])?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <div class="signature">
        <div class="line">Prepared by (Admin)</div>
        <div class="line">Customer signature</div>
    </div>

    <div class="footer-note">
        Generated from NestSphere · <?=e(date('d M Y H:i'))?> ·
        Report period <?=e(date('d M Y', strtotime($from)))?> – <?=e(date('d M Y', strtotime($to)))?>
    </div>

</div>

<script>
    // Auto-print when opened in the hidden iframe
    if (window.opener || window.self !== window.top || location.search.indexOf('autoprint=1') !== -1) {
        // slight delay so fonts/images can render
        setTimeout(function () {
            window.focus();
            window.print();
        }, 300);
    }
</script>
</body>
</html>