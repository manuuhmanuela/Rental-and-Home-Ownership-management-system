<?php
require '../config.php';
need_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    go('/admin/orders.php');
}
check();

$action  = $_POST['action'] ?? '';
$orderId = (int)($_POST['order_id'] ?? 0);
if (!$orderId) go('/admin/orders.php');

$stmt = db()->prepare("SELECT * FROM orders WHERE order_id=?");
$stmt->execute([$orderId]);
$order = $stmt->fetch();
if (!$order) go('/admin/orders.php');

if ($action === 'mark_paid' && $order['status'] !== 'paid') {
    db()->prepare("UPDATE orders SET status='paid', payment_method=COALESCE(payment_method,'manual'), payment_ref=COALESCE(payment_ref,?), paid_at=NOW() WHERE order_id=?")
        ->execute(['ADMIN-' . strtoupper(bin2hex(random_bytes(4))), $orderId]);
    $items = db()->prepare("SELECT property_id, item_type FROM order_items WHERE order_id=?");
    $items->execute([$orderId]);
    foreach ($items->fetchAll() as $row) {
        if ($row['item_type'] === 'purchase') {
            db()->prepare("UPDATE properties SET status='sold' WHERE id=?")->execute([$row['property_id']]);
        }
    }
    logit("Admin marked order #$orderId as paid");
}

if ($action === 'cancel' && $order['status'] === 'pending') {
    db()->prepare("UPDATE orders SET status='cancelled' WHERE order_id=?")->execute([$orderId]);
    logit("Admin cancelled order #$orderId");
}

go('/admin/order_view.php?id=' . $orderId);