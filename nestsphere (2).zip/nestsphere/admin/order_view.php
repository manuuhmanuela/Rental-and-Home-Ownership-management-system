<?php
require '../config.php';
need_admin();

$id = (int)($_GET['id'] ?? 0);
$stmt = db()->prepare("SELECT o.*, u.name AS user_name, u.email AS user_email, u.phone AS user_phone, u.city AS user_city
                       FROM orders o JOIN users u ON u.id=o.user_id WHERE o.order_id=?");
$stmt->execute([$id]);
$o = $stmt->fetch();
if (!$o) { http_response_code(404); die('Order not found.'); }

$items = db()->prepare("SELECT oi.*, p.title, p.location FROM order_items oi JOIN properties p ON p.id=oi.property_id WHERE oi.order_id=?");
$items->execute([$id]);
$items = $items->fetchAll();

top('Order ' . $o['order_ref']);
?>
<section class="wrap">
    <a href="orders.php" class="muted">&larr; Back to orders</a>
    <h1>Order <?=e($o['order_ref'])?></h1>

    <div class="box" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px">
        <div>
            <h2>Customer</h2>
            <p>
                <strong><?=e($o['user_name'])?></strong><br>
                <?=e($o['user_email'])?><br>
                <?=e($o['user_phone'])?><br>
                <span class="muted"><?=e($o['user_city'])?></span>
            </p>
        </div>
        <div>
            <h2>Details</h2>
            <p>
                Type: <strong><?=ucfirst(e($o['order_type']))?></strong><br>
                Status: <strong><?=e($o['status'])?></strong><br>
                Amount: <strong>KShs <?=number_format((float)$o['total_amount'], 2)?></strong><br>
                Method: <?=e($o['payment_method'] ?: '—')?><br>
                Ref: <?=e($o['payment_ref'] ?: '—')?><br>
                Paid: <?= $o['paid_at'] ? e(date('d M Y H:i', strtotime($o['paid_at']))) : '—' ?><br>
                Created: <?=e(date('d M Y H:i', strtotime($o['created_at'])))?>
            </p>
        </div>
    </div>

    <div class="box">
        <h2>Items</h2>
        <table class="tbl">
            <thead><tr><th>Property</th><th>Type</th><th>Price</th><th>Months</th><th>Subtotal</th></tr></thead>
            <tbody>
            <?php foreach ($items as $it): ?>
                <tr>
                    <td><?=e($it['title'])?><br><span class="muted"><?=e($it['location'])?></span></td>
                    <td><?= $it['item_type'] === 'rental' ? 'Rental' : 'Purchase' ?></td>
                    <td>KShs <?=number_format((float)$it['price'], 2)?></td>
                    <td><?= $it['item_type'] === 'rental' ? (int)$it['months'] : '—' ?></td>
                    <td>KShs <?=number_format((float)$it['subtotal'], 2)?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr><th colspan="4" style="text-align:right">Total</th><th>KShs <?=number_format((float)$o['total_amount'], 2)?></th></tr>
            </tfoot>
        </table>
    </div>

    <?php if ($o['status'] === 'pending'): ?>
        <div class="box">
            <h2>Admin actions</h2>
            <form method="post" action="order_action.php" style="display:inline">
                <?=field()?>
                <input type="hidden" name="action" value="mark_paid">
                <input type="hidden" name="order_id" value="<?=(int)$o['order_id']?>">
                <button class="btn">Mark as paid</button>
            </form>
            <form method="post" action="order_action.php" style="display:inline" onsubmit="return confirm('Cancel this order?')">
                <?=field()?>
                <input type="hidden" name="action" value="cancel">
                <input type="hidden" name="order_id" value="<?=(int)$o['order_id']?>">
                <button class="btn bad">Cancel order</button>
            </form>
        </div>
    <?php endif; ?>
</section>
<?php include '../includes/footer.php'; ?>