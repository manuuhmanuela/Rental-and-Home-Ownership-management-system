<?php
require '../config.php';
need_admin();

/* ──────────────────────────────────────────────
   FILTERS
   ────────────────────────────────────────────── */
$from   = $_GET['from']   ?? date('Y-m-01');
$to     = $_GET['to']     ?? date('Y-m-d');
$status = $_GET['status'] ?? '';
$type   = $_GET['type']   ?? '';
$search = trim($_GET['q'] ?? '');

$vFrom = DateTime::createFromFormat('Y-m-d', $from);
$vTo   = DateTime::createFromFormat('Y-m-d', $to);
if (!$vFrom) $from = date('Y-m-01');
if (!$vTo)   $to   = date('Y-m-d');
if (strtotime($from) > strtotime($to)) { $tmp = $from; $from = $to; $to = $tmp; }

/* ──────────────────────────────────────────────
   QUERY
   ────────────────────────────────────────────── */
$sql = "SELECT o.*, u.name AS user_name, u.email AS user_email, u.phone AS user_phone,
               (SELECT COUNT(*) FROM order_items oi WHERE oi.order_id = o.order_id) AS item_count,
               (SELECT COALESCE(GROUP_CONCAT(p.title SEPARATOR ', '), '')
                  FROM order_items oi
                  JOIN properties p ON p.id = oi.property_id
                  WHERE oi.order_id = o.order_id) AS items_summary
        FROM orders o
        JOIN users u ON u.id = o.user_id
        WHERE DATE(o.created_at) BETWEEN ? AND ?";
$params = [$from, $to];

if (in_array($status, ['pending','paid','cancelled','failed'], true)) {
    $sql .= " AND o.status = ?";
    $params[] = $status;
}
if (in_array($type, ['purchase','rental','mixed'], true)) {
    $sql .= " AND o.order_type = ?";
    $params[] = $type;
}
if ($search !== '') {
    $sql .= " AND (o.order_ref LIKE ? OR u.name LIKE ? OR u.email LIKE ? OR u.phone LIKE ?)";
    $like = "%$search%";
    $params[] = $like; $params[] = $like; $params[] = $like; $params[] = $like;
}
$sql .= " ORDER BY o.created_at ASC, o.order_id ASC";

$stmt = db()->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

/* ──────────────────────────────────────────────
   SUMMARY
   ────────────────────────────────────────────── */
$totalAmount = 0.0;
$paidAmount  = 0.0;
$pendingCount = 0;
$paidCount = 0;
$cancelledCount = 0;
foreach ($rows as $r) {
    $totalAmount += (float)$r['total_amount'];
    if ($r['status'] === 'paid') {
        $paidAmount += (float)$r['total_amount'];
        $paidCount++;
    } elseif ($r['status'] === 'pending') {
        $pendingCount++;
    } elseif ($r['status'] === 'cancelled') {
        $cancelledCount++;
    }
}
$unpaidAmount = $totalAmount - $paidAmount;
$totalOrders  = count($rows);

top('Reports');
?>
<style>
    @media print {
        .no-print { display: none !important; }
        body { background: #fff; }
        .box { box-shadow: none; border: 1px solid #ccc; page-break-inside: avoid; }
        .tbl th, .tbl td { font-size: 11px; padding: 6px; }
        .wrap { max-width: 100%; padding: 0; }
    }
    .report-summary {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
        gap: 12px;
        margin-bottom: 16px;
    }
    .stat {
        background: #f8fafc;
        border: 1px solid #e5e7eb;
        border-radius: 10px;
        padding: 14px 16px;
    }
    .stat .l {
        font-size: .72rem;
        text-transform: uppercase;
        font-weight: 700;
        color: #6b7280;
        letter-spacing: .4px;
    }
    .stat .v {
        font-size: 1.3rem;
        font-weight: 800;
        margin-top: 4px;
    }
    .stat.ok .v { color: #16a34a; }
    .stat.warn .v { color: #d97706; }
    .stat.bad .v { color: #dc2626; }

    .report-toolbar {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
        align-items: center;
        margin-bottom: 16px;
    }

    .badge.ok   { background:#dcfce7; color:#166534; }
    .badge.warn { background:#fef3c7; color:#92400e; }
    .badge.bad  { background:#fee2e2; color:#991b1b; }
    .badge.muted{ background:#e5e7eb; color:#374151; }

    #printFrame {
        position: fixed; right: 0; bottom: 0;
        width: 0; height: 0; border: 0; visibility: hidden;
    }
</style>

<section class="wrap">
    <div class="page-header no-print" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:16px">
        <div>
            <h1 style="margin:0">Reports</h1>
            <p class="muted" style="margin:4px 0 0">
                <?=e(date('d M Y', strtotime($from)))?> → <?=e(date('d M Y', strtotime($to)))?>
                &middot; <?=$totalOrders?> order<?= $totalOrders === 1 ? '' : 's'?>
            </p>
        </div>
        <div class="report-toolbar">
            <button type="button" class="btn" onclick="printAll()">
                <i class="bi bi-printer"></i> Print All Reports
            </button>
            <a class="btn ghost" href="reports.php">↻ Reset</a>
        </div>
    </div>

    <!-- Filters -->
    <form method="get" class="box no-print">
        <div class="grid">
            <label>From
                <input type="date" name="from" value="<?=e($from)?>" required>
            </label>
            <label>To
                <input type="date" name="to" value="<?=e($to)?>" required>
            </label>
            <label>Status
                <select name="status">
                    <option value="">All</option>
                    <?php foreach (['pending','paid','cancelled','failed'] as $s): ?>
                        <option value="<?=$s?>" <?=$status===$s?'selected':''?>><?=ucfirst($s)?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Type
                <select name="type">
                    <option value="">All</option>
                    <?php foreach (['purchase','rental','mixed'] as $t): ?>
                        <option value="<?=$t?>" <?=$type===$t?'selected':''?>><?=ucfirst($t)?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Search
                <input type="text" name="q" value="<?=e($search)?>" placeholder="Ref, name, email, phone">
            </label>
            <div style="display:flex;gap:8px;align-items:end">
                <button class="btn">Generate</button>
                <a class="btn ghost" href="reports.php">Reset</a>
            </div>
        </div>
    </form>

    <!-- Summary -->
    <div class="report-summary">
        <div class="stat">
            <div class="l">Total orders</div>
            <div class="v"><?=$totalOrders?></div>
        </div>
        <div class="stat">
            <div class="l">Total amount</div>
            <div class="v">KShs <?=number_format($totalAmount, 2)?></div>
        </div>
        <div class="stat ok">
            <div class="l">Paid (<?=$paidCount?>)</div>
            <div class="v">KShs <?=number_format($paidAmount, 2)?></div>
        </div>
        <div class="stat warn">
            <div class="l">Pending (<?=$pendingCount?>)</div>
            <div class="v">KShs <?=number_format($unpaidAmount, 2)?></div>
        </div>
        <div class="stat bad">
            <div class="l">Cancelled (<?=$cancelledCount?>)</div>
            <div class="v"><?=$cancelledCount?></div>
        </div>
    </div>

    <!-- Table -->
    <div class="box" id="reportCard">
        <h2>Orders in range</h2>

        <?php if (!$rows): ?>
            <p class="muted">No orders match your filters.</p>
        <?php else: ?>
            <div style="overflow-x:auto">
                <table class="tbl" id="mainReportTable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Ref</th>
                            <th>Date</th>
                            <th>Customer</th>
                            <th>Items</th>
                            <th>Type</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th class="no-print">Print</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($rows as $i => $r): ?>
                        <tr>
                            <td><?=$i + 1?></td>
                            <td><strong><?=e($r['order_ref'])?></strong></td>
                            <td><?=date('d M Y', strtotime($r['created_at']))?></td>
                            <td>
                                <?=e($r['user_name'])?><br>
                                <span class="muted" style="font-size:.78rem"><?=e($r['user_email'])?></span>
                            </td>
                            <td>
                                <?=e($r['items_summary'] ?: '—')?><br>
                                <span class="muted" style="font-size:.78rem"><?= (int)$r['item_count']?> item(s)</span>
                            </td>
                            <td><?=ucfirst(e($r['order_type']))?></td>
                            <td>KShs <?=number_format((float)$r['total_amount'], 2)?></td>
                            <td>
                                <span class="badge <?= $r['status']==='paid'?'ok':($r['status']==='pending'?'warn':'bad') ?>">
                                    <?=e($r['status'])?>
                                </span>
                            </td>
                            <td class="no-print">
                                <button type="button" class="btn sm" onclick="printSingle(<?=(int)$r['order_id']?>)">
                                    🖨️ Print
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th colspan="6" style="text-align:right">TOTAL (<?=$totalOrders?>)</th>
                            <th>KShs <?=number_format($totalAmount, 2)?></th>
                            <th colspan="2"></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        <?php endif; ?>
    </div>

    <p class="muted no-print" style="font-size:.8rem;margin-top:8px">
        Tip: the <strong>Print</strong> button opens a clean single-order page in a hidden frame, then prints it — the rest of the report stays untouched.
    </p>
</section>

<iframe id="printFrame" title="Print frame"></iframe>

<script>
    function printAll() {
        // Hide the search/filter/action cells before printing
        document.body.classList.add('printing-all');
        const frame = document.getElementById('printFrame');
        frame.style.visibility = 'hidden';

        // Print the current page; @media print CSS strips .no-print
        window.print();
    }

    function printSingle(orderId) {
        const frame = document.getElementById('printFrame');
        frame.onload = function () {
            frame.contentWindow.focus();
            frame.contentWindow.print();
        };
        frame.src = 'reports_print.php?id=' + encodeURIComponent(orderId)
                   + '&from=<?=rawurlencode($from)?>'
                   + '&to=<?=rawurlencode($to)?>';
    }
</script>

<?php include '../includes/footer.php'; ?>