<?php require '../config.php'; need('admin');
if($_SERVER['REQUEST_METHOD'] === 'POST'){ check(); $id = (int)$_POST['id']; $do = $_POST['do'];
  if($do === 'approve') q("UPDATE properties SET status='approved',reject_reason=NULL WHERE id=?", [$id]);
  elseif($do === 'reject') q("UPDATE properties SET status='rejected',reject_reason=? WHERE id=?", [trim($_POST['reason'] ?? ''), $id]);
  elseif($do === 'sold') q("UPDATE properties SET status='sold' WHERE id=?", [$id]);
  elseif($do === 'feature') q("UPDATE properties SET featured=1-featured WHERE id=?", [$id]);
  elseif($do === 'delete') q("DELETE FROM properties WHERE id=?", [$id]);
  logit("Admin $do on listing #$id"); flash('Listing updated: '.$do.'.'); header('Location: '.$_SERVER['REQUEST_URI']); exit; }
$st = $_GET['status'] ?? ''; $s = trim($_GET['q'] ?? ''); $w = ['1=1']; $p = [];
if(in_array($st, ['pending','approved','rejected','sold'])){ $w[] = 'p.status=?'; $p[] = $st; }
if($s !== ''){ $w[] = '(p.title LIKE ? OR p.location LIKE ? OR u.name LIKE ?)'; array_push($p, "%$s%", "%$s%", "%$s%"); }
$rows = q("SELECT p.*, u.name owner, (SELECT COUNT(*) FROM inquiries WHERE property_id=p.id) inq, (SELECT COUNT(*) FROM offers WHERE property_id=p.id) off FROM properties p JOIN users u ON u.id=p.owner_id WHERE ".implode(' AND ', $w)." ORDER BY p.status='pending' DESC, p.id DESC", $p)->fetchAll();
top('Track listings'); ?>
<section class="wrap"><h1>Track listings</h1>
<form class="filters box" method="get"><input name="q" placeholder="Title, location or owner" value="<?=e($s)?>"><select name="status"><option value="">All statuses</option><?=opts(['pending','approved','rejected','sold'], $st)?></select><button class="btn">Filter</button></form>
<p class="muted"><?=count($rows)?> listing(s)</p><div class="scroll"><table><tr><th>Building</th><th>Owner</th><th>Status</th><th>Views</th><th>Inq.</th><th>Offers</th><th>Actions</th></tr>
<?php foreach($rows as $r): ?><tr><td><a href="<?=BASE?>/property.php?id=<?=$r['id']?>"><?=e($r['title'])?></a><?=$r['featured'] ? ' <span class="tag hot">Featured</span>' : ''?><br><span class="muted"><?=e($r['location'])?> &middot; <?=kes($r['price'])?> &middot; <?=$r['purpose']?></span></td>
<td><?=e($r['owner'])?></td><td><?=pill($r['status'])?><?=$r['reject_reason'] ? '<br><span class="muted">'.e($r['reject_reason']).'</span>' : ''?></td><td><?=(int)$r['views']?></td><td><?=$r['inq']?></td><td><?=$r['off']?></td>
<td class="act"><form method="post"><?=field()?><input type="hidden" name="id" value="<?=$r['id']?>">
<?php if($r['status'] !== 'approved'): ?><button name="do" value="approve" class="btn sm">Approve</button><?php endif; ?>
<?php if($r['status'] === 'pending'): ?><input name="reason" placeholder="Reject reason" class="sm"><button name="do" value="reject" class="btn sm danger">Reject</button><?php endif; ?>
<?php if($r['status'] === 'approved'): ?><button name="do" value="feature" class="btn sm alt"><?=$r['featured'] ? 'Unfeature' : 'Feature'?></button><button name="do" value="sold" class="btn sm alt">Mark sold</button><?php endif; ?>
<button name="do" value="delete" class="btn sm danger" onclick="return confirm('Delete this listing?')">Delete</button></form></td></tr><?php endforeach; ?></table></div></section>
<?php include '../includes/footer.php';
