<?php require '../config.php'; need('admin');
if($_SERVER['REQUEST_METHOD'] === 'POST' && in_array($_POST['do'] ?? '', ['accepted','rejected','pending'])){ check(); q("UPDATE offers SET status=? WHERE id=?", [$_POST['do'], (int)$_POST['id']]); logit('Admin set offer #'.(int)$_POST['id'].' to '.$_POST['do']); flash('Offer updated.'); go('/admin/offers.php'); }
$rows = q("SELECT o.*, p.title, p.price, b.name buyer, s.name seller FROM offers o JOIN properties p ON p.id=o.property_id JOIN users b ON b.id=o.user_id JOIN users s ON s.id=p.owner_id ORDER BY o.id DESC")->fetchAll();
top('Offers'); ?>
<section class="wrap"><h1>Offers and purchase requests</h1><?php if(!$rows) echo '<p class="empty">No offers yet.</p>'; else { ?><div class="scroll"><table><tr><th>Property</th><th>Buyer</th><th>Seller</th><th>Asking</th><th>Offer</th><th>Status</th><th>Set status</th></tr>
<?php foreach($rows as $o): ?><tr><td><?=e($o['title'])?></td><td><?=e($o['buyer'])?></td><td><?=e($o['seller'])?></td><td><?=kes($o['price'])?></td><td><?=kes($o['amount'])?></td><td><?=pill($o['status'])?></td>
<td class="act"><form method="post"><?=field()?><input type="hidden" name="id" value="<?=$o['id']?>"><button name="do" value="accepted" class="btn sm">Accept</button><button name="do" value="rejected" class="btn sm danger">Reject</button><button name="do" value="pending" class="btn sm alt">Reset</button></form></td></tr><?php endforeach; ?></table></div><?php } ?></section>
<?php include '../includes/footer.php';
