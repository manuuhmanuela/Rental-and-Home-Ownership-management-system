<?php
require '../config.php';
need_admin();

$status = $_GET['status'] ?? '';
$type   = $_GET['type']   ?? '';
$search = trim($_GET['q'] ?? '');

$sql = "SELECT o.*, u.name AS user_name, u.email AS user_email FROM orders o JOIN users u ON u.id=o.user_id WHERE 1=1";
$params = [];
if (in_array($status, ['pending','paid','cancelled','failed'], true)) {
    $sql .= " AND o.status = ?"; $params[] = $status;
}
if (in_array($type, ['purchase','rental','mixed'], true)) {
    $sql .= " AND o.order_type = ?"; $params[] = $type;
}
if ($search !== '') {
    $sql .= " AND (o.order_ref LIKE ? OR u.name LIKE ? OR u.email LIKE ?)";
    $like = "%$search%";
    $params[] = $like; $params[] = $like; $params[] = $like;
}
$sql .= " ORDER BY o.created_at DESC";
$stmt = db()->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();

top('Orders & Payments');
?>
<section class="wrap">
    <h1>Orders</h1>

    <form method="get" class="box grid">
        <label>Search<input type="text" name="q" value="<?=e($search)?>" placeholder="Ref / name / email"></label>
        <label>Status
            <select name="status">
                <option value="">All</option>
                <?php foreach (['pending','paid','cancelled','failed'] as $s): ?>
                    <option value="<?=$s?>" <?=$status===$s?'selected':''?>><?=ucfirst($s)?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>Type
            <select name="type">
                <option value="">All</option>
                <?php foreach (['purchase','rental','mixed'] as $t): ?>
                    <option value="<?=$t?>" <?=$type===$t?'selected':''?>><?=ucfirst($t)?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <div><button class="btn">Filter</button> <a class="btn ghost" href="orders.php">Reset</a></div>
    </form>

    <div class="box">
        <?php if (!$orders): ?><p class="muted">No orders found.</p>
        <?php else: ?>
            <div style="overflow-x:auto">
                <table class="tbl">
                    <thead><tr><th>Ref</th><th>Customer</th><th>Type</th><th>Amount</th><th>Status</th><th>Created</th><th></th></tr></thead>
                    <tbody>
                    <?php foreach ($orders as $o): ?>
                        <tr>
                            <td><strong><?=e($o['order_ref'])?></strong></td>
                            <td><?=e($o['user_name'])?><br><span class="muted"><?=e($o['user_email'])?></span></td>
                            <td><?=ucfirst(e($o['order_type']))?></td>
                            <td>KShs <?=number_format((float)$o['total_amount'], 2)?></td>
                            <td>
                                <span class="badge <?= $o['status']==='paid'?'ok':($o['status']==='pending'?'warn':'bad') ?>">
                                    <?=e($o['status'])?>
                                </span>
                            </td>
                            <td><?=date('d M Y H:i', strtotime($o['created_at']))?></td>
                            <td><a class="btn sm" href="order_view.php?id=<?=(int)$o['order_id']?>">View</a></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php include '../includes/footer.php'; ?>