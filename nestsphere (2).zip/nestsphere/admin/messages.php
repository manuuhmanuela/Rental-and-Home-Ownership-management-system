<?php require '../config.php'; need('admin');
if($_SERVER['REQUEST_METHOD'] === 'POST'){ check(); $id = (int)$_POST['id'];
  if($_POST['do'] === 'read') q("UPDATE messages SET is_read=1 WHERE id=?", [$id]); else q("DELETE FROM messages WHERE id=?", [$id]);
  go('/admin/messages.php'); }
$rows = q("SELECT * FROM messages ORDER BY is_read, id DESC")->fetchAll();
top('Messages'); ?>
<section class="wrap"><h1>Contact messages</h1><?php if(!$rows) echo '<p class="empty">No messages yet.</p>'; foreach($rows as $m): ?>
<div class="box"><b><?=e($m['subject'])?></b> <?=$m['is_read'] ? '' : pill('pending')?><span class="muted"><?=e($m['name'])?> &middot; <?=e($m['email'])?> &middot; <?=e($m['created_at'])?></span><p><?=nl2br(e($m['message']))?></p>
<form method="post" class="act"><?=field()?><input type="hidden" name="id" value="<?=$m['id']?>"><a class="btn sm" href="mailto:<?=e($m['email'])?>?subject=Re: <?=e($m['subject'])?>">Reply by email</a>
<?php if(!$m['is_read']): ?><button name="do" value="read" class="btn sm alt">Mark read</button><?php endif; ?><button name="do" value="delete" class="btn sm danger" onclick="return confirm('Delete?')">Delete</button></form></div><?php endforeach; ?></section>
<?php include '../includes/footer.php';
