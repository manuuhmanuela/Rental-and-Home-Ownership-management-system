<?php
require '../config.php';
need_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check();
    $id     = (int)($_POST['rental_id'] ?? 0);
    $status = $_POST['status'] ?? '';
    if ($id && in_array($status, ['active','expired','cancelled'], true)) {
        db()->prepare("UPDATE rentals SET status=? WHERE rental_id=?")->execute([$status, $id]);
        logit("Admin set rental #$id to $status");
    }
    go('/admin/rentals.php');
}

$statusFilter = $_GET['status'] ?? '';
$sql = "SELECT r.*, p.title, p.location, u.name AS user_name, u.email AS user_email, o.order_ref
        FROM rentals r JOIN properties p ON p.id=r.property_id JOIN users u ON u.id=r.user_id JOIN orders o ON o.order_id=r.order_id
        WHERE 1=1";
$params = [];
if (in_array($statusFilter, ['active','expired','cancelled'], true)) {
    $sql .= " AND r.status = ?";
    $params[] = $statusFilter;
}
$sql .= " ORDER BY r.created_at DESC";
$stmt = db()->prepare($sql);
$stmt->execute($params);
$rentals = $stmt->fetchAll();

top('Rentals');
?>
<section class="wrap">
    <h1>Rental agreements</h1>

    <form method="get" class="box" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap">
        <label>Status
            <select name="status">
                <option value="">All</option>
                <?php foreach (['active','expired','cancelled'] as $s): ?>
                    <option value="<?=$s?>" <?=$statusFilter===$s?'selected':''?>><?=ucfirst($s)?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <button class="btn">Filter</button>
        <a class="btn ghost" href="rentals.php">Reset</a>
    </form>

    <div class="box">
        <?php if (!$rentals): ?><p class="muted">No rentals found.</p>
        <?php else: ?>
            <div style="overflow-x:auto">
                <table class="tbl">
                    <thead><tr><th>Property</th><th>Tenant</th><th>Order</th><th>Monthly rent</th><th>Months</th><th>Start</th><th>Status</th><th>Action</th></tr></thead>
                    <tbody>
                    <?php foreach ($rentals as $r): ?>
                        <tr>
                            <td><?=e($r['title'])?><br><span class="muted"><?=e($r['location'])?></span></td>
                            <td><?=e($r['user_name'])?><br><span class="muted"><?=e($r['user_email'])?></span></td>
                            <td><a href="order_view.php?id=<?=(int)$r['order_id']?>"><?=e($r['order_ref'])?></a></td>
                            <td>KShs <?=number_format((float)$r['monthly_rent'], 2)?></td>
                            <td><?=(int)$r['months']?></td>
                            <td><?=e($r['start_date'])?></td>
                            <td><span class="badge <?= $r['status']==='active'?'ok':($r['status']==='expired'?'muted':'bad') ?>"><?=e($r['status'])?></span></td>
                            <td>
                                <form method="post" style="display:inline">
                                    <?=field()?>
                                    <input type="hidden" name="rental_id" value="<?=(int)$r['rental_id']?>">
                                    <select name="status" style="padding:4px 6px;border-radius:6px;border:1px solid #ddd">
                                        <?php foreach (['active','expired','cancelled'] as $s): ?>
                                            <option value="<?=$s?>" <?=$r['status']===$s?'selected':''?>><?=ucfirst($s)?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button class="btn sm">Save</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php include '../includes/footer.php'; ?>