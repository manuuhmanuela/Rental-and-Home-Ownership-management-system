<?php
require '../config.php';
need_admin();

/* ---------- Upload settings ---------- */
$UPLOAD_DIR_FS  = __DIR__ . '/../uploads/properties/';
$UPLOAD_DIR_WEB = BASE . '/uploads/properties/';
$MAX_BYTES      = 5 * 1024 * 1024; // 5 MB
$ALLOWED_EXT    = ['jpg','jpeg','jfif','png','webp','gif'];
$ALLOWED_MIME   = ['image/jpeg','image/pjpeg','image/jfif','image/png','image/webp','image/gif'];

if (!is_dir($UPLOAD_DIR_FS)) {
    @mkdir($UPLOAD_DIR_FS, 0775, true);
}

$err = '';
$ok  = '';

/* ============================================================
   Handle POST actions
   ============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check();
    $action = $_POST['action'] ?? '';

    /* ---------- ADD ---------- */
    if ($action === 'add') {
        $title       = trim($_POST['title'] ?? '');
        $type        = $_POST['type'] ?? '';
        $purpose     = $_POST['purpose'] ?? '';
        $location    = trim($_POST['location'] ?? '');
        $price       = (float)($_POST['price'] ?? 0);
        $bedrooms    = (int)($_POST['bedrooms'] ?? 0);
        $bathrooms   = (int)($_POST['bathrooms'] ?? 0);
        $size        = trim($_POST['size'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $image_url   = trim($_POST['image_url'] ?? '');
        $owner_id    = (int)($_POST['owner_id'] ?? 0);
        $status      = $_POST['status'] ?? 'approved';
        $featured    = isset($_POST['featured']) ? 1 : 0;

        if ($title === '' || $location === '' || $price <= 0) {
            $err = 'Title, location, and price are required.';
        } elseif (!in_array($type, ['Apartment','Bungalow','Townhouse','Land','Commercial'], true)) {
            $err = 'Invalid property type.';
        } elseif (!in_array($purpose, ['sale','rent'], true)) {
            $err = 'Choose Sale or Rent.';
        } elseif (!in_array($status, ['pending','approved','rejected','sold'], true)) {
            $err = 'Invalid status.';
        } elseif ($owner_id <= 0) {
            // Default to the logged-in admin
            $owner_id = (int)user()['id'];
        } else {
            // Validate owner exists
            $chk = q("SELECT id FROM users WHERE id=?", [$owner_id])->fetch();
            if (!$chk) { $owner_id = (int)user()['id']; }
        }

        /* Handle image upload */
        $savedImagePath = null;
        if (!$err && !empty($_FILES['image']['name'] ?? '')) {
            $f = $_FILES['image'];
            if ($f['error'] !== UPLOAD_ERR_OK) {
                $err = 'Image upload failed (code ' . (int)$f['error'] . ').';
            } elseif ($f['size'] > $MAX_BYTES) {
                $err = 'Image is larger than ' . ($MAX_BYTES / 1024 / 1024) . ' MB.';
            } else {
                $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
                if (!in_array($ext, $ALLOWED_EXT, true)) {
                    $err = 'Only JPG, JPEG, JFIF, PNG, WEBP or GIF allowed.';
                } else {
                    $finfo = function_exists('finfo_open') ? finfo_open(FILEINFO_MIME_TYPE) : null;
                    $mime  = $finfo ? finfo_file($finfo, $f['tmp_name']) : ($f['type'] ?? '');
                    if ($finfo) finfo_close($finfo);
                    if (!in_array(strtolower($mime), $ALLOWED_MIME, true)) {
                        $err = 'The uploaded file is not a valid image.';
                    } elseif (!is_uploaded_file($f['tmp_name'])) {
                        $err = 'Upload verification failed.';
                    } else {
                        $safeBase = preg_replace('/[^a-z0-9\-_]+/i', '-', pathinfo($f['name'], PATHINFO_FILENAME));
                        $safeBase = trim($safeBase, '-_') ?: 'image';
                        if ($ext === 'jfif') $ext = 'jpg';
                        $newName  = $safeBase . '-' . date('YmdHis') . '-' . bin2hex(random_bytes(3)) . '.' . $ext;
                        if (move_uploaded_file($f['tmp_name'], $UPLOAD_DIR_FS . $newName)) {
                            $savedImagePath = $UPLOAD_DIR_WEB . $newName;
                        } else {
                            $err = 'Could not save the uploaded image.';
                        }
                    }
                }
            }
        }

        if (!$err && !$savedImagePath && $image_url !== '') {
            if (!filter_var($image_url, FILTER_VALIDATE_URL)) {
                $err = 'Image URL is not valid.';
            } else {
                $savedImagePath = $image_url;
            }
        }

        if (!$err) {
            q("INSERT INTO properties
                (owner_id, title, type, purpose, location, price, bedrooms, bathrooms, size, description, image_url, status, featured)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                [
                    $owner_id, $title, $type, $purpose, $location, $price,
                    $bedrooms, $bathrooms, $size, $description, $savedImagePath,
                    $status, $featured
                ]
            );
            logit("Admin added property: $title");
            $ok = "Property \"$title\" created.";
        }
    }

    /* ---------- STATUS CHANGE ---------- */
    elseif ($action === 'status') {
        $id     = (int)($_POST['id'] ?? 0);
        $status = $_POST['status'] ?? '';
        $reason = trim($_POST['reject_reason'] ?? '');
        if ($id && in_array($status, ['pending','approved','rejected','sold'], true)) {
            if ($status === 'rejected') {
                q("UPDATE properties SET status=?, reject_reason=? WHERE id=?", [$status, $reason ?: null, $id]);
            } else {
                q("UPDATE properties SET status=?, reject_reason=NULL WHERE id=?", [$status, $id]);
            }
            logit("Admin set property #$id to $status");
            $ok = 'Status updated.';
        }
    }

    /* ---------- FEATURE TOGGLE ---------- */
    elseif ($action === 'feature') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            q("UPDATE properties SET featured = 1 - featured WHERE id=?", [$id]);
            logit("Admin toggled featured on property #$id");
            $ok = 'Featured status toggled.';
        }
    }

    /* ---------- DELETE ---------- */
    elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            q("DELETE FROM properties WHERE id=?", [$id]);
            logit("Admin deleted property #$id");
            $ok = 'Property deleted.';
        }
    }
}

/* ============================================================
   Filters + list
   ============================================================ */
$filterStatus = $_GET['status'] ?? '';
$search       = trim($_GET['q'] ?? '');

$sql = "SELECT p.*, u.name AS owner_name, u.email AS owner_email
        FROM properties p
        JOIN users u ON u.id = p.owner_id
        WHERE 1=1";
$params = [];
if (in_array($filterStatus, ['pending','approved','rejected','sold'], true)) {
    $sql .= " AND p.status = ?";
    $params[] = $filterStatus;
}
if ($search !== '') {
    $sql .= " AND (p.title LIKE ? OR p.location LIKE ? OR u.name LIKE ?)";
    $params[] = "%$search%"; $params[] = "%$search%"; $params[] = "%$search%";
}
$sql .= " ORDER BY p.created_at DESC";

$stmt = db()->prepare($sql);
$stmt->execute($params);
$properties = $stmt->fetchAll();

/* Counts */
$counts = ['pending'=>0,'approved'=>0,'rejected'=>0,'sold'=>0,'all'=>0];
foreach (db()->query("SELECT status, COUNT(*) AS n FROM properties GROUP BY status")->fetchAll() as $row) {
    $counts[$row['status']] = (int)$row['n'];
    $counts['all'] += (int)$row['n'];
}

/* Owner dropdown */
$owners = db()->query("SELECT id, name, email FROM users ORDER BY name")->fetchAll();

/* Image resolver */
function admin_prop_img($p) {
    $v = trim((string)($p['image_url'] ?? ''));
    if ($v === '') return 'https://picsum.photos/seed/' . (int)$p['id'] . '/120/90';
    if (preg_match('#^https?://#i', $v)) return $v;
    if (strpos($v, '/') === 0) return $v;
    return rtrim(BASE, '/') . '/uploads/properties/' . rawurlencode(basename($v));
}

top('Manage properties');
?>
<style>
    .admin-tabs { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 16px; }
    .admin-tab {
        display: inline-flex; align-items: center; gap: 6px;
        padding: 8px 14px; border-radius: 999px;
        background: #fff; border: 1px solid #e5e7eb;
        color: #374151; font-weight: 700; font-size: .82rem;
        text-decoration: none;
    }
    .admin-tab.active { background: #2563eb; border-color: #2563eb; color: #fff; }
    .admin-tab .n {
        display: inline-block; padding: 0 7px; border-radius: 999px;
        background: rgba(0,0,0,.08); font-size: .7rem;
    }
    .admin-tab.active .n { background: rgba(255,255,255,.3); }

    .add-box {
        background: #f8fafc;
        border: 1px solid #e5e7eb;
        border-radius: 12px;
        padding: 16px;
        margin-bottom: 18px;
    }
    .add-box h2 { margin: 0 0 12px; font-size: 1rem; }

    .form-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 10px;
    }
    .inline-actions {
        display: flex; gap: 6px; flex-wrap: wrap;
    }
    .inline-actions form { display: inline-block; }

    .thumb {
        width: 60px; height: 44px; object-fit: cover;
        border-radius: 6px; border: 1px solid #e5e7eb;
    }
    .status-form {
        display: flex; gap: 4px; align-items: center; flex-wrap: wrap;
        margin: 0;
    }
    .status-form select, .status-form input {
        padding: 4px 6px; border-radius: 6px; border: 1px solid #d1d5db; font-size: .8rem;
    }
    .badge {
        display: inline-block; padding: 2px 8px; border-radius: 999px;
        font-size: .7rem; font-weight: 700; text-transform: uppercase; letter-spacing: .3px;
    }
    .badge.ok   { background:#dcfce7; color:#166534; }
    .badge.warn { background:#fef3c7; color:#92400e; }
    .badge.bad  { background:#fee2e2; color:#991b1b; }
    .badge.muted{ background:#e5e7eb; color:#374151; }
</style>

<section class="wrap wide">
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:16px">
        <div>
            <h1 style="margin:0">Manage properties</h1>
            <p class="muted" style="margin:4px 0 0"><?=$counts['all']?> total</p>
        </div>
        <a class="btn ghost" href="<?=BASE?>/admin/dashboard.php">&larr; Dashboard</a>
    </div>

    <?php if ($err): ?><div class="box bad"><?=e($err)?></div><?php endif; ?>
    <?php if ($ok): ?><div class="box good"><?=e($ok)?></div><?php endif; ?>

    <!-- ADD PROPERTY (admin inline, no redirect to user listing) -->
    <div class="add-box">
        <h2>➕ Add a new property</h2>
        <form method="post" enctype="multipart/form-data">
            <?=field()?>
            <input type="hidden" name="action" value="add">

            <div class="form-grid">
                <label>Title
                    <input type="text" name="title" required maxlength="150">
                </label>
                <label>Type
                    <select name="type" required>
                        <option value="">Select</option>
                        <?php foreach (['Apartment','Bungalow','Townhouse','Land','Commercial'] as $t): ?>
                            <option value="<?=$t?>"><?=$t?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>Purpose
                    <select name="purpose" required>
                        <option value="sale">For Sale</option>
                        <option value="rent">For Rent</option>
                    </select>
                </label>
                <label>Location
                    <input type="text" name="location" required maxlength="120">
                </label>
                <label>Price (KShs)
                    <input type="number" name="price" step="0.01" min="1" required>
                </label>
                <label>Bedrooms
                    <input type="number" name="bedrooms" min="0" value="0">
                </label>
                <label>Bathrooms
                    <input type="number" name="bathrooms" min="0" value="0">
                </label>
                <label>Size
                    <input type="text" name="size" maxlength="40" placeholder="140 sqm / 0.25 acre">
                </label>
                <label>Owner
                    <select name="owner_id">
                        <?php foreach ($owners as $o): ?>
                            <option value="<?=(int)$o['id']?>" <?= (int)$o['id']===(int)user()['id'] ? 'selected' : '' ?>>
                                <?=e($o['name'])?> (<?=e($o['email'])?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>Status
                    <select name="status">
                        <option value="approved" selected>Approved (goes live)</option>
                        <option value="pending">Pending</option>
                        <option value="rejected">Rejected</option>
                        <option value="sold">Sold</option>
                    </select>
                </label>
            </div>

            <label>Description
                <textarea name="description" rows="3"></textarea>
            </label>

            <div class="form-grid">
                <label>Image file
                    <input type="file" name="image" accept=".jpg,.jpeg,.jfif,.png,.webp,.gif,image/*">
                </label>
                <label>Or Image URL
                    <input type="url" name="image_url" placeholder="https://…">
                </label>
                <label style="display:flex;align-items:center;gap:8px;margin-top:22px">
                    <input type="checkbox" name="featured" style="width:auto">
                    <span>Featured</span>
                </label>
            </div>

            <div style="margin-top:12px">
                <button class="btn">Add property</button>
                <a class="btn ghost" href="<?=BASE?>/admin/properties.php">Reset</a>
            </div>
        </form>
    </div>

    <!-- Tabs -->
    <div class="admin-tabs">
        <a class="admin-tab <?= $filterStatus === '' ? 'active' : '' ?>" href="<?=BASE?>/admin/properties.php">
            All <span class="n"><?=$counts['all']?></span>
        </a>
        <a class="admin-tab <?= $filterStatus === 'approved' ? 'active' : '' ?>" href="<?=BASE?>/admin/properties.php?status=approved">
            Approved <span class="n"><?=$counts['approved']?></span>
        </a>
        <a class="admin-tab <?= $filterStatus === 'pending' ? 'active' : '' ?>" href="<?=BASE?>/admin/properties.php?status=pending">
            Pending <span class="n"><?=$counts['pending']?></span>
        </a>
        <a class="admin-tab <?= $filterStatus === 'rejected' ? 'active' : '' ?>" href="<?=BASE?>/admin/properties.php?status=rejected">
            Rejected <span class="n"><?=$counts['rejected']?></span>
        </a>
        <a class="admin-tab <?= $filterStatus === 'sold' ? 'active' : '' ?>" href="<?=BASE?>/admin/properties.php?status=sold">
            Sold <span class="n"><?=$counts['sold']?></span>
        </a>
    </div>

    <!-- Search -->
    <form method="get" class="box" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap">
        <input type="hidden" name="status" value="<?=e($filterStatus)?>">
        <label style="flex:1;min-width:200px;margin:0">Search
            <input type="text" name="q" value="<?=e($search)?>" placeholder="Title, location, owner">
        </label>
        <button class="btn">Search</button>
        <a class="btn ghost" href="<?=BASE?>/admin/properties.php">Reset</a>
    </form>

    <!-- LIST -->
    <div class="box" style="overflow-x:auto">
        <?php if (!$properties): ?>
            <p class="muted">No properties found.</p>
        <?php else: ?>
            <table class="tbl">
                <thead>
                    <tr>
                        <th></th>
                        <th>Property</th>
                        <th>Owner</th>
                        <th>Purpose</th>
                        <th>Price</th>
                        <th>Status</th>
                        <th>Featured</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($properties as $p): ?>
                    <tr>
                        <td><img class="thumb" src="<?=e(admin_prop_img($p))?>" alt=""></td>
                        <td>
                            <strong><?=e($p['title'])?></strong><br>
                            <span class="muted" style="font-size:.78rem"><?=e($p['location'])?> · <?=e($p['type'])?></span>
                            <br>
                            <small class="muted">#<?=(int)$p['id']?> · <?=(int)$p['views']?> views</small>
                        </td>
                        <td>
                            <?=e($p['owner_name'])?><br>
                            <span class="muted" style="font-size:.75rem"><?=e($p['owner_email'])?></span>
                        </td>
                        <td>
                            <span class="badge <?= $p['purpose']==='rent'?'warn':'ok' ?>">
                                <?= $p['purpose'] === 'rent' ? 'Rent' : 'Sale' ?>
                            </span>
                        </td>
                        <td>KShs <?=number_format((float)$p['price'], 0)?></td>
                        <td>
                            <span class="badge <?= $p['status']==='approved'?'ok':($p['status']==='pending'?'warn':'bad') ?>">
                                <?=e($p['status'])?>
                            </span>
                            <?php if ($p['status'] === 'rejected' && $p['reject_reason']): ?>
                                <br><small class="bad"><?=e($p['reject_reason'])?></small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <form method="post" style="display:inline">
                                <?=field()?>
                                <input type="hidden" name="action" value="feature">
                                <input type="hidden" name="id" value="<?=(int)$p['id']?>">
                                <button class="btn sm <?= $p['featured'] ? 'ok' : 'ghost' ?>">
                                    <?= $p['featured'] ? '★ On' : '☆ Off' ?>
                                </button>
                            </form>
                        </td>
                        <td>
                            <div class="inline-actions">
                                <!-- Status change -->
                                <form method="post" class="status-form">
                                    <?=field()?>
                                    <input type="hidden" name="action" value="status">
                                    <input type="hidden" name="id" value="<?=(int)$p['id']?>">
                                    <select name="status">
                                        <?php foreach (['pending','approved','rejected','sold'] as $s): ?>
                                            <option value="<?=$s?>" <?=$p['status']===$s?'selected':''?>><?=ucfirst($s)?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <input type="text" name="reject_reason" placeholder="reason (if rejected)"
                                           value="<?=e($p['reject_reason'] ?? '')?>" style="width:130px">
                                    <button class="btn sm">Save</button>
                                </form>

                                <!-- View -->
                                <?php if ($p['status'] === 'approved'): ?>
                                    <a class="btn sm ghost" href="<?=BASE?>/property.php?id=<?=(int)$p['id']?>" target="_blank">View</a>
                                <?php endif; ?>

                                <!-- Delete -->
                                <form method="post" onsubmit="return confirm('Delete this property permanently?')">
                                    <?=field()?>
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?=(int)$p['id']?>">
                                    <button class="btn sm bad">Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</section>
<?php include '../includes/footer.php'; ?>