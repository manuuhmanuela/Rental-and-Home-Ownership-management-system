<?php
require '../config.php';
need_admin();

// Admin landing page → send to dashboard
go('/admin/dashboard.php');