<?php require '../config.php'; need('admin');
$rows = q("SELECT a.*, u.name FROM activity a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 150")->fetchAll(); top('Activity log'); ?>
<section class="wrap"><h1>Activity log</h1><p class="muted">The latest 150 actions on the platform.</p><div class="scroll"><table><tr><th>When</th><th>Who</th><th>Action</th></tr>
<?php foreach($rows as $a) echo '<tr><td>'.e($a['created_at']).'</td><td>'.e($a['name'] ?? 'Guest').'</td><td>'.e($a['action']).'</td></tr>'; ?></table></div></section>
<?php include '../includes/footer.php';
