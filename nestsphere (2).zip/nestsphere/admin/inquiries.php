<?php require '../config.php'; need('admin');
if($_SERVER['REQUEST_METHOD'] === 'POST'){ check(); q("DELETE FROM inquiries WHERE id=?", [(int)$_POST['id']]); logit('Admin deleted an inquiry'); flash('Inquiry deleted.'); go('/admin/inquiries.php'); }
$rows = q("SELECT i.*, p.title, u.name FROM inquiries i JOIN properties p ON p.id=i.property_id JOIN users u ON u.id=i.user_id ORDER BY i.id DESC")->fetchAll();
top('Inquiries'); ?>
<section class="wrap"><h1>All inquiries</h1><?php if(!$rows) echo '<p class="empty">No inquiries yet.</p>'; else { ?><div class="scroll"><table><tr><th>From</th><th>Property</th><th>Message</th><th>Reply</th><th>Sent</th><th></th></tr>
<?php foreach($rows as $i): ?><tr><td><?=e($i['name'])?></td><td><?=e($i['title'])?></td><td><?=e($i['message'])?></td><td><?=$i['reply'] ? e($i['reply']) : '<span class="muted">No reply yet</span>'?></td><td><?=e($i['created_at'])?></td>
<td><form method="post"><?=field()?><input type="hidden" name="id" value="<?=$i['id']?>"><button class="btn sm danger" onclick="return confirm('Delete?')">Delete</button></form></td></tr><?php endforeach; ?></table></div><?php } ?></section>
<?php include '../includes/footer.php';
