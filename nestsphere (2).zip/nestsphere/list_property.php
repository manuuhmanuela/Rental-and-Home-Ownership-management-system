<?php
require 'config.php';
require 'includes/cart_helpers.php';
need_login();

$u = user();
$err = '';

/* ---------- Upload settings ---------- */
$UPLOAD_DIR_FS  = __DIR__ . '/uploads/properties/';
$UPLOAD_DIR_WEB = BASE . '/uploads/properties/';
$MAX_BYTES      = 5 * 1024 * 1024; // 5 MB
$ALLOWED_EXT    = ['jpg','jpeg','jfif','png','webp','gif'];
$ALLOWED_MIME   = [
    'image/jpeg',
    'image/pjpeg',
    'image/jfif',
    'image/png',
    'image/webp',
    'image/gif',
];

if (!is_dir($UPLOAD_DIR_FS)) {
    @mkdir($UPLOAD_DIR_FS, 0775, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check();

    $title       = trim($_POST['title'] ?? '');
    $type        = $_POST['type'] ?? '';
    $purpose     = $_POST['purpose'] ?? '';
    $location    = trim($_POST['location'] ?? '');
    $price       = (float)($_POST['price'] ?? 0);
    $bedrooms    = (int)($_POST['bedrooms'] ?? 0);
    $bathrooms   = (int)($_POST['bathrooms'] ?? 0);
    $size        = trim($_POST['size'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $image_url   = trim($_POST['image_url'] ?? '');

    if ($title === '' || $location === '' || $price <= 0) {
        $err = 'Title, location, and a positive price are required.';
    } elseif (!in_array($type, ['Apartment','Bungalow','Townhouse','Land','Commercial'], true)) {
        $err = 'Please choose a valid property type.';
    } elseif (!in_array($purpose, ['sale','rent'], true)) {
        $err = 'Please choose Sale or Rent.';
    }

    /* ---------- Handle upload ---------- */
    $savedImagePath = null;

    if (!$err && !empty($_FILES['image']['name'] ?? '')) {
        $f = $_FILES['image'];

        if ($f['error'] !== UPLOAD_ERR_OK) {
            $err = 'Image upload failed (code ' . (int)$f['error'] . ').';
        } elseif ($f['size'] > $MAX_BYTES) {
            $err = 'Image is larger than ' . ($MAX_BYTES / 1024 / 1024) . ' MB.';
        } else {
            $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, $ALLOWED_EXT, true)) {
                $err = 'Only JPG, JPEG, JFIF, PNG, WEBP or GIF images are allowed.';
            } else {
                $finfo = function_exists('finfo_open') ? finfo_open(FILEINFO_MIME_TYPE) : null;
                $mime  = $finfo ? finfo_file($finfo, $f['tmp_name']) : ($f['type'] ?? '');
                if ($finfo) finfo_close($finfo);

                if (!in_array(strtolower($mime), $ALLOWED_MIME, true)) {
                    $err = 'The uploaded file is not a valid image.';
                } elseif (!is_uploaded_file($f['tmp_name'])) {
                    $err = 'Upload verification failed.';
                } else {
                    $safeBase = preg_replace('/[^a-z0-9\-_]+/i', '-', pathinfo($f['name'], PATHINFO_FILENAME));
                    $safeBase = trim($safeBase, '-_') ?: 'image';

                    /*
                     * JFIF is just a JPEG container. Rename the stored extension to .jpg
                     * so browsers always display it reliably (some older browsers and
                     * PHP GD helpers don't render .jfif in <img> as consistently).
                     */
                    if ($ext === 'jfif') {
                        $ext = 'jpg';
                    }

                    $newName  = $safeBase . '-' . date('YmdHis') . '-' . bin2hex(random_bytes(3)) . '.' . $ext;
                    $destFs   = $UPLOAD_DIR_FS . $newName;

                    if (move_uploaded_file($f['tmp_name'], $destFs)) {
                        $savedImagePath = $UPLOAD_DIR_WEB . $newName;
                    } else {
                        $err = 'Could not save the uploaded image. Check folder permissions.';
                    }
                }
            }
        }
    }

    /* Fall back to URL if no upload */
    if (!$err && !$savedImagePath && $image_url !== '') {
        if (!filter_var($image_url, FILTER_VALIDATE_URL)) {
            $err = 'The image URL is not valid.';
        } else {
            $savedImagePath = $image_url;
        }
    }

    if (!$err) {
        q("INSERT INTO properties
            (owner_id, title, type, purpose, location, price, bedrooms, bathrooms, size, description, image_url, status)
           VALUES (?,?,?,?,?,?,?,?,?,?,?, 'pending')",
            [
                $u['id'], $title, $type, $purpose, $location, $price,
                $bedrooms, $bathrooms, $size, $description, $savedImagePath
            ]
        );
        logit("Listed a new property: $title");
        go('/user/properties.php?created=1');
    }
}

top('List a property');
?>
<style>
    .form-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 12px;
    }
    .upload-box {
        background: #f8fafc;
        border: 1px dashed #cbd5e1;
        border-radius: 10px;
        padding: 14px;
        margin-bottom: 16px;
    }
    .upload-box label { margin-bottom: 6px; }
    .upload-box small { color: #6b7280; font-weight: 400; }
    .preview {
        display: none;
        margin-top: 12px;
        border-radius: 8px;
        max-height: 260px;
        object-fit: cover;
        width: 100%;
        border: 1px solid #e5e7eb;
    }
    .hint {
        font-size: .85rem;
        color: #6b7280;
        margin: 6px 0 16px;
        padding: 10px 12px;
        background: #eff6ff;
        border: 1px solid #bfdbfe;
        border-radius: 8px;
    }
    .back-link {
        display: inline-block;
        margin-bottom: 12px;
        color: #6b7280;
        font-size: .9rem;
        text-decoration: none;
    }
    .back-link:hover { color: #2563eb; }
    .form-actions {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
        margin-top: 8px;
    }
    @media (max-width: 640px) {
        .form-actions .btn { width: 100%; }
    }
</style>

<section class="wrap narrow">
    <a href="<?=BASE?>/properties.php" class="back-link">&larr; Back to properties</a>
    <h1>List a property</h1>
    <p class="muted">Fill in the details below. Your listing will be reviewed by an admin before it goes public.</p>

    <?php if ($err): ?>
        <div class="box" style="border-left:4px solid #dc2626">
            <strong class="bad"><?=e($err)?></strong>
        </div>
    <?php endif; ?>

    <form method="post" class="box" enctype="multipart/form-data">
        <?=field()?>

        <label>Title
            <input type="text" name="title" required maxlength="150"
                   value="<?=e($_POST['title'] ?? '')?>"
                   placeholder="e.g. Modern 3-bedroom apartment">
        </label>

        <div class="form-grid">
            <label>Property type
                <select name="type" required>
                    <option value="">Select type</option>
                    <?php foreach (['Apartment','Bungalow','Townhouse','Land','Commercial'] as $t): ?>
                        <option value="<?=$t?>" <?=($_POST['type'] ?? '')===$t?'selected':''?>><?=$t?></option>
                    <?php endforeach; ?>
                </select>
            </label>

            <label>Purpose
                <select name="purpose" required>
                    <option value="">Select purpose</option>
                    <option value="sale" <?=($_POST['purpose'] ?? '')==='sale'?'selected':''?>>For Sale</option>
                    <option value="rent" <?=($_POST['purpose'] ?? '')==='rent'?'selected':''?>>For Rent</option>
                </select>
            </label>

            <label>Location
                <input type="text" name="location" required maxlength="120"
                       value="<?=e($_POST['location'] ?? '')?>"
                       placeholder="e.g. Kilimani, Nairobi">
            </label>

            <label>Price (KShs)
                <input type="number" name="price" step="0.01" min="1" required
                       value="<?=e($_POST['price'] ?? '')?>">
            </label>

            <label>Bedrooms
                <input type="number" name="bedrooms" min="0" max="50"
                       value="<?=e($_POST['bedrooms'] ?? 0)?>">
            </label>

            <label>Bathrooms
                <input type="number" name="bathrooms" min="0" max="50"
                       value="<?=e($_POST['bathrooms'] ?? 0)?>">
            </label>

            <label>Size
                <input type="text" name="size" maxlength="40"
                       value="<?=e($_POST['size'] ?? '')?>"
                       placeholder="e.g. 140 sqm or 0.25 acre">
            </label>
        </div>

        <!-- Upload image -->
        <div class="upload-box">
            <label>Property image
                <input type="file" name="image" id="imageInput"
                       accept=".jpg,.jpeg,.jfif,.png,.webp,.gif,image/jpeg,image/png,image/webp,image/gif">
                <small>JPG, JPEG, JFIF, PNG, WEBP or GIF · max 5 MB</small>
            </label>

            <img id="imagePreview" class="preview" alt="Preview">

            <p class="muted" style="font-size:.8rem;margin:10px 0 6px">
                Or paste an image URL if you don't have a file to upload.
            </p>
            <label>Image URL (optional)
                <input type="url" name="image_url" maxlength="255"
                       value="<?=e($_POST['image_url'] ?? '')?>"
                       placeholder="https://…">
            </label>
        </div>

        <label>Description
            <textarea name="description" rows="5" placeholder="Describe the property, amenities, and what makes it special…"><?=e($_POST['description'] ?? '')?></textarea>
        </label>

        <div class="hint">
            <strong>Note:</strong> New listings are saved as <strong>pending</strong>. They become visible on the public properties page once an admin approves them.
        </div>

        <div class="form-actions">
            <button class="btn">
                <i class="bi bi-check2-circle"></i> Submit listing
            </button>
            <a class="btn ghost" href="<?=BASE?>/properties.php">Cancel</a>
        </div>
    </form>
</section>

<script>
    document.getElementById('imageInput').addEventListener('change', function (e) {
        const file = e.target.files && e.target.files[0];
        const img  = document.getElementById('imagePreview');
        if (!file) { img.style.display = 'none'; img.src = ''; return; }
        if (!file.type.startsWith('image/')) { img.style.display = 'none'; return; }
        const reader = new FileReader();
        reader.onload = function (ev) {
            img.src = ev.target.result;
            img.style.display = 'block';
        };
        reader.readAsDataURL(file);
    });
</script>

<?php include 'includes/footer.php'; ?>